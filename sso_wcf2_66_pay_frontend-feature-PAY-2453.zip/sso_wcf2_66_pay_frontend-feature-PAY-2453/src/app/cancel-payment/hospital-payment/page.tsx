import React from 'react';
import HospitalPaymentForm from '@/modules/cancel-payment/hospital-payment';

export default function PageHospitalPayment(): React.ReactElement {
  return <HospitalPaymentForm />;
}
