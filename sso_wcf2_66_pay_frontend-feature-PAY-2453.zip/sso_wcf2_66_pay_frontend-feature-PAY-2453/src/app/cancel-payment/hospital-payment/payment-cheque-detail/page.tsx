import React from 'react';
import PaymentChequeDetail from '@/modules/cancel-payment/hospital-payment/payment-cheque-detail';

export default function PagePaymentChequeDetail(): React.ReactElement {
  return <PaymentChequeDetail />;
}
