import React from 'react';
import RefundToEmployerForm from '@/modules/cancel-payment/refund-to-employer';

export default function PageRefundToEmployer(): React.ReactElement {
  return <RefundToEmployerForm />;
}
