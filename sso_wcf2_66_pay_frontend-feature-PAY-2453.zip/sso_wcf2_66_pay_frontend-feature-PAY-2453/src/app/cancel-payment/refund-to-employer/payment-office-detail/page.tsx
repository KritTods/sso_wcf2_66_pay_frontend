import React from 'react';
import PaymentOfficeDetail from '@/modules/cancel-payment/refund-to-employer/payment-office-detail';

export default function PagePaymentOfficeDetail(): React.ReactElement {
  return <PaymentOfficeDetail />;
}
