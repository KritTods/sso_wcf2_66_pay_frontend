import React from 'react';
import PaymentChequeDetail from '@/modules/cancel-payment/refund-to-employer/payment-cheque-detail';

export default function PagePaymentChequeDetail(): React.ReactElement {
  return <PaymentChequeDetail />;
}
