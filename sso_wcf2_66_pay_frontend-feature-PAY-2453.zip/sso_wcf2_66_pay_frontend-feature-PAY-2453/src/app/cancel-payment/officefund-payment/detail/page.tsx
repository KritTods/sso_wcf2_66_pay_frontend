import React from 'react';
import OfficefundPaymentDetail from '@/modules/cancel-payment/officefund-payment/detail';

export default function PageOfficefundPaymentDetail(): React.ReactElement {
  return <OfficefundPaymentDetail />;
}
