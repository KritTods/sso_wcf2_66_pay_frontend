import React from 'react';
import OfficefundPaymentForm from '@/modules/cancel-payment/officefund-payment';

export default function PageOfficefundPayment(): React.ReactElement {
  return <OfficefundPaymentForm />;
}
