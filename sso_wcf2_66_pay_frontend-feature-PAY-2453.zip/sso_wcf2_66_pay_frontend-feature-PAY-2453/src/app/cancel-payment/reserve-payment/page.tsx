import React from 'react';
import CancelReservePaymentMenus from '@/modules/cancel-payment/reserve-payment';

export default function PageCancelReservePayment(): React.ReactElement {
  return <CancelReservePaymentMenus />;
}
