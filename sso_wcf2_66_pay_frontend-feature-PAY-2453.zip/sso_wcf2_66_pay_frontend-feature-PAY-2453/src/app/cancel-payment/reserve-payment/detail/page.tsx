import React from 'react';
import CancelReservePaymentDetail from '@/modules/cancel-payment/reserve-payment/detail';

export default function PageCancelReservePaymentDetail(): React.ReactElement {
  return <CancelReservePaymentDetail />;
}
