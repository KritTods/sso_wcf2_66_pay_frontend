import React from 'react';
import OtherPaymentForm from '@/modules/cancel-payment/other-payment';

export default function PageOtherPayment(): React.ReactElement {
  return <OtherPaymentForm />;
}
