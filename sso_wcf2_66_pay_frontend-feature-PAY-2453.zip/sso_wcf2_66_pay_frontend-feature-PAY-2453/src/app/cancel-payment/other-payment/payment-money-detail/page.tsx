import React from 'react';
import PaymentMoneyDetail from '@/modules/cancel-payment/other-payment/payment-money-detail';

export default function PagePaymentMoneyDetail(): React.ReactElement {
  return <PaymentMoneyDetail />;
}
