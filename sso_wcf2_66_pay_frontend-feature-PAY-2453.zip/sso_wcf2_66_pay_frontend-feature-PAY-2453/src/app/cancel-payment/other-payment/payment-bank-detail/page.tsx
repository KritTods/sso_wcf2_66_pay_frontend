import React from 'react';
import BankDetail from '@/modules/cancel-payment/other-payment/payment-bank-detail';

export default function PagePaymentBankDetail(): React.ReactElement {
  return <BankDetail />;
}
