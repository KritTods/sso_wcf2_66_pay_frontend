import React from 'react';
import PaymentOfficeDetail from '@/modules/cancel-payment/wrongfund-payment/payment-office-detail';

export default function PagePaymentOfficeDetail(): React.ReactElement {
  return <PaymentOfficeDetail />;
}
