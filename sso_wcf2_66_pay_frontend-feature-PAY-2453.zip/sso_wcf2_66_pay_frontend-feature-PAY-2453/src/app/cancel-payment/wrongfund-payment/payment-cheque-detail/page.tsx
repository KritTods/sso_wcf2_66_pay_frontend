import React from 'react';
import PaymentChequeDetail from '@/modules/cancel-payment/wrongfund-payment/payment-cheque-detail';

export default function PagePaymentChequeDetail(): React.ReactElement {
  return <PaymentChequeDetail />;
}
