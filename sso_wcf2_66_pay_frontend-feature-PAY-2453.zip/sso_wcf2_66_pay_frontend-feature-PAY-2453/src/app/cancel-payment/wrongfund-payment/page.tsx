import React from 'react';
import WrongfundPaymentForm from '@/modules/cancel-payment/wrongfund-payment';

export default function PageWrongfundPayment(): React.ReactElement {
  return <WrongfundPaymentForm />;
}
