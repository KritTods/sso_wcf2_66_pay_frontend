import React from 'react';
import PaymentMoneyDetail from '@/modules/cancel-payment/wrongfund-payment/payment-money-detail';

export default function PagePaymentMoneyDetail(): React.ReactElement {
  return <PaymentMoneyDetail />;
}
