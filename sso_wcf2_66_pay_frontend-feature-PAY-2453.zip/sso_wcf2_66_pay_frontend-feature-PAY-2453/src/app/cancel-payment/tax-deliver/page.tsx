import React from 'react';
import TaxDeliverForm from '@/modules/cancel-payment/tax-deliver';

export default function PageTaxDeliver(): React.ReactElement {
  return <TaxDeliverForm />;
}
