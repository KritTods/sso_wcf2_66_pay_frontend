import React from 'react';
import CancelPaymentMenus from '@/modules/cancel-payment';

export default function PageCancelPayment(): React.ReactElement {
  return <CancelPaymentMenus />;
}
