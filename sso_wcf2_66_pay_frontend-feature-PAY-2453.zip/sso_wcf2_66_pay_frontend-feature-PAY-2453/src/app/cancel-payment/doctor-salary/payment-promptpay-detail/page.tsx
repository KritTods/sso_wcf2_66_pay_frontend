import React from 'react';
import PromptPayDetail from '@/modules/cancel-payment/doctor-salary/payment-promptpay-detail';

export default function PagePaymentPromptPayDetail(): React.ReactElement {
  return <PromptPayDetail />;
}
