import React from 'react';
import PaymentMoneyDetail from '@/modules/cancel-payment/doctor-salary/payment-money-detail';

export default function PagePaymentMoneyDetail(): React.ReactElement {
  return <PaymentMoneyDetail />;
}
