import React from 'react';
import PaymentChequeDetail from '@/modules/cancel-payment/doctor-salary/payment-cheque-detail';

export default function PagePaymentChequeDetail(): React.ReactElement {
  return <PaymentChequeDetail />;
}
