import React from 'react';
import BankDetail from '@/modules/cancel-payment/doctor-salary/payment-bank-detail';
export default function PagePaymentBankDetail(): React.ReactElement {
  return <BankDetail />;
}
