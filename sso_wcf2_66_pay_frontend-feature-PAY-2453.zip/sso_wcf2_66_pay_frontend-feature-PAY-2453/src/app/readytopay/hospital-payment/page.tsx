import React from 'react';
import HospitalPaymentForm from '@/modules/readytopay/hospital-payment';

export default function PageHospitalPayment(): React.ReactElement {
  return <HospitalPaymentForm />;
}
