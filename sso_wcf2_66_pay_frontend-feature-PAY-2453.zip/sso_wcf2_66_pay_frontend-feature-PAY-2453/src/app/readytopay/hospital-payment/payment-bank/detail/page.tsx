import React from 'react';
import BankDetail from '@/modules/readytopay/hospital-payment/payment-bank/detail';
export default function PageDetail(): React.ReactElement {
  return (
    <div className='m-4'>
      <BankDetail />
    </div>
  );
}
