import React from 'react';
import HPpaymentMoneyDetail from '@/modules/readytopay/hospital-payment/payment-money/detail';

export default function PageHPpaymentMoneyDetail(): React.ReactElement {
  return (
    <div>
      <HPpaymentMoneyDetail />
    </div>
  );
}
