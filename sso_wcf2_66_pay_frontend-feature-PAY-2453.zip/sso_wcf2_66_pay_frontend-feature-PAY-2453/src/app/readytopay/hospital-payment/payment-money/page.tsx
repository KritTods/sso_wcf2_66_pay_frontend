import React from 'react';
import HPpaymentMoney from '@/modules/readytopay/hospital-payment/payment-money';

export default function PageHPpaymentMoney(): React.ReactElement {
  return (
    <div>
      <HPpaymentMoney />
    </div>
  );
}
