import React from 'react';
import HPpaymentCheck from '@/modules/readytopay/hospital-payment/payment-cheque';

export default function PageHPpaymentCheck(): React.ReactElement {
  return (
    <div>
      <HPpaymentCheck />
    </div>
  );
}
