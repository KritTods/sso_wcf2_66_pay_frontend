import React from 'react';
import HPpaymentCheckDetail from '@/modules/readytopay/hospital-payment/payment-cheque/detail';

export default function PageHPpaymentCheckDetail(): React.ReactElement {
  return (
    <div>
      <HPpaymentCheckDetail />
    </div>
  );
}
