import React from 'react';
import PaymentOfficeDetail from '@/modules/readytopay/hospital-payment//payment-office/detail';

export default function PagePaymentOfficeDetail(): React.ReactElement {
  return <PaymentOfficeDetail />;
}
