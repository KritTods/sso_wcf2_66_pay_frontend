import React from 'react';
import PaymentOfficeForm from '@/modules/readytopay/hospital-payment/payment-office';

export default function PagePaymentOffice(): React.ReactElement {
  return <PaymentOfficeForm />;
}
