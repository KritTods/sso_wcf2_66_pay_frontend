import React from 'react';
import OfficeFundPaymentDetailForm from '@/modules/readytopay/officefund-payment/detail';

export default function PageOfficeFundPaymentDetail(): React.ReactElement {
  return <OfficeFundPaymentDetailForm />;
}
