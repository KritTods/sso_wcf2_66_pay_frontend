import React from 'react';
import OfficeFundPaymentForm from '@/modules/readytopay/officefund-payment';

export default function PageOfficeFundPayment(): React.ReactElement {
  return <OfficeFundPaymentForm />;
}
