import React from 'react';
import DoctorSalaryDetail from '@/modules/readytopay/doctor-salary/detail';
export default function PageDoctorSalaryDetail(): React.ReactElement {
  return (
    <div className='m-4'>
      <DoctorSalaryDetail />
    </div>
  );
}
