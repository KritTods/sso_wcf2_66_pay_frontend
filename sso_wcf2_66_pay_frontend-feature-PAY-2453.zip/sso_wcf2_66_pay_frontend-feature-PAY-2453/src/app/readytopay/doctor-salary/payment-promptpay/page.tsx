import React from 'react';
import PromptPay from '@/modules/readytopay/doctor-salary/payment-promptpay';

export default function PagePromptPay(): React.ReactElement {
  return <PromptPay />;
}
