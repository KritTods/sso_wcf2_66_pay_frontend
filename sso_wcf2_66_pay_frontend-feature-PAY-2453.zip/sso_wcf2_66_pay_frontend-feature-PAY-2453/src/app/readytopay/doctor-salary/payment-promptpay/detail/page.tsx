import React from 'react';
import PromptPayDetail from '@/modules/readytopay/doctor-salary/payment-promptpay/detail';

export default function PagePromptPay(): React.ReactElement {
  return <PromptPayDetail />;
}
