import React from 'react';
import BankDetail from '@/modules/readytopay/doctor-salary/payment-bank/detail';
export default function PageDetail(): React.ReactElement {
  return (
    <div className='m-4'>
      <BankDetail />
    </div>
  );
}
