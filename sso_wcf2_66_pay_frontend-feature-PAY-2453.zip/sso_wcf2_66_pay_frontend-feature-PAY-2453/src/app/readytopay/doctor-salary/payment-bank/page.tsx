import React from 'react';
import Paymentbank from '@/modules/readytopay/doctor-salary/payment-bank';

export default function PagePaymentbank(): React.ReactElement {
  return (
    <div className='m-4'>
      <Paymentbank />
    </div>
  );
}
