import React from 'react';
import DoctorSalaryForm from '@/modules/readytopay/doctor-salary';

export default function PageDoctorSalary(): React.ReactElement {
  return <DoctorSalaryForm />;
}
