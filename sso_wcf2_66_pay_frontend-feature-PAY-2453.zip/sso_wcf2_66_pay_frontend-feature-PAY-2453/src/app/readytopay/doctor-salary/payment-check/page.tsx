import React from 'react';
import PaymentCheck from '@/modules/readytopay/doctor-salary/payment-cheque';

export default function PagePaymentCheck(): React.ReactElement {
  return (
    <div>
      <PaymentCheck />
    </div>
  );
}
