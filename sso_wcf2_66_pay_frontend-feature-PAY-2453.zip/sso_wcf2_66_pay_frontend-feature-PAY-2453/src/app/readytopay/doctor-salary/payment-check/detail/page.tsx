import React from 'react';
import PaymentCheckDetail from '@/modules/readytopay/doctor-salary/payment-cheque/detail';

export default function PagePaymentCheckDetail(): React.ReactElement {
  return (
    <div>
      <PaymentCheckDetail />
    </div>
  );
}
