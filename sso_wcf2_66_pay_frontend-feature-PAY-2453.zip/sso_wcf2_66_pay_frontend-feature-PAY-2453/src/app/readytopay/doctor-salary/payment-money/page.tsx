import React from 'react';
import PaymentMoney from '@/modules/readytopay/doctor-salary/payment-money';

export default function PagePaymentMoney(): React.ReactElement {
    return <div>
        <PaymentMoney/>
        </div> ;
  }
