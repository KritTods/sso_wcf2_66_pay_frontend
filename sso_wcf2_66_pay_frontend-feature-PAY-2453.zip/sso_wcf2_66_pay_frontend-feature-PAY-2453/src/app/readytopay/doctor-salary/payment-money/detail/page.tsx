import React from 'react';
import PaymentMoneyDetail from '@/modules/readytopay/doctor-salary/payment-money/detail';

export default function PagePaymentMoneyDetail(): React.ReactElement {
    return <div>
        <PaymentMoneyDetail/>
        </div>;
}
