import React from 'react';
import PageOtherPaymentForm from '@/modules/readytopay/other-payment';

export default function PageOtherPayment(): React.ReactElement {
  return <PageOtherPaymentForm />;
}
