import React from 'react';
import OtherPaymentDetail from '@/modules/readytopay/other-payment/detail';

export default function PageOtherPaymentDetail(): React.ReactElement {
  return <OtherPaymentDetail />;
}
