import React from 'react';
import ReadyToPayForm from '@/modules/readytopay';

export default function PageReadyToPay(): React.ReactElement {
  return <ReadyToPayForm />;
}
