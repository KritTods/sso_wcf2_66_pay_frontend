import React from 'react';
import REpaymentCheck from '@/modules/readytopay/refund-to-employer/payment-cheque';

export default function PageREpaymentCheck(): React.ReactElement {
  return (
    <div>
      <REpaymentCheck />
    </div>
  );
}
