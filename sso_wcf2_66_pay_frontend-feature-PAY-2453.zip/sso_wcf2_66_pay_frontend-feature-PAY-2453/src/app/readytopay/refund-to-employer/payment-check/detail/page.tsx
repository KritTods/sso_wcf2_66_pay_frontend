import React from 'react';
import REpaymentCheckDetail from '@/modules/readytopay/refund-to-employer/payment-cheque/detail';

export default function PageREpaymentCheckDetail(): React.ReactElement {
  return (
    <div>
      <REpaymentCheckDetail />
    </div>
  );
}
