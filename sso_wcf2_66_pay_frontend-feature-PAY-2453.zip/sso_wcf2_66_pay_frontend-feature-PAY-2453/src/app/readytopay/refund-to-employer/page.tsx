import React from 'react';
import RefundToEmployer from '@/modules/readytopay/refund-to-employer';

export default function PageRefundToEmployer(): React.ReactElement {
  return <RefundToEmployer />;
}
