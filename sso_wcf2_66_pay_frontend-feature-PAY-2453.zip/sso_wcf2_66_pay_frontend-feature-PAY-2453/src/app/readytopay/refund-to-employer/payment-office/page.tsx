import React from 'react';
import PaymentOffice from '@/modules/readytopay/refund-to-employer/payment-office';

export default function PagePaymentOffice(): React.ReactElement {
  return <PaymentOffice />;
}
