import React from 'react';
import PaymentOfficeDetail from '@/modules/readytopay/refund-to-employer/payment-office/detail';

export default function PageDetail(): React.ReactElement {
  return <PaymentOfficeDetail />;
}
