import React from 'react';
import PaymentBankDetail from '@/modules/readytopay/refund-to-employer/payment-bank/detail';

export default function PagePaymentBankDetail(): React.ReactElement {
  return <PaymentBankDetail />;
}
