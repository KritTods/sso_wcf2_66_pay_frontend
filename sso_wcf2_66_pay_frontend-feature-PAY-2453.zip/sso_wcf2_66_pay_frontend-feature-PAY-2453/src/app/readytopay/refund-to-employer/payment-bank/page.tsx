import React from 'react';
import PaymentBank from '@/modules/readytopay/refund-to-employer/payment-bank';

export default function PagePaymentBank(): React.ReactElement {
  return <PaymentBank />;
}
