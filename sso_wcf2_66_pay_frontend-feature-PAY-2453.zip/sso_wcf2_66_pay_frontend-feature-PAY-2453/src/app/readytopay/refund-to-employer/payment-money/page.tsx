import React from 'react';
import REpaymentMoney from '@/modules/readytopay/refund-to-employer/payment-money';

export default function PageREpaymentMoney(): React.ReactElement {
    return <div>
        <REpaymentMoney/>
        </div> ;
  }
