import React from 'react';
import HPpaymentMoneyDetail from '@/modules/readytopay/refund-to-employer/payment-money/detail';

export default function PageHPpaymentMoneyDetail(): React.ReactElement {
    return <div>
        <HPpaymentMoneyDetail/>
        </div>;
}
