import React from 'react';
import CutOffWrongFundPayment from '@/modules/cut-off-payment/wrongfund-payment';

export default function PageCutOffWrongFundPayment(): React.ReactElement {
  return <CutOffWrongFundPayment />;
}
