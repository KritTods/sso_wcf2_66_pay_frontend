import React from 'react';
import CutOffRefundToEmployer from '@/modules/cut-off-payment/refund-to-employer';

export default function PageCutOffRefundToEmployer(): React.ReactElement {
  return <CutOffRefundToEmployer />;
}
