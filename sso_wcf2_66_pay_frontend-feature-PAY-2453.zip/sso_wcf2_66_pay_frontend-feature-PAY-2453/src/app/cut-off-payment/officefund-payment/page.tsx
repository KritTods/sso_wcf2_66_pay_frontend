import React from 'react';
import CutOffOfficeFundPayment from '@/modules/cut-off-payment/officefund-payment';

export default function PageCutOffOfficeFundPayment(): React.ReactElement {
  return <CutOffOfficeFundPayment />;
}
