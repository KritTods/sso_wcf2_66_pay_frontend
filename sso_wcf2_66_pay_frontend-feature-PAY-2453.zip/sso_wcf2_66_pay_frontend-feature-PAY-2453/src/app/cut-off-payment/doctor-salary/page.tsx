import React from 'react';
import DoctorSalaryForm from '@/modules/cut-off-payment/doctor-salary';

export default function PageDoctorSalary(): React.ReactElement {
  return <DoctorSalaryForm />;
}
