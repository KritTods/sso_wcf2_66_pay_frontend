import React from 'react';
import PaymentOfficeForm from '@/modules/cut-off-payment/doctor-salary/payment-office';

export default function PagePaymentOffice(): React.ReactElement {
  return <PaymentOfficeForm />;
}
