import React from 'react';
import PaymentChequeDetail from '@/modules/cut-off-payment/doctor-salary/payment-cheque/detail';

export default function PagePaymentChequeDetail(): React.ReactElement {
  return <PaymentChequeDetail />;
}
