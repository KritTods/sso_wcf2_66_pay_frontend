import React from 'react';
import PaymentChequeForm from '@/modules/cut-off-payment/doctor-salary/payment-cheque';

export default function PagePaymentCheque(): React.ReactElement {
  return <PaymentChequeForm />;
}
