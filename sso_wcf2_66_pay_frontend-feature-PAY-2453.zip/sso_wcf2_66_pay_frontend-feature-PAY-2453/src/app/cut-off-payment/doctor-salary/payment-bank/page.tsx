import React from 'react';
import PaymentBankForm from '@/modules/cut-off-payment/doctor-salary/payment-bank';

export default function PagePaymentBank(): React.ReactElement {
  return <PaymentBankForm />;
}
