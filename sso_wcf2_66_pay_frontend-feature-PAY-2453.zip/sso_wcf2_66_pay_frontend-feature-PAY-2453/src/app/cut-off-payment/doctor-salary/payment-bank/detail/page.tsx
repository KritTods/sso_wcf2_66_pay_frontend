import React from 'react';
import PaymentBankDetail from '@/modules/cut-off-payment/doctor-salary/payment-bank/detail';

export default function PagePaymentBankDetail(): React.ReactElement {
  return <PaymentBankDetail />;
}
