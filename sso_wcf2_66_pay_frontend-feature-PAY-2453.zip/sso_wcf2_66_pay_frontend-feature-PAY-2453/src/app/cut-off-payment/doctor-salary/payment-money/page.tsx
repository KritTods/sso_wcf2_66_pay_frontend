import React from 'react';
import PaymentMoneyForm from '@/modules/cut-off-payment/doctor-salary/payment-money';

export default function PagePaymentMoney(): React.ReactElement {
  return <PaymentMoneyForm />;
}
