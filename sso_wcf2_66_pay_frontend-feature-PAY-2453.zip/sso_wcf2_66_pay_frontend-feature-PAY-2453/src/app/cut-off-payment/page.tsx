import React from 'react';
import CutOffPaymentMenus from '@/modules/cut-off-payment';

export default function PageCutOffPaymentMenus(): React.ReactElement {
  return <CutOffPaymentMenus />;
}
