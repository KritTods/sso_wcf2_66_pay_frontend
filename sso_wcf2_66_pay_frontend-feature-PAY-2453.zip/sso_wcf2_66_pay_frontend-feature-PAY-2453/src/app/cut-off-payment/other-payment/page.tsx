import React from 'react';
import OtherPaymentForm from '@/modules/cut-off-payment/other-payment';

export default function PageOtherPayment(): React.ReactElement {
  return <OtherPaymentForm />;
}
