import React from 'react';

export default function Home(): React.ReactElement {
  return (
    <div className='p-2'>
      <h1>Home</h1>
    </div>
  );
}
