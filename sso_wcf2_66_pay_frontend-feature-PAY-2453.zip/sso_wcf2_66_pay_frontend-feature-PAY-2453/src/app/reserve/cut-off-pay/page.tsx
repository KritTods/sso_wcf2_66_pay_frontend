import React from 'react';
import CutOffList from '@/modules/reserve/cut-off-pay';

export default function PageCutOffPay(): React.ReactElement {
  return (
    <div className='m-4'>
      <CutOffList />
    </div>
  );
}
