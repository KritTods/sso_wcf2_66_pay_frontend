import React from 'react';
import CutOffPayDetail from '@/modules/reserve/cut-off-pay/detail';

export default function PageCutOffPayDetail(): React.ReactElement {
  return (
    <div className='m-4'>
      <CutOffPayDetail />
    </div>
  );
}
