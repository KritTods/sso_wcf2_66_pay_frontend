import React from 'react';
import CutOffPayForm from '@/modules/reserve/cut-off-pay/form';

export default function PageCutOffPayForm(): React.ReactElement {
  return (
    <div className='m-4'>
      <CutOffPayForm />
    </div>
  );
}
