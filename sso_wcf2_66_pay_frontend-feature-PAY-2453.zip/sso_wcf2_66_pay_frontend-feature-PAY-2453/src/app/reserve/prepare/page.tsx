import React from 'react';
import PrepareForm from '@/modules/reserve/prepare';

export default function PagePrepare(): React.ReactElement {
  return <PrepareForm />;
}
