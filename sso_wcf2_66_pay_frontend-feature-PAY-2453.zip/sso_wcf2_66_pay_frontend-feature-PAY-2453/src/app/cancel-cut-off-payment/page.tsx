import React from 'react';
import CancelCutoffPayment from '@/modules/cancel-cut-off-payment';

export default function PageCancelCutoffPayment(): React.ReactElement {
  return <CancelCutoffPayment />;
}
