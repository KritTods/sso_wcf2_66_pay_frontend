import React from 'react';
import CutReview from '@/modules/cut-review';

export default function PageCutReview(): React.ReactElement {
  return <CutReview dataTestId={''} />;
}
