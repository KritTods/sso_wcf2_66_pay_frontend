import React from 'react';
import TestComponent from '@/modules/test-component/';

export default function PageTestComponent(): React.ReactElement {
  return <TestComponent />;
}
