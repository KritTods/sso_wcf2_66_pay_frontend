// X = รับเงิน ณ สำนักงาน
// T = โอนผ่านธนาคารโดยจังหวัด (ใช้กับจ่ายโรงพยาบาล)
// S = ส่งเช็คทางไปรณษีย์
// P = ธนาณัติ
// M = พร้อมเพย์
// B = โอนผ่านธนาคารโดยจังหวัด (ใช้กับเงินทดแทนแพทย์)

export type PayType = 'X' | 'T' | 'S' | 'P' | 'M' | 'B';

export type PayToCodeType = '1' | '8'; // ประเภทเบิกเงินรองจ่าย 1 = เงินทดแทน 8 = ค่าตอบแทนแพทย์

export type AdvancePaymentType = 'PAY' | 'FIN';

export type IncorrectPaymentReasonType = 'S' | 'O' | 'J';

export type ReceiveType = 'O' | 'A';

export type PayBy = 'X' | 'C';
