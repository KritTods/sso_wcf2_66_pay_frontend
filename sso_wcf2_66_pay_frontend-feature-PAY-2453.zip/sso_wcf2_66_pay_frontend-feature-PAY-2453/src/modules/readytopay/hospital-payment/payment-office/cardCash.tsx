'use client';
import React, { useState } from 'react';
import { Form, Col, Row } from 'wcf-component-lib/node_modules/antd';
import { formColumn } from '@/constants/layoutColumn';
import { InfoCircle } from 'wcf-component-lib/node_modules/iconoir-react';
import {
  BaseForm,
  BaseDialog,
  BaseButton,
  BaseToastNotification,
  BaseIcon,
  BaseItemInputNumber,
} from 'wcf-component-lib/src/components';
import { URL } from '@/constants/configPage';
import { useRouter } from 'next/navigation';
import { useAppDispatch } from '@/store-redux/store';
import { useSelector } from 'react-redux';
import { HospitalPaymentSelector, addCashData } from '@/store-redux/slices/readytopay/hospital-payment.bk';

export default function CardCash(): React.JSX.Element {
  const [form] = Form.useForm();
  const router = useRouter();
  const dispatch = useAppDispatch();

  const [isOpenConfirmModal, setIsOpenConfirmModal] = useState(false); //บันทึกข้อมูลใช่หรือไม่?
  const [isOpenAddRow, setIsOpenAddRow] = useState(false); //กรุณาเพิ่มเช็คอย่างน้อย 1 รายการ
  const [isOpenOverPrice, setIsOpenOverPrice] = useState(false); //จำนวนเงินไม่สอดคล้อง

  const {
    doctorSalaly: {
      tabs: {
        paymentOffice: {
          paymentForm: {
            mode: { view },
          },
        },
      },
    },
  } = useSelector(HospitalPaymentSelector);

  const handleBackToMain = (): void => {
    router.push(URL.readytopay.doctorSalary.url);
  };

  const handleConfirm = (): void => {
    // show notification success
    BaseToastNotification({
      type: 'success',
      message: 'เสร็จสิ้น',
      description: 'ทำรายการเสร็จสิ้น',
    });
    router.push(`${URL.readytopay.paymentOfficeDetail.url}?tab=1`);

    //close modal
    setIsOpenConfirmModal(false);
  };

  const handleCancel = (): void => {
    setIsOpenConfirmModal(false);
    setIsOpenAddRow(false);
    setIsOpenOverPrice(false);
  };

  const onFinish = (): void => {
    const sumTotalTableListCash = view.tabs.cash;
    console.log('TabActive', view.paymentTabActive);
    console.log('sumTableList', view.sumTableList);
    console.log('sumTotalTableListCash', sumTotalTableListCash);

    if (sumTotalTableListCash !== 0) {
      if (sumTotalTableListCash === view.sumTableList) {
        setIsOpenConfirmModal(true);
      } else {
        setIsOpenOverPrice(true);
      }
    } else {
      setIsOpenAddRow(true);
    }
  };

  return (
    <BaseForm extraForm={form} name='doctor-salary-tabcheck-form' onFinish={onFinish}>
      <div className='flex flex-col items-center'>
        <div className='w-full bg-white p-6'>
          <p className='font-bold text-xl'>สั่งจ่ายโดย : เงินสด</p>
          <Row gutter={[16, 16]}>
            <Col {...formColumn}>
              <BaseItemInputNumber
                label='จำนวนเงิน (บาท)'
                id='amount-form'
                className='w-full'
                rules={[{ required: true, message: 'กรุณากรอก' }]}
                itemName='amount'
                step={1}
                hideFieldControl={true}
                onChangeFunction={(e) => {
                  console.log('Number(e.target.value)', Number(e.target.value));
                  //เก็บค่า ผลรวมเข้า store
                  if (Number(e.target.value) > 0) {
                    void dispatch(addCashData(Number(e.target.value)));
                  }
                }}
              />
            </Col>
          </Row>
        </div>
      </div>
      {/* ปุ่ม ยกเลิก/บันทึก */}
      <div className='flex justify-center  gap-4 py-6'>
        <BaseButton
          size='middle'
          type='cancel'
          label='ยกเลิก'
          className='w-[240px]'
          onClick={handleBackToMain} // เรียกฟังก์ชันเมื่อกดปุ่ม
        />
        <BaseButton
          size='middle'
          label='บันทึกข้อมูล'
          className='w-[240px]'
          // htmlType='submit'
          onClick={() => form.submit()}
        />
      </div>
      <BaseDialog
        width='560px'
        isOpen={isOpenConfirmModal}
        setIsOpen={setIsOpenConfirmModal}
        content={
          <div className='flex flex-col w-full gap-4'>
            <div className='text-left font-semibold text-3xl'>บันทึกข้อมูลใช่หรือไม่?</div>
            <div className='text-left status text-[#4B5760]'>กรุณายืนยันการทำรายการอีกครั้ง</div>
          </div>
        }
        headerLeftIcon={
          <BaseIcon
            name='downloadSquare'
            size='40px'
            classNameColor={{
              base: 'text-primary',
              hover: 'text-primary-bright',
              active: 'text-secondary',
              disabled: 'text-primary-very-bright',
            }}
            disabled={false}
            active={false}
          />
        }
        footer={
          <div className='flex justify-center gap-4'>
            <BaseButton size='middle' type='cancel' label='ยกเลิก' onClick={handleCancel} />
            <BaseButton size='middle' label='ยืนยัน' onClick={handleConfirm} />
          </div>
        }
      />

      <BaseDialog
        width='560px'
        isOpen={isOpenAddRow}
        setIsOpen={setIsOpenAddRow}
        themeIcon='warning'
        content={
          <div className='flex flex-col w-full gap-4'>
            <div className='text-left font-semibold text-3xl'>ไม่สามารถทำรายการได้</div>
            <div className='text-left status text-[#4B5760]'>กรุณาเพิ่มเช็คอย่างน้อย 1 รายการ</div>
          </div>
        }
        headerLeftIcon={<InfoCircle />}
        footer={
          <div className='flex justify-center gap-4'>
            <BaseButton size='middle' label='ตกลง' onClick={handleCancel} />
          </div>
        }
      />

      <BaseDialog
        width='560px'
        isOpen={isOpenOverPrice}
        setIsOpen={setIsOpenOverPrice}
        themeIcon='warning'
        content={
          <div className='flex flex-col w-full gap-4'>
            <div className='text-left font-semibold text-3xl'>จำนวนเงินไม่สอดคล้อง</div>
            <div className='text-left status text-[#4B5760]'>
              จำนวนเงินสั่งจ่ายไม่สอดคล้องกับจำนวนเงินที่ต้องจ่าย กรุณาตรวจสอบการทำรายการอีกครั้ง
            </div>
          </div>
        }
        headerLeftIcon={<InfoCircle />}
        footer={
          <div className='flex justify-center gap-4'>
            <BaseButton size='middle' label='ตกลง' onClick={handleCancel} />
          </div>
        }
      />
    </BaseForm>
  );
}
