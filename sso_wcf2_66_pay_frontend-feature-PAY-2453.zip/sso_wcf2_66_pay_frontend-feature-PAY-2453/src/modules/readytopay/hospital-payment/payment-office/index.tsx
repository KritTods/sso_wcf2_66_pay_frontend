'use client';
import React, { useState, useEffect, use } from 'react';
import { Col, Row, TabsProps } from 'wcf-component-lib/node_modules/antd';
import { formColumn } from '@/constants/layoutColumn';
import { BaseTabs, BaseIcon, BaseLoading } from 'wcf-component-lib/src/components';
import TablePaymentRequest from '@/modules/readytopay/hospital-payment/component/tablePaymentRequest';
import CardCheque from '@/modules/readytopay/hospital-payment/payment-office/cardCheque';
import { Cash } from 'wcf-component-lib/node_modules/iconoir-react';
import CardCash from '@/modules/readytopay/hospital-payment/payment-office/cardCash';
import { useAppDispatch } from '@/store-redux/store';
import { useSelector } from 'react-redux';
import { URL } from '@/constants/configPage';
import { useRouter } from 'next/navigation';
import { statusPayType } from '@/constants/statusSystem';
import { PayType } from '@/types/payType';
import { formatDayThai } from '@/utils/formatGeneral';
import useLayout from 'wcf-component-lib/src/provider/LayoutProvider/useLayout';
import {
  clearFilter,
  getFilterListService,
  hospitalPaymentSelector,
  ReadyToPayDataType,
  setFilter,
  setPageForm,
} from '@/store-redux/slices/readytopay/hospital-payment';

const PaymentOffice: React.FC = () => {
  const dataTestId = 'pageHospitalPaymentForm';
  const dispatch = useAppDispatch();
  const [activeTab, setActiveTab] = useState<string>('cheque');
  const { pageForm } = useSelector(hospitalPaymentSelector);
  const [mode, setMode] = useState<'create' | 'edite'>('create');
  const router = useRouter();
  const {
    stateLayout: { user },
  } = useLayout();

  //set ชื่อผู้เตรียมจ่าย จาก user login
  useEffect(() => {
    if (!user) return;
    void dispatch(
      setPageForm({ ...pageForm, paymentAgent: `${user?.firstName} ${user?.lastName}`, payTypeTabActive: 'X' }),
    );
  }, [user]);

  const items: TabsProps['items'] = [
    {
      key: 'cheque',
      label: (
        <div className='flex justify-center'>
          <BaseIcon
            name='payOrders'
            size='24px'
            className='!mr-1'
            classNameColor={{
              base: '!text-primary',
              active: 'white-text',
              disabled: 'text-primary-very-bright',
            }}
            disabled={false}
            active={activeTab === 'cheque'}
          />
          <span>เช็ค</span>
        </div>
      ),
      children: <CardCheque />,
    },
    {
      key: 'cash',
      label: (
        <div className='flex justify-center'>
          <Cash className='mr-2' />
          <span>เงินสด</span>
        </div>
      ),
      children: <CardCash />,
    },
  ];

  // //loading Page
  // if (!pageForm.tableList || pageForm.tableList.length === 0) {
  //   return <BaseLoading size='default' />;
  // }

  return (
    <div className=' flex flex-col justify-center gap-4 mx-4'>
      <div className='w-full bg-white p-6 shadow-sm rounded-xl'>
        <div className='flex flex-col gap-4'>
          <p className='header-card'> รายละเอียด</p>
          <Row gutter={[16, 16]}>
            <Col {...formColumn}>
              <div>
                <p className='text-label-info'>เลขที่เอกสาร</p>
                <p className='text-display'>{pageForm.documentNo}</p>
              </div>
            </Col>
            <Col {...formColumn}>
              <div>
                <p className='text-label-info'>ผู้เตรียมจ่าย</p>
                <p className='text-display'>{pageForm.paymentAgent}</p>
              </div>
            </Col>
            <Col {...formColumn}>
              <div>
                <p className='text-label-info'>วันที่เตรียมจ่าย</p>
                <p className='text-display'>{formatDayThai(pageForm.payDate)}</p>
              </div>
            </Col>
            <Col {...formColumn}>
              <div>
                <p className='text-label-info'>วิธีการชำระเงิน</p>
                <p className='text-display'>{statusPayType[pageForm.payTypeTabActive]}</p>
              </div>
            </Col>
          </Row>
        </div>
      </div>
      {/* Table รายการสั่งจ่าย */}
      <TablePaymentRequest dataTestId={dataTestId} tabActive={'X'} />
      {/* <BaseTabs
        noBackground={true}
        className='w-full'
        defaultActiveKey={'1'}
        items={items}
        onChange={(key: string) => setActiveTab(key)}
      /> */}
    </div>
  );
};

export default PaymentOffice;
