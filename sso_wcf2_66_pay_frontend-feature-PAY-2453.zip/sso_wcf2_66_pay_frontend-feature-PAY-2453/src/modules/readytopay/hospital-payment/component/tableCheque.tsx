'use client';
import React, { useState, useEffect, useRef } from 'react';
import {
  BaseButton,
  BaseItemDropdown,
  BaseItemInput,
  BaseItemInputNumber,
  BaseDialog,
} from 'wcf-component-lib/src/components';
import TableListLayout from 'wcf-component-lib/src/layout/TableListLayout';
import { BaseGrid, BaseItemDatePicker } from 'wcf-component-lib/src/components/v2';
import { ColumnsTypeCustom } from 'wcf-component-lib/src/components/v2/BaseGrid';
import { PlusOutlined } from '@ant-design/icons';
import { onlyNumberRule, requiredRule, minRule, maxRule } from 'wcf-component-lib/src/rules/FormRulesFunction';
import { Trash, CheckCircle, Edit, LogNoAccess, InfoCircle } from 'wcf-component-lib/node_modules/iconoir-react';

import { v4 as uuidv4 } from 'uuid';
import { useAppDispatch } from '@/store-redux/store';
import { useSelector } from 'react-redux';
import {
  TableChequeType,
  addChequeData,
  getChequeInfoListService,
  HospitalPaymentSelector,
} from '@/store-redux/slices/readytopay/hospital-payment.bk';
import isEqual from 'lodash/isEqual';

interface TableReceivePaymentProps {
  dataTestId: string;
}

export default function TableCheque({ dataTestId }: TableReceivePaymentProps): React.ReactElement {
  const [dataSource, setDataSource] = useState<TableChequeType[]>([]);
  const dispatch = useAppDispatch();
  const prevDataSourceRef = useRef<TableChequeType[]>(dataSource);
  const [isOpenDelect, setIsOpenDelect] = useState(false); //ยืนยันการลบรายการ
  const [paymentNoKey, setpaymentNoKey] = useState('');

  const {
    doctorSalaly: {
      tabs: {
        paymentOffice: { paymentActive, paymentForm },
      },
    },
  } = useSelector(HospitalPaymentSelector);

  console.log('paymentActive', paymentActive, paymentNoKey);

  //ดึงค่า รายการสั่งจ่าย
  useEffect(() => {
    // console.log('ดึงข้อมูล รายการสั่งจ่าย ครั้งแรก:', paymentForm.mode.view.paymentNo);

    if (paymentForm.mode.view.paymentNo) {
      setpaymentNoKey((prev) => {
        if (prev !== paymentForm.mode.view.paymentNo) {
          void dispatch(getChequeInfoListService(paymentForm.mode.view.paymentNo)); // ดึงค่าจาก API

          return paymentForm.mode.view.paymentNo;
        }

        return prev;
      });
    }
  }, [dispatch, paymentForm.mode.view.paymentNo]);

  //ดึงข้อมูลเช็คครั้งแรก
  useEffect(() => {
    //console.log('ดึงข้อมูล เช็ค ครั้งแรก', paymentForm.mode.view.tabs.cheque);
    if (paymentForm.mode.view.tabs?.cheque) {
      setDataSource(paymentForm.mode.view.tabs.cheque);
    }
  }, [paymentForm.mode.view.tabs?.cheque]);

  // console.log('dataSource:', dataSource);

  //เพิ่มข้อมูลเช็คเข้าไปเก็บใน store
  useEffect(() => {
    if (!isEqual(prevDataSourceRef.current, dataSource)) {
      prevDataSourceRef.current = dataSource; // อัปเดตค่า reference
      dispatch(addChequeData(dataSource));
    }
  }, [dataSource, dispatch]);

  // ฟังก์ชันอัปเดตข้อมูล เข้า DataSource
  const updateDataSource = (id: string, key: string, value: string | number | undefined): void => {
    const newData = dataSource.map((item) => {
      if (item.id === id) {
        return { ...item, [key]: value };
      }

      return item;
    });
    setDataSource(newData);
  };

  // ฟังก์ชันเพิ่มเช็คใหม่
  const addNewCheque = (): void => {
    if (paymentActive === 'view') return; // ป้องกันการเพิ่มเช็คเมื่ออยู่ในโหมด view
    const newCheque: TableChequeType = {
      id: uuidv4(),
      paymentNo: '',
      chequeNo: '',
      bankCode: '',
      bankName: '',
      bankAccountNo: '',
      bankAccountName: '',
      amount: 0,
      chequeStampDate: '',
      mode: 'add',
    };

    setDataSource([...dataSource, newCheque]);
  };

  // ฟังก์ชันลบเช็ค
  const removeCheque = (id: string): void => {
    const filteredData = dataSource.filter((item) => item.id !== id);
    setDataSource(filteredData);
  };

  //จัดการ mode เช็ค
  const updateMode = (id: string, mode: 'add' | 'edit' | 'view' | undefined): void => {
    //console.log('mode:', mode);
    const updatedData = dataSource.map((item) => (item.id === id ? { ...item, mode } : item));
    setDataSource(updatedData);
  };

  const handleCancel = (): void => {
    setIsOpenDelect(false);
  };

  const [delectId, setDelectId] = useState(''); //เก็บ id ที่ต้องการลบ

  //เตรียมลบข้อมูล
  const preConfirmDelect = (id: string): void => {
    // console.log('id:', id);
    setDelectId(id);
    setIsOpenDelect(true);
  };

  //ยืนยันลบข้อมูล
  const handleConfirm = (): void => {
    removeCheque(delectId);
    setIsOpenDelect(false);
  };

  const columns = [
    {
      title: 'ลำดับ',
      key: 'no',
      dataIndex: 'no',
      align: 'center',
      width: 50,
      render: (chequeNo: number, record: unknown, index: number): React.ReactElement => {
        return <span>{index + 1}</span>;
      },
    },
    {
      align: 'center',
      title: 'เลขที่เช็ค',
      key: 'chequeNo',
      dataIndex: 'chequeNo',
      render: (chequeNo: number, record: unknown): React.ReactElement => {
        const row = record as TableChequeType;
        //console.log('mode:', row.mode);

        if (row.mode === 'add' || row.mode === 'edit') {
          return (
            <div key={row.id}>
              <BaseItemInput
                id={`${dataTestId}-chequeNo-${row.id}-input-text`}
                itemName={[row.id.toString(), 'chequeNo']}
                value={row.chequeNo}
                rules={[
                  requiredRule('เลขที่เช็ค'),
                  onlyNumberRule('เลขที่เช็ค'),
                  minRule('เลขที่เช็ค', 8),
                  maxRule('เลขที่เช็ค', 8),
                ]}
                className='mt-[23px] bg-[#E7F3F5]'
                onChangeFunction={(e) => {
                  updateDataSource(row.id, 'chequeNo', e.target.value);
                }}
              />
            </div>
          );
        }

        return (
          <div key={row.id}>
            <span className='w-full text-center -mb-[24px]'>{chequeNo}</span>
          </div>
        );
      },
    },
    {
      align: 'center',
      title: 'ธนาคาร',
      key: 'bankCode',
      dataIndex: 'bankCode',
      render: (bankCode: number, record: unknown): React.ReactElement => {
        const row = record as TableChequeType;

        if (row.mode === 'add') {
          return (
            <div key={row.id}>
              <BaseItemDropdown
                id={`${dataTestId}-bankCode-${row.id}-selecter`}
                itemName={[row.id.toString(), 'bankCode']}
                option={[{ value: 1, label: 'ธนาคารกรุงเทพ', disabled: false }]}
                rules={[requiredRule('ธนาคาร')]}
                className='mt-[20px] custom-bg-color-blue'
                onChange={(e) => {
                  if (e !== undefined) {
                    updateDataSource(row.id, 'bankCode', e);
                  } else {
                    updateDataSource(row.id, 'bankCode', '');
                  }
                }}
              />
            </div>
          );
        }

        return (
          <div key={row.id}>
            <span className='w-full text-center -mb-[24px]'>{bankCode}</span>
          </div>
        );
      },
    },
    {
      align: 'center',
      title: 'จำนวนเงิน',
      key: 'amount',
      dataIndex: 'amount',
      render: (amount: number, record: unknown): React.ReactElement => {
        const row = record as TableChequeType;
        if (row.mode === 'add') {
          return (
            <div key={row.id}>
              <BaseItemInputNumber
                id={`${dataTestId}-amount-${row.id}-input-text`}
                itemName={[row.id.toString(), 'amount']}
                className='mt-[20px] w-full bg-[#E7F3F5]'
                hideFieldControl
                onChangeFunction={(e) => {
                  updateDataSource(row.id, 'amount', Number(e.target.value));
                }}
              />
            </div>
          );
        }

        return (
          <div key={row.id}>
            <span className='w-full text-center -mb-[24px]'>{amount.toLocaleString()}</span>
          </div>
        );
      },
    },
    {
      align: 'center',
      title: 'วันที่เช็ค',
      key: 'dateCheck',
      dataIndex: 'dateCheck',
      render: (dateCheck: number, record: unknown): React.ReactElement => {
        const row = record as TableChequeType;
        if (row.mode === 'add') {
          return (
            <div key={row.id}>
              <BaseItemDatePicker
                id={`${dataTestId}-dateCheck-${row.id}-input-date`}
                itemName={[row.id.toString(), 'dateCheck']}
                rules={[requiredRule('วันที่เช็ค')]}
                className='mt-[23px] bg-[#E7F3F5]'
                onChange={(e) => {
                  const date = e ? e.format('YYYY-MM-DD') : '';
                  updateDataSource(row.id, 'dateCheck', date);
                }}
              />
            </div>
          );
        }

        return (
          <div key={row.id}>
            <span className='w-full text-center -mb-[24px]'>{dateCheck}</span>
          </div>
        );
      },
    },
    {
      align: 'center',
      title: '',
      key: 'id',
      dataIndex: 'id',
      width: 50,
      render: (text: string, record: unknown): React.ReactElement => {
        const row = record as TableChequeType;

        // if (dataSource.length <= 1) {
        //   return (
        //     <div key={row.id} className='p-2 rounded-full bg-gray-100 cursor-not-allowed'>
        //       <Trash color='gray' />
        //     </div>
        //   );
        // }
        if (row.mode === 'add') {
          return (
            <div key={row.id} className='flex flex-row gap-2'>
              <div
                key={row.id}
                className='p-2 rounded-full bg-[#E7FAF2] cursor-pointer'
                onClick={() => updateMode(row.id, 'view')}
              >
                <CheckCircle color='green' />
              </div>
              <div
                key={row.id}
                className='p-2 rounded-full bg-[#F9EAEA] cursor-pointer'
                onClick={() => preConfirmDelect(row.id)}
              >
                <Trash color='red' />
              </div>
            </div>
          );
        }

        if (row.mode === 'view') {
          return (
            <div key={row.id} className='flex flex-row gap-2'>
              <div
                key={row.id}
                className='p-2 rounded-full bg-[#FFF9E5] cursor-pointer'
                onClick={() => updateMode(row.id, 'edit')}
              >
                <Edit color='#1C4651' />
              </div>
              <div
                key={row.id}
                className='p-2 rounded-full bg-[#F9EAEA] cursor-pointer'
                onClick={() => preConfirmDelect(row.id)}
              >
                <Trash color='red' />
              </div>
            </div>
          );
        }

        if (row.mode === 'edit') {
          return (
            <div key={row.id} className='flex flex-row gap-2'>
              <div
                key={row.id}
                className='p-2 rounded-full bg-[#E7FAF2] cursor-pointer'
                onClick={() => updateMode(row.id, 'view')}
              >
                <CheckCircle color='green' />
              </div>

              <div
                key={row.id}
                className='p-2 rounded-full bg-[#F9EAEA] cursor-pointer'
                onClick={() => updateMode(row.id, 'view')}
              >
                <LogNoAccess color='red' />
              </div>
            </div>
          );
        }

        return (
          <div key={row.id} className='flex flex-row justify-center gap-2'>
            <div
              key={row.id}
              className='p-2 rounded-full bg-[#F9EAEA] cursor-pointer'
              onClick={() => removeCheque(row.id)}
            >
              <Trash color='red' />
            </div>
          </div>
        );
      },
    },
  ];

  return (
    <>
      <div className='w-full flex flex-col p-6 bg-white shadow-sm rounded-xl'>
        <TableListLayout
          headTableContent={
            paymentActive !== 'view' && (
              <BaseButton
                size='middle'
                className='!min-w-[240px]'
                icon={<PlusOutlined />}
                label='เพิ่มเช็ค'
                onClick={addNewCheque}
              />
            )
          }
          textHeader='สั่งจ่ายโดย : เช็ค'
          totalItems={dataSource.length}
          type='form'
          firstLoading={dataSource.length === 0}
          emptyText='โปรดระบุข้อมูลที่ต้องการค้นหา'
          emptyDescription='ไม่มีข้อมูลที่ต้องการแสดงในขณะนี้'
          Grid={<BaseGrid bordered rows={dataSource} columns={columns as ColumnsTypeCustom} />}
        />
      </div>
      <BaseDialog
        width='560px'
        isOpen={isOpenDelect}
        setIsOpen={setIsOpenDelect}
        themeIcon='danger'
        content={
          <div className='flex flex-col w-full gap-4'>
            <div className='text-left font-semibold text-3xl'>ยืนยันการลบรายการ</div>
            <div className='text-left status text-[#4B5760]'>กรุณายืนยันการทำรายการอีกครั้ง</div>
          </div>
        }
        headerLeftIcon={<InfoCircle />}
        footer={
          <div className='flex justify-center gap-4'>
            <BaseButton size='middle' type='cancel' label='ยกเลิก' onClick={handleCancel} />
            <BaseButton size='middle' label='ยืนยัน' onClick={handleConfirm} />
          </div>
        }
      />
    </>
  );
}
