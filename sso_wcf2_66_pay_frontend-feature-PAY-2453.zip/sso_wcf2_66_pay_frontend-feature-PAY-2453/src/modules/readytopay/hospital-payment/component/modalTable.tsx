'use client';
import React, { useMemo, useEffect, useState, use } from 'react';
import { Checkbox } from 'wcf-component-lib/node_modules/antd';
import TableListLayout from 'wcf-component-lib/src/layout/TableListLayout';
import BaseGrid, { ColumnsTypeCustom } from 'wcf-component-lib/src/components/BaseGrid';
import { Refresh, Trash } from 'wcf-component-lib/node_modules/iconoir-react';
import { ReadyToPayDataType } from '@/store-redux/slices/readytopay/hospital-payment';
import { formatCurrency } from '@/utils/formatGeneral';
import { PayType } from '@/types/payType';
import { hospitalPaymentSelector } from '@/store-redux/slices/readytopay/hospital-payment';
import { useSelector } from 'react-redux';
import { Pagination } from 'wcf-component-lib/src/constants/interface';
import { FilterSearchType } from '@/store-redux/slices/readytopay/hospital-payment';
import { set } from 'lodash';

interface Props {
  dataTestId: string;
  tabActive: PayType;
  dataRows: ReadyToPayDataType[];
  filter: FilterSearchType;
  setFilter: (filter: FilterSearchType) => void;
  totalElements: number;
  callBackDataSelected: (data: ReadyToPayDataType[]) => void;
}

export default function ModalTable({
  dataTestId,
  tabActive,
  dataRows,
  filter,
  setFilter,
  totalElements,
  callBackDataSelected,
}: Props): React.ReactElement {
  const [dataSelected, setDataSelected] = useState<ReadyToPayDataType[]>([]);
  const [dataSelectedActiveTable, setDataSelectedActiveTable] = useState<ReadyToPayDataType[]>([]);
  const { pageForm } = useSelector(hospitalPaymentSelector);

  //set dataSelected from pageForm.tableList
  useEffect(() => {
    setDataSelected(pageForm.tableList);
  }, [pageForm.tableList]);

  //callback callBackDataSelected when dataSelected change
  useEffect(() => {
    callBackDataSelected(dataSelected);
  }, [dataSelected]);

  const columns: ColumnsTypeCustom = [
    {
      title: (
        <Checkbox
          checked={dataSelected.length === 10}
          onChange={(e) => {
            if (e.target.checked) {
              setDataSelected(dataSource);
            } else {
              setDataSelected([]);
            }
          }}
        />
      ),
      key: 'checkbox',
      dataIndex: 'paymentId',
      render: (paymentId: string, record: unknown): React.ReactElement => {
        const row = record as ReadyToPayDataType;

        const handleCheckboxChange = (checked: boolean, record: ReadyToPayDataType): void => {
          if (checked) {
            setDataSelected([...dataSelected, record]);
          } else {
            //remove item from dataSelected by record.value_2
            setDataSelected(dataSelected.filter((item) => item.paymentId !== record.paymentId));
          }
        };

        // find paymentId in dataSelected
        const isChecked = dataSelected.some((item) => item.paymentId === paymentId);

        return (
          <div className='flex justify-center'>
            <Checkbox
              checked={isChecked}
              value={paymentId}
              onChange={(e) => handleCheckboxChange(e.target.checked, row)} // เมื่อคลิก checkbox
            />
          </div>
        );
      },
    },
    {
      title: 'ลำดับ',
      key: 'no',
      dataIndex: 'no',
      align: 'center',
      width: 50,
      render: (chequeNo: number, record: unknown, index: number): React.ReactElement => {
        return <span>{index + 1}</span>;
      },
    },
    // tabActive === 'T' && {
    //   title: 'ธนาคาร',
    //   key: 'bankCode',
    //   dataIndex: 'bankCode',
    //   align: 'center',
    //   width: 250,
    //   render: (text: string, record: unknown): React.ReactElement => {
    //     const row = record as ReadyToPayDataType;

    //     return (
    //       <div className='flex justify-start'>
    //         {row.bank?.code} : {row.bank?.name}
    //       </div>
    //     );
    //   },
    // },
    {
      title: 'เลขที่ใบสั่งจ่าย',
      key: 'paymentNo',
      dataIndex: 'paymentNo',
      width: 150,
      align: 'center',
    },
    {
      title: 'ผู้มีสิทธิ์',
      key: 'hospital',
      dataIndex: 'hospital',
      width: 250,
      align: 'center',
      render: (hospital: string): React.ReactElement => {
        return <div className='flex justify-start'>{hospital}</div>;
      },
    },
    {
      title: 'เลขบัตรประชาชน',
      key: 'employeeCitizenId',
      dataIndex: 'employeeCitizenId',
      width: 200,
      align: 'center',
    },
    {
      title: 'เลขประสบอันตราย',
      key: 'accidentIssueCode',
      dataIndex: 'accidentIssueCode',
      width: 200,
      align: 'center',
    },
    {
      title: 'ผู้ประสบอันตราย',
      key: 'fullName',
      dataIndex: 'fullName',
      width: 250,
      align: 'center',
      render: (fullName: string): React.ReactElement => {
        return <div className='flex justify-start'>{fullName}</div>;
      },
    },

    {
      title: 'จำนวนเงิน',
      key: 'amount',
      dataIndex: 'amount',
      sorter: true,
      align: 'center',
      width: 250,
      render: (amount: number): React.ReactElement => {
        return <span className='w-full flex justify-end'>{formatCurrency(Number(amount))}</span>;
      },
    },
  ];

  const SelectedItems = (): React.ReactElement => {
    const onRemove = (item: string): void => {
      //remove item from dataSelected by item paymentId
      setDataSelected(dataSelected.filter((data) => data.paymentId !== item));
    };

    return (
      <div className='flex flex-wrap gap-2'>
        {dataSelected.map((item, index) => (
          <div key={index} className='flex gap-2 flex-row'>
            <div
              className={`flex flex-row items-center select-none ${
                dataSelectedActiveTable.includes(item) ? 'bg-[#1c4651] text-[#E6EFF5]' : 'bg-[#d3e1e4] text-[#1c4651]'
              } gap-2 p-2 px-4 rounded-xl`}
            >
              <p
                className='cursor-pointer'
                onClick={() => {
                  //check if item is in array dataSelectedActiveTable or not then remove item from dataSelectedActiveTable
                  if (dataSelectedActiveTable.includes(item)) {
                    setDataSelectedActiveTable(dataSelectedActiveTable.filter((data) => data !== item));
                  } else {
                    //add item to dataSelectedActiveTable
                    setDataSelectedActiveTable([...dataSelectedActiveTable, item]);
                  }
                }}
              >
                {item.paymentId}
              </p>
              <button className='rounded-full p-1 bg-[#F9EAEA] text-[#C42828]' onClick={() => onRemove(item.paymentId)}>
                <Trash className='text-xs' />
              </button>
            </div>
          </div>
        ))}
      </div>
    );
  };

  const dataSource = useMemo(() => {
    return dataRows;
  }, [dataRows]);

  return (
    <div className='w-full flex flex-col gap-4'>
      <div className='w-full'>
        <TableListLayout
          textHeader='ผลลัพธ์การค้นหา'
          type='form'
          firstLoading={dataSource.length === 0}
          totalItems={totalElements}
          emptyText='โปรดระบุข้อมูลที่ต้องการค้นหา'
          Grid={
            <div>
              <div className='p-3 rounded-xl bg-white border mb-4 -mt-2 flex gap-2'>
                <div className='flex flex-row justify-start items-center gap-2 mr-auto '>
                  <div className='w-[100px]'>รายการที่เลือก</div>
                  <SelectedItems />
                </div>
                <div className='flex w-[120px] justify-end'>
                  <button
                    className='flex flex-row justify-end items-start gap-2 p-2 text-[#C42828]'
                    onClick={() => {
                      setDataSelected([]);
                      setDataSelectedActiveTable([]);
                    }}
                  >
                    <Refresh className='text-sm' /> ล้างทั้งหมด
                  </button>
                </div>
              </div>

              <BaseGrid
                rowKey='paymentId'
                rows={dataSelectedActiveTable.length > 0 ? dataSelectedActiveTable : dataSource}
                columns={columns}
                page={{
                  pageNumber: filter.pagination.pageNumber,
                  pageSize: filter.pagination.pageSize,
                  totalData: totalElements,
                  orders: filter.pagination.orders,
                }}
                orderActive={filter.pagination.orders}
                setOrder={(orders) => {
                  setFilter({ ...filter, pagination: { ...filter.pagination, orders } });
                }}
                setPagination={({ pageNumber, pageSize }) => {
                  setFilter({ ...filter, pagination: { ...filter.pagination, pageNumber, pageSize } });
                }}
                isHaveBorderBottomLeftRight
              />
            </div>
          }
        />
      </div>
    </div>
  );
}
