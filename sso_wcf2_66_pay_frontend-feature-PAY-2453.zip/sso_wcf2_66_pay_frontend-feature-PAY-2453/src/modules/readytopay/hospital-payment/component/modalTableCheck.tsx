'use client';
import React, { useState } from 'react';
import { Checkbox } from 'wcf-component-lib/node_modules/antd';
import TableListLayout from 'wcf-component-lib/src/layout/TableListLayout';
import BaseGrid, { ColumnsTypeCustom } from 'wcf-component-lib/src/components/BaseGrid';
import { Refresh, Trash } from 'wcf-component-lib/node_modules/iconoir-react';

interface DataSourceType {
  key: number;
  value_1: string;
  value_2: string;
  value_3: string;
  value_4: string;
  value_5: string;
  value_6: string;
}
interface ModalTableProps {
  hideBankColumn?: boolean;
  dataTestId: string;
}

const DATA_MOCK: DataSourceType[] = [
  // ตัวอย่างข้อมูล
  {
    key: 1,
    value_1: '006 : กรุงไทย จำกัด (มหาชน)',
    value_2: '00000001',
    value_3: '10001:โรงพยาบาลกรุงเทพ',
    value_4: '100764/0128602/02',
    value_5: 'นพดล สุขใจดี',
    value_6: '1,200,000.00',
  },
  {
    key: 2,
    value_1: '006 : กรุงไทย จำกัด (มหาชน)',
    value_2: '00000002',
    value_3: '10001:โรงพยาบาลกรุงเทพ',
    value_4: '100764/0128602/02',
    value_5: 'กาญจนา พิเศษ',
    value_6: '1,500,000.00',
  },
  {
    key: 3,
    value_1: '006 : กรุงไทย จำกัด (มหาชน)',
    value_2: '00000003',
    value_3: '10001:โรงพยาบาลกรุงเทพ',
    value_4: '100764/0128602/02',
    value_5: 'กาญจนา พิเศษ',
    value_6: '1,500,000.00',
  },
  {
    key: 4,
    value_1: '006 : กรุงไทย จำกัด (มหาชน)',
    value_2: '00000004',
    value_3: '10001:โรงพยาบาลกรุงเทพ',
    value_4: '100764/0128602/02',
    value_5: 'กาญจนา พิเศษ',
    value_6: '1,500,000.00',
  },
  {
    key: 5,
    value_1: '006 : กรุงไทย จำกัด (มหาชน)',
    value_2: '00000005',
    value_3: '10001:โรงพยาบาลกรุงเทพ',
    value_4: '100764/0128602/02',
    value_5: 'กาญจนา พิเศษ',
    value_6: '1,500,000.00',
  },
  {
    key: 6,
    value_1: '006 : กรุงไทย จำกัด (มหาชน)',
    value_2: '00000006',
    value_3: '10001:โรงพยาบาลกรุงเทพ',
    value_4: '100764/0128602/02',
    value_5: 'กาญจนา พิเศษ',
    value_6: '1,500,000.00',
  },
  {
    key: 7,
    value_1: '006 : กรุงไทย จำกัด (มหาชน)',
    value_2: '00000007',
    value_3: '10001:โรงพยาบาลกรุงเทพ',
    value_4: '100764/0128602/02',
    value_5: 'กาญจนา พิเศษ',
    value_6: '1,500,000.00',
  },
  {
    key: 8,
    value_1: '006 : กรุงไทย จำกัด (มหาชน)',
    value_2: '00000008',
    value_3: '10001:โรงพยาบาลกรุงเทพ',
    value_4: '100764/0128602/02',
    value_5: 'กาญจนา พิเศษ',
    value_6: '1,500,000.00',
  },
  {
    key: 9,
    value_1: '006 : กรุงไทย จำกัด (มหาชน)',
    value_2: '00000009',
    value_3: '10001:โรงพยาบาลกรุงเทพ',
    value_4: '100764/0128602/02',
    value_5: 'กาญจนา พิเศษ',
    value_6: '1,500,000.00',
  },
  {
    key: 10,
    value_1: '006 : กรุงไทย จำกัด (มหาชน)',
    value_2: '00000010',
    value_3: '10001:โรงพยาบาลกรุงเทพ',
    value_4: '100764/0128602/02',
    value_5: 'กาญจนา พิเศษ',
    value_6: '1,500,000.00',
  },
];

export default function ModalTable({ hideBankColumn = false }: ModalTableProps): React.ReactElement {
  const [dataSource] = useState<DataSourceType[]>(DATA_MOCK);
  const [dataSelected, setDataSelected] = useState<DataSourceType[]>([]);
  const [dataSelectedActiveTable, setDataSelectedActiveTable] = useState<DataSourceType[]>([]);

  const columns = [
    {
      title: (
        <Checkbox
          checked={dataSelected.length === 10}
          onChange={(e) => {
            if (e.target.checked) {
              setDataSelected(dataSource);
            } else {
              setDataSelected([]);
            }
          }}
        />
      ),
      key: 'checkbox',
      dataIndex: 'paymentOrder',
      render: (paymentOrder: string, record: unknown): React.ReactElement => {
        const handleCheckboxChange = (checked: boolean, record: DataSourceType): void => {
          if (checked) {
            setDataSelected([...dataSelected, record]);
          } else {
            //remove item from dataSelected by record.value_2
            setDataSelected(dataSelected.filter((item) => item.value_2 !== record.value_2));
          }
        };

        // ตรวจสอบว่า record นี้ถูกเลือกหรือไม่
        const isChecked = dataSelected.includes(record as DataSourceType);

        return (
          <div className='flex justify-center'>
            <Checkbox
              checked={isChecked}
              value={paymentOrder}
              onChange={(e) => handleCheckboxChange(e.target.checked, record as DataSourceType)} // เมื่อคลิก checkbox
            />
          </div>
        );
      },
    },
    {
      title: 'ลำดับ',
      key: 'no',
      dataIndex: 'no',
      align: 'center',
      width: 50,
      render: (chequeNo: number, record: unknown, index: number): React.ReactElement => {
        return <span>{index + 1}</span>;
      },
    },
    !hideBankColumn && {
      title: 'ธนาคาร',
      key: 'value_1',
      dataIndex: 'value_1',
      align: 'center',
    },
    {
      title: 'เลขที่ใบสั่งจ่าย',
      key: 'value_2',
      dataIndex: 'value_2',
      align: 'center',
    },
    {
      title: 'ผู้มีสิทธิ์',
      key: 'value_3',
      dataIndex: 'value_3',
      align: 'center',
    },
    {
      title: 'เลขประสบอันตราย',
      key: 'value_4',
      dataIndex: 'value_4',
      align: 'center',
    },
    {
      title: 'ผู้ประสบอันตราย',
      key: 'value_5',
      dataIndex: 'value_5',
    },
    {
      title: 'จำนวนเงิน',
      key: 'value_6',
      dataIndex: 'value_6',
      align: 'right',
      sorter: true,
    },
  ].filter(Boolean);

  const SelectedItems = (): React.ReactElement => {
    const onRemove = (item: string): void => {
      //remove item from dataSelected by item value_2
      setDataSelected(dataSelected.filter((data) => data.value_2 !== item));
    };

    return (
      <div className='flex flex-wrap gap-2'>
        {dataSelected.map((item, index) => (
          <div key={index} className='flex gap-2 flex-row'>
            <div
              className={`flex flex-row items-center select-none ${
                dataSelectedActiveTable.includes(item) ? 'bg-[#1c4651] text-[#E6EFF5]' : 'bg-[#d3e1e4] text-[#1c4651]'
              } gap-2 p-2 rounded-xl`}
            >
              <p
                className='cursor-pointer'
                onClick={() => {
                  //check if item is in array dataSelectedActiveTable or not then remove item from dataSelectedActiveTable
                  if (dataSelectedActiveTable.includes(item)) {
                    setDataSelectedActiveTable(dataSelectedActiveTable.filter((data) => data !== item));
                  } else {
                    //add item to dataSelectedActiveTable
                    setDataSelectedActiveTable([...dataSelectedActiveTable, item]);
                  }
                }}
              >
                {item.value_2}
              </p>
              <div className='rounded-full p-1 bg-[#F9EAEA] text-[#C42828]' onClick={() => onRemove(item.value_2)}>
                <Trash className='text-xs' />
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  };

  return (
    <div className='w-full flex flex-col gap-4'>
      <div className='w-full'>
        <TableListLayout
          textHeader='ผลลัพธ์การค้นหา'
          type='form'
          firstLoading={dataSource.length === 0}
          totalItems={dataSource.length}
          emptyText='โปรดระบุข้อมูลที่ต้องการค้นหา'
          Grid={
            <div>
              <div className='p-3 rounded-xl bg-white border mb-4 -mt-2 flex gap-2'>
                <div className='flex flex-row justify-start items-center gap-2 mr-auto '>
                  <div className='w-[100px]'>รายการที่เลือก</div>
                  <SelectedItems />
                </div>
                <div className='flex w-[120px] justify-end'>
                  <button
                    className='flex flex-row justify-end items-start gap-2 p-2 text-[#C42828]'
                    onClick={() => {
                      setDataSelected([]);
                      setDataSelectedActiveTable([]);
                    }}
                  >
                    <Refresh className='text-sm' /> ล้างทั้งหมด
                  </button>
                </div>
              </div>
              <BaseGrid
                rows={dataSelectedActiveTable.length > 0 ? dataSelectedActiveTable : dataSource}
                columns={columns as ColumnsTypeCustom}
                page={{
                  pageNumber: 0,
                  pageSize: 10,
                  totalData: 11,
                }}
                isHaveBorderBottomLeftRight={true}
              />
            </div>
          }
        />
      </div>
    </div>
  );
}
