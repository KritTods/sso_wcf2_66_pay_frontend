import React from 'react';
import BaseGrid, { ColumnsTypeCustom } from 'wcf-component-lib/src/components/BaseGrid';
import TableListLayout from 'wcf-component-lib/src/layout/TableListLayout';
import { BaseForm } from 'wcf-component-lib/src/components';

const CardCheque: React.FC = () => {
  const columns = [
    {
      title: 'ลำดับ',
      key: 'no',
      dataIndex: 'no',
      align: 'center',
      width: 50,
      render: (chequeNo: number, record: unknown, index: number): React.ReactElement => {
        return <span>{index + 1}</span>;
      },
    },
    {
      title: 'เลขที่เช็ค',
      key: 'value_2',
      dataIndex: 'value_2',
      align: 'center',
    },
    {
      title: 'ธนาคาร',
      key: 'value_3',
      dataIndex: 'value_3',
      align: 'center',
      render: (text: string): React.ReactElement => {
        return <span className='w-full text-left'>{text}</span>;
      },
    },
    {
      title: 'จำนวนเงิน',
      key: 'value_4',
      dataIndex: 'value_4',
      align: 'right',
    },
    {
      title: 'วันที่เช็ค',
      key: 'value_5',
      dataIndex: 'value_5',
      align: 'center',
    },
  ];

  const dataSource = [
    {
      key: '1',
      value_1: '1',
      value_2: '81020094',
      value_3: '006:กรุงไทย จำกัด(มหาชน)',
      value_4: '20,000.00',
      value_5: '31/12/2567',
    },
  ];

  return (
    <div>
      <BaseForm>
        <div className='flex flex-col items-center'>
          <div className='w-full bg-white p-6 shadow-sm rounded-xl relative'>
            <TableListLayout
              textHeader='เช็ค'
              type='form'
              totalItems={dataSource.length}
              Grid={<BaseGrid rows={dataSource} columns={columns as ColumnsTypeCustom} />}
            />
          </div>
        </div>
      </BaseForm>
    </div>
  );
};

export default CardCheque;
