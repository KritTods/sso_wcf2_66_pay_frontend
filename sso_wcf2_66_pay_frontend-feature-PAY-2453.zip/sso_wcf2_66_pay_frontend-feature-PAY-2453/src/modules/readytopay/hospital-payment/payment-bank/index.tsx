'use client';
import React, { useState } from 'react';
import { Row, Col, Form } from 'wcf-component-lib/node_modules/antd';
import { formColumn } from '@/constants/layoutColumn';
import { InfoCircle } from 'wcf-component-lib/node_modules/iconoir-react';
import TableCheck from '@/modules/readytopay/hospital-payment/component/tableCheque';
import { BaseForm, BaseButton, BaseDialog, BaseToastNotification, BaseIcon } from 'wcf-component-lib/src/components';
import { URL } from '@/constants/configPage';
import { useRouter } from 'next/navigation';
// import TablePaymentRequest from '@/modules/readytopay/hospital-payment/component/tablePaymentRequest';
import { useSelector } from 'react-redux';
import { hospitalPaymentSelector } from '@/store-redux/slices/readytopay/hospital-payment';

export default function PaymentBankForm(): React.JSX.Element {
  const [form] = Form.useForm();
  const router = useRouter();
  const [isOpenConfirmModal, setIsOpenConfirmModal] = useState(false); //บันทึกข้อมูลใช่หรือไม่?
  const [isOpenAddRow, setIsOpenAddRow] = useState(false); //กรุณาเพิ่มเช็คอย่างน้อย 1 รายการ
  const [isOpenOverPrice, setIsOpenOverPrice] = useState(false); //จำนวนเงินไม่สอดคล้อง

  // const {} = useSelector(hospitalPaymentSelector);

  return (
    <div className='flex flex-col gap-4 mx-5'>
      <div className='w-full bg-white p-6 shadow-sm rounded-xl'>
        <div className='flex flex-col gap-4'>
          <p className='header-card'> รายละเอียด</p>
          <Row gutter={[16, 16]}>
            <Col {...formColumn}>
              <div>
                <p className='text-label-info'>เลขที่เอกสาร</p>
                <p className='text-display'>-</p>
              </div>
            </Col>
            <Col {...formColumn}>
              <div>
                <p className='text-label-info'>ผู้เตรียมจ่าย</p>
                <p className='text-display'>กาญจนา พิเศษ</p>
              </div>
            </Col>
            <Col {...formColumn}>
              <div>
                <p className='text-label-info'>วันที่เตรียมจ่าย</p>
                <p className='text-display'>31/12/2567</p>
              </div>
            </Col>
            <Col {...formColumn}>
              <div>
                <p className='text-label-info'>วิธีการชำระเงิน</p>
                <p className='text-display'>โอนผ่านธนาคารโดยจังหวัด</p>
              </div>
            </Col>
          </Row>
        </div>
      </div>
      {/* Table รายการสั่งจ่าย */}
    </div>
  );
}
