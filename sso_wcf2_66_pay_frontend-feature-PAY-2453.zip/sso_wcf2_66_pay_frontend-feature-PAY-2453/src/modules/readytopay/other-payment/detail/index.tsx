'use client';
import React, { useEffect, useState, useMemo } from 'react';
import { Col, Row, Form } from 'wcf-component-lib/node_modules/antd';
import { BaseButton, BaseForm, BaseItemTextArea, BaseLoading } from 'wcf-component-lib/src/components';
import { formColumn } from '@/constants/layoutColumn';
import { URL } from '@/constants/configPage';
import { useRouter, useSearchParams } from 'next/navigation';
import { PrinterOutlined } from '@ant-design/icons';
import { useSelector } from 'react-redux';
import { otherPaymentSelector, setPageOtherPaymentDetail } from '@/store-redux/slices/readytopay/other-pament';
import { statusPayType } from '@/constants/statusSystem';
import { useAppDispatch } from '@/store-redux/store';
import { PayType } from '@/types/payType';
import { formatCurrency } from '@/utils/formatGeneral';
import TableCheque from '@/components/common/tableCheque';
import TableBank from '@/components/common/tableBank';
import { maxRule, requiredRule } from 'wcf-component-lib/src/rules/FormRulesFunction';
import TableMoney from '@/components/common/tableMoney';

export default function OtherPaymentDetail(): React.ReactElement {
  const dataTestId = 'pageOtherPaymentDetail';
  const searchParams = useSearchParams();
  const id = searchParams.get('id');
  const router = useRouter();
  const { loading, pageOtherPaymentDetail } = useSelector(otherPaymentSelector);
  const dispatch = useAppDispatch();
  const [form] = Form.useForm();
  const [mode, setMode] = useState<'view' | 'edit'>();

  useEffect(() => {
    if (!id) return;
    // Call API Thunks
    //  void dispatch(getPrepareBudgetService(prepareBudgetRequestId));

    void dispatch(
      setPageOtherPaymentDetail({
        ...pageOtherPaymentDetail,
        isCheque: true,
        cheques: [
          {
            id: '1',
            chequeNo: '00000001',
            bankCode: '006',
            bankBranchCode: '0001',
            amount: 5000,
            chequeStampDate: '2024-12-31',
            mode: 'view',
          },
          {
            id: '2',
            chequeNo: '00000001',
            bankCode: '006',
            bankBranchCode: '0001',
            amount: 5000,
            chequeStampDate: '2024-12-31',
            mode: 'view',
          },
        ],
        banks: [
          {
            id: '1',
            bankCode: '006',
            bankAccountName: 'กสิกรไทย',
            bankAccountNo: '0001000011',
            amount: 1000,
            mode: 'view',
          },
        ],
        moneys: [
          {
            id: '1',
            postalNo: '00000001',
            portalDestination: 'นนทบุรี',
            postalCode: '0001',
            receiverName: 'นิรันรัตน์ เทศกาล',
            amount: 3000,
            mode: 'view',
          },
        ],
        address: '54 ถนนลาดพร้าว แขวงจอมพล เขตจตุจักร กรุงเทพมหานคร 10900',
        cash: 10000,
        documentNo: 'P000167000001E1',
        paymentNo: 'J000167000001E1',
        paymentAgent: 'กาญจนา พิเศษ',
        transactionDate: '2024-12-31',
        payType: 'S',
        receiverName: 'กาญจนา พิเศษ',
        bookNo: 'รง0615/สท884',
        paymentType: 'โอนเงินเกินเข้าชำระหนี้เงินสมทบ กองทุนประกันสังคม',
      }),
    );

    // first load set mode view
    setMode('view');
  }, [dispatch, id]);

  useEffect(() => {
    //check mode is undefined end process
    if (!mode) return;

    if (mode === 'edit') {
      void dispatch(
        setPageOtherPaymentDetail({
          ...pageOtherPaymentDetail,

          chequesEdit: pageOtherPaymentDetail.cheques.map((cheque) => ({
            ...cheque,
            mode: 'edit',
          })),
          banksEdit: pageOtherPaymentDetail.banks.map((bank) => ({
            ...bank,
            mode: 'edit',
          })),
          moneysEdit: pageOtherPaymentDetail.moneys.map((money) => ({
            ...money,
            mode: 'edit',
          })),
        }),
      );
    } else {
      //reset modeEdit clear data when cancel mode edit
      void dispatch(
        setPageOtherPaymentDetail({
          ...pageOtherPaymentDetail,
          chequesEdit: [],
          banksEdit: [],
          moneysEdit: [],
        }),
      );
    }
  }, [dispatch, mode]);

  const data = useMemo(() => {
    return pageOtherPaymentDetail;
  }, [pageOtherPaymentDetail]);

  //loading form
  if (loading) {
    return <BaseLoading size='default' />;
  }

  //add loading firstload

  const onFinish = (values: any) => {
    console.log('onFinish: ', values);
  };

  return (
    <BaseForm name='other-payment-form-T' onFinish={onFinish} extraForm={form} initialValues={data}>
      <div className='flex flex-col mx-4 gap-4 mb-6'>
        <div className='w-full bg-white p-6 shadow-sm rounded-xl'>
          <div className='flex flex-col gap-4'>
            <p className='header-card'>รายละเอียดบันทึกจ่ายเงินประเภทอื่น</p>
            <Row gutter={[16, 16]}>
              <Col {...formColumn}>
                <div>
                  <p className='text-label-info'>เลขที่เอกสาร</p>
                  <p className='text-display'>{data.documentNo}</p>
                </div>
              </Col>
              <Col {...formColumn}>
                <div>
                  <p className='text-label-info'>เลขที่คำสั่งจ่าย</p>
                  <p className='text-display'>{data.paymentNo}</p>
                </div>
              </Col>
              <Col {...formColumn}>
                <div>
                  <p className='text-label-info'>ผู้เตรียมจ่าย</p>
                  <p className='text-display'>{data.paymentAgent}</p>
                </div>
              </Col>
              <Col {...formColumn}>
                <div>
                  <p className='text-label-info'>วันที่เตรียมจ่าย</p>
                  <p className='text-display'>{data.transactionDate}</p>
                </div>
              </Col>
              <Col {...formColumn}>
                <div>
                  <p className='text-label-info'>วิธีการชำระเงิน</p>
                  <p className='text-display'>{statusPayType[data.payType as PayType]}</p>
                </div>
              </Col>
              <Col {...formColumn}>
                <div>
                  <p className='text-label-info'>เลขที่หนังสือ รง.</p>
                  <p className='text-display'>{data.bookNo}</p>
                </div>
              </Col>
              <Col {...formColumn}>
                <div>
                  <p className='text-label-info'>ชื่อผู้มีสิทธิ์</p>
                  <p className='text-display'>{data.receiverName}</p>
                </div>
              </Col>
              <Col {...formColumn}>
                <div>
                  <p className='text-label-info'>ประเภทการจ่ายนอกระบบ</p>
                  <p className='text-display'>{data.paymentType}</p>
                </div>
              </Col>
            </Row>
          </div>
        </div>

        {/* //section address case ส่งเช็คทางไปรณษีย์ */}
        {data.payType === 'S' && (
          <div className='w-full bg-white shadow-sm rounded-xl flex flex-col gap-4 p-6'>
            <p className='header-card'>ส่งเช็คทางไปรษณีย์</p>
            <div className='w-full'>
              {mode === 'view' && (
                <div>
                  <p className='text-label-info'>ที่อยู่</p>
                  <p className='text-display'>{data.address}</p>
                </div>
              )}
              {mode === 'edit' && (
                <BaseItemTextArea
                  id={`${dataTestId}-input-textarea`}
                  itemName='address'
                  label='ที่อยู่'
                  rules={[requiredRule('ที่อยู่'), maxRule('ที่อยู่', 400)]}
                />
              )}
            </div>
          </div>
        )}

        {/* //section cash */}
        {!data.isCheque && (
          <div className='w-full bg-white p-6 shadow-sm rounded-xl'>
            <div className='flex flex-col gap-4'>
              <p className='header-card'>สั่งจ่ายโดย : เงินสด</p>
              <Row gutter={[16, 16]}>
                <Col {...formColumn}>
                  <p className='text-label-info'>จำนวนเงิน (บาท)</p>
                </Col>
                <Col {...formColumn}>
                  <p className='text-display'>{formatCurrency(data.cash)}</p>
                </Col>
              </Row>
            </div>
          </div>
        )}

        {/* //section bank แสดงเฉพาะ โอนผ่านธนาคารโดยจังหวัด */}
        {data.payType === 'T' && form && (
          <div className='bg-white rounded-xl'>
            <Form.List name='banks'>
              {(_, { add, remove }) => {
                return (
                  <>
                    <TableBank
                      itemName={mode === 'view' ? 'banks' : 'banksEdit'}
                      form={form}
                      add={add}
                      remove={remove}
                      mode={mode}
                      dataTestId={dataTestId}
                      onChange={(data) => {
                        // console.log('data change: ', data);
                        // console.log('BaseForm : ', form.getFieldValue('cheques'));
                      }}
                    />
                  </>
                );
              }}
            </Form.List>
          </div>
        )}

        {/* //section cheque */}
        {data.isCheque && form && (
          <div className='bg-white rounded-xl'>
            <Form.List name={mode === 'view' ? 'cheques' : 'chequesEdit'}>
              {(_, { add, remove }) => {
                return (
                  <>
                    <TableCheque
                      itemName={mode === 'view' ? 'cheques' : 'chequesEdit'}
                      form={form}
                      add={add}
                      remove={remove}
                      mode={mode}
                      dataTestId={dataTestId}
                      onChange={(data) => {
                        // console.log('data change: ', data);
                        // console.log('BaseForm : ', form.getFieldValue('cheques'));
                      }}
                    />
                  </>
                );
              }}
            </Form.List>
          </div>
        )}

        {/* //section money แสดงเฉพาะ ธนาณัติ */}
        {data.payType === 'P' && form && (
          <div className='bg-white rounded-xl'>
            <Form.List name={mode === 'view' ? 'moneys' : 'moneysEdit'}>
              {(_, { add, remove }) => {
                return (
                  <>
                    <TableMoney
                      itemName={mode === 'view' ? 'moneys' : 'moneysEdit'}
                      form={form}
                      add={add}
                      remove={remove}
                      mode={mode}
                      dataTestId={dataTestId}
                    />
                  </>
                );
              }}
            </Form.List>
          </div>
        )}

        {/* //section button footer */}
        {mode === 'view' && (
          <div className='flex justify-center items-center gap-4'>
            <BaseButton
              type='cancel'
              size='large'
              label='ยกเลิก'
              onClick={() => router.push(URL.readytopay.otherPayment.url)}
            />

            {(data.isCheque || data.payType === 'P') && (
              <>
                <BaseButton
                  size='large'
                  label='แก้ไข'
                  className='border border-[#1C4651]'
                  onClick={() => {
                    setMode('edit');
                  }}
                  type='default'
                />
              </>
            )}

            {/* //แสดงเฉพาะ ธนาณัติ */}
            {data.isCheque && data.payType === 'P' && (
              <BaseButton
                size='large'
                label='Export ไปยัง Post App'
                className='w-[280px]'
                onClick={() => console.log('Export ไปยัง Post App')}
              />
            )}

            <BaseButton
              type='primary'
              size='large'
              label='ตัดจ่าย'
              className='bg-[#dedede] hover:bg-red-500'
              onClick={() => {
                console.log('ตัดจ่าย');
                // router.push(URL.readytopay.otherPayment.url);
              }}
            />

            {data.isCheque && (
              <>
                <BaseButton
                  size='large'
                  label='พิมพ์หนังสือลงนามในเช็ค'
                  className='w-[280px]'
                  icon={<PrinterOutlined />}
                  onClick={() => console.log('print')}
                />
              </>
            )}
          </div>
        )}
        {mode === 'edit' && (
          <div className='flex justify-center items-center gap-4'>
            <BaseButton
              type='cancel'
              size='large'
              label='ยกเลิก'
              onClick={() => {
                setMode('view');
              }}
            />

            <BaseButton
              type='primary'
              size='large'
              label='บันทึกข้อมูล'
              className='w-[240px]'
              htmlType='submit'
              onClick={() => form.submit()}
            />
          </div>
        )}
      </div>
    </BaseForm>
  );
}
