'use client';
import React, { useState, useEffect, useMemo } from 'react';
import {
  BaseButton,
  BaseDialog,
  BaseForm,
  BaseItemDateRangePicker,
  BaseItemDropdown,
  BaseItemInput,
} from 'wcf-component-lib/src/components';
import ModalTable from '@/modules/readytopay/doctor-salary/component/modalTable';
import { Col, Row, Radio, FormProps, RadioChangeEvent } from 'wcf-component-lib/node_modules/antd';
import { searchColumn } from '@/constants/layoutColumn';
import { minRule, maxRule, onlyNumberRule, requiredRule } from 'wcf-component-lib/src/rules/FormRulesFunction';
import { SearchOutlined } from '@ant-design/icons';
import { useAppDispatch } from '@/store-redux/store';
import { useSelector } from 'react-redux';
import {
  readyToPayDoctorSalarySelector,
  FilterSearchType,
  ReadyToPayDataType,
  initialFilter,
  getDoctorSalalyListService,
  GetFilterListServiceType,
  setPagePaymentForm,
} from '@/store-redux/slices/readytopay/doctor-salary';
import { PayloadAction } from '@reduxjs/toolkit';
import { PayType } from '@/types/payType';
import { SelectData } from 'wcf-component-lib/src/constants/interface';
import { BankItem, getBankList, bankSelector } from '@/redux/slices/mdm/bank';
interface DataProps {
  isOpenModal: boolean;
  setOpenModal: (isOpenModal: boolean) => void;
  dataTestId: string;
  tabActive: PayType;
}

export default function ModalPaymentOrder(props: DataProps): React.ReactElement {
  const dispatch = useAppDispatch();
  const [filter, setFilter] = useState<FilterSearchType>(initialFilter);
  const [filterResult, setFilterResult] = useState<ReadyToPayDataType[]>([]);
  const [totalElements, setTotalElements] = useState<number>(0);
  const { pageDoctorSalalyForm } = useSelector(readyToPayDoctorSalarySelector);
  const [dataSelected, setDataSelected] = useState<ReadyToPayDataType[]>([]);

  // ใช้ useSelector ภายในฟังก์ชัน component
  const { list: bankList } = useSelector(bankSelector);

  useEffect(() => {
    void dispatch(
      getBankList({
        data: {
          pagination: {
            pageNumber: 0,
            pageSize: 10000,
            orders: [
              {
                direction: 'DESC',
                property: 'bankCode',
              },
            ],
          },
        },
      }),
    );
  }, [dispatch]);

  const bankSelectData = useMemo(() => {
    const result: SelectData[] = [];
    bankList.map((e: BankItem) => {
      result.push({
        value: e.bankCode,
        label: `${e.bankCode} : ${e.bankName}`,
      });
    });

    return result;
  }, [bankList]);
  // console.log('filter', filter);
  useEffect(() => {
    const fetchData = async (): Promise<void> => {
      const resFilter = (await dispatch(getDoctorSalalyListService(filter))) as PayloadAction<GetFilterListServiceType>;
      if (resFilter) {
        setFilterResult(resFilter.payload.content as ReadyToPayDataType[]);
        setTotalElements(resFilter.payload.totalElements);
      }
    };

    void fetchData();
  }, [filter]);

  const handleConfirmCreateModal = (): void => {
    //close modal
    props.setOpenModal(false);
    //initFilter
    setFilter(initialFilter);
    //update dataSelected to slice pageForm.tableList
    void dispatch(setPagePaymentForm({ ...pageDoctorSalalyForm, selectList: dataSelected }));
  };

  const [valueRadio, setValueRadio] = useState<string | number>('1');

  const onChangeRadio = (e: RadioChangeEvent): void => {
    const value = e.target.value as string | number; // Explicitly cast the value type
    //console.log('radio checked', value);
    setValueRadio(value);
  };
  const onFinish: FormProps<FilterSearchType>['onFinish'] = (values) => {
    const searchObj = {
      paymentNo: values.paymentNo,
      payToCode: valueRadio,
      payType: props.tabActive,
      accidentIssueCode: values.accidentIssueCode,
      date: values.date,
      hospitalLikeField: values.hospitalLikeField,
      bankCode: values.bankCode,
      fullName: values.fullName,
      employeeCitizenId: values.employeeCitizenId,
      operation: 'AND',
      pagination: {
        pageNumber: filter.pagination.pageNumber,
        pageSize: filter.pagination.pageSize,
        orders: [
          {
            direction: 'ASC',
            property: 'compensationPerPerson',
          },
        ],
      },
    };
    console.log('searchObj', searchObj);
    //updata filter state
    setFilter(searchObj);
  };

  return (
    <BaseDialog
      width='1500px'
      isOpen={props.isOpenModal}
      setIsOpen={props.setOpenModal}
      headerContent={<p className='page-title pt-4 text-left'>เพิ่มรายการใบสั่งจ่าย</p>}
      contentCenter={true}
      content={
        <>
          <BaseForm name='filter' onFinish={onFinish} initialValues={{ filter }}>
            <div className='flex flex-col gap-4 '>
              <div className='w-full bg-white'>
                <div className='flex flex-col gap-4'>
                  <Row gutter={[16, 16]}>
                    <Col {...searchColumn}>
                      <p className='text-label mb-2'>เลขที่ใบสั่งจ่าย</p>
                      <div className='flex justify-between items-center gap-4'>
                        <BaseItemInput
                          id={`${props.dataTestId}-paymentNo-input-text`}
                          itemName={['0']}
                          placeholder='ระบุเลขเริ่มต้น'
                          rules={[
                            minRule('เลขที่ใบสั่งจ่าย', 15),
                            maxRule('เลขที่ใบสั่งจ่าย', 15),
                            ({
                              getFieldValue,
                            }: {
                              getFieldValue: (name: string | (string | number)[]) => string;
                            }): { validator(_: unknown, value: string): Promise<void> } => ({
                              validator(_: unknown, value: string): Promise<void> {
                                if (!value && getFieldValue('paymentNo')[1]) {
                                  return Promise.reject(
                                    new Error('โปรดระบุข้อมูล เลขที่ใบสั่งจ่าย เริ่ม - สิ้นสุด ให้ครบถ้วน'),
                                  );
                                }

                                return Promise.resolve();
                              },
                            }),
                          ]}
                        />
                        <div className='mb-[23px]'>ถึง</div>
                        <BaseItemInput
                          id={`${props.dataTestId}-paymentNo-input-text`}
                          itemName={['1']}
                          placeholder='สิ้นสุด'
                          rules={[
                            minRule('เลขที่ใบสั่งจ่าย', 15),
                            maxRule('เลขที่ใบสั่งจ่าย', 15),
                            ({
                              getFieldValue,
                            }: {
                              getFieldValue: (name: string | (string | number)[]) => string;
                            }): { validator(_: unknown, value: string): Promise<void> } => ({
                              validator(_: unknown, value: string): Promise<void> {
                                if (!value && getFieldValue('paymentNo')[0]) {
                                  return Promise.reject(
                                    new Error('โปรดระบุข้อมูล เลขที่ใบสั่งจ่าย เริ่ม - สิ้นสุด ให้ครบถ้วน'),
                                  );
                                }

                                return Promise.resolve();
                              },
                            }),
                          ]}
                        />
                      </div>
                    </Col>
                    <Col {...searchColumn}>
                      <BaseItemInput
                        id={`${props.dataTestId}-accidentIssueCode-input-text`}
                        label='เลขประสบอันตราย'
                        itemName='accidentIssueCode'
                        placeholder='ระบุเลขประสบอันตราย'
                        rules={[
                          onlyNumberRule('เลขประสบอันตราย'),
                          minRule('เลขประสบอันตราย', 13),
                          maxRule('เลขประสบอันตราย', 13),
                        ]}
                      />
                    </Col>
                    <Col {...searchColumn}>
                      <BaseItemDateRangePicker
                        id={`${props.dataTestId}-date-input-date`}
                        rules={[requiredRule('วันที่คำสั่งจ่าย')]}
                        itemName='date'
                        label='วันที่คำสั่งจ่าย'
                        placeholder={['เริ่มต้น', 'สิ้นสุด']}
                      />
                    </Col>
                    <Col {...searchColumn}>
                      <BaseItemDropdown
                        label='ธนาคาร'
                        itemName='bankCode'
                        placeholder='เลือกธนาคาร'
                        id={`${props.dataTestId}-bankCode-selecter`}
                        option={bankSelectData}
                        // option={[{ value: 1, label: 'ธนาคารกรุงเทพ', disabled: false }]}
                        // loading={loadingBankData}
                        disabled={
                          props.tabActive === 'X' ||
                          props.tabActive === 'M' ||
                          props.tabActive === 'S' ||
                          props.tabActive === 'P'
                        }
                        rules={['B'].includes(props.tabActive) ? [requiredRule('ธนาคาร')] : []} // เพิ่ม rules เฉพาะ tab ที่กำหนด
                      />
                    </Col>
                  </Row>
                  <Row gutter={[16, 16]}>
                    <Col {...searchColumn}>
                      <BaseItemInput
                        id={`${props.dataTestId}-fullName-input-text`}
                        label='ชื่อ - นามสกุล'
                        itemName='fullName'
                        placeholder='ระบุชื่อ - นามสกุล'
                      />
                    </Col>
                    <Col {...searchColumn}>
                      <BaseItemInput
                        label='เลขบัตรประชาชน'
                        itemName='employeeCitizenId'
                        id={`${props.dataTestId}-employeeCitizenId-input`}
                        placeholder='เลขบัตรประชาชน'
                        rules={
                          ['S'].includes(props.tabActive)
                            ? [
                                requiredRule('เลขบัตรประชาชน'),
                                onlyNumberRule('เลขบัตรประชาชน'),
                                minRule('เลขบัตรประชาชน', 13),
                                maxRule('เลขบัตรประชาชน', 13),
                              ]
                            : [
                                onlyNumberRule('เลขบัตรประชาชน'),
                                minRule('เลขบัตรประชาชน', 13),
                                maxRule('เลขบัตรประชาชน', 13),
                              ]
                        }
                      />
                    </Col>
                    <Col {...searchColumn}>
                      <div>
                        <p className='text-label mb-2 text-left' id={`${props.dataTestId}-advancePaymentType-label`}>
                          ประเภทเบิกเงินรองจ่าย
                        </p>

                        <Radio.Group
                          className='h-[48px]'
                          optionType='button'
                          text-lg
                          font-boldtyle='solid'
                          onChange={onChangeRadio}
                          value={valueRadio}
                        >
                          <div className='flex gap-4 h-full'>
                            <Radio.Button className='!h-full flex justify-center items-center' value={'1'}>
                              <div id={`${props.dataTestId}-advancePaymentType-radio-W`}> เบิกเงินรองจ่าย</div>
                            </Radio.Button>
                            <Radio.Button className='!h-full flex justify-center items-center' value={'8'}>
                              <div id={`${props.dataTestId}-advancePaymentType-radio-B`}> ยืมเงินระหว่างวัน</div>
                            </Radio.Button>
                          </div>
                        </Radio.Group>
                      </div>
                    </Col>
                    <Col {...searchColumn}>
                      <div className='grid place-items-end h-20'>
                        <BaseButton
                          className='!min-w-[200px]'
                          size='middle'
                          icon={<SearchOutlined />}
                          htmlType='submit'
                          label={'ค้นหา'}
                        />
                      </div>
                    </Col>
                  </Row>
                </div>
              </div>
            </div>
          </BaseForm>
          <ModalTable
            filter={filter}
            setFilter={(filter) => {
              setFilter(filter);
            }}
            totalElements={totalElements}
            dataTestId={props.dataTestId}
            tabActive={props.tabActive}
            dataRows={filterResult}
            callBackDataSelected={(data) => {
              console.log('callBackDataSelected', data);
              setDataSelected(data);
            }}
          />
        </>
      }
      footer={
        <div className='flex justify-center gap-4'>
          <BaseButton size='middle' type='cancel' label='ยกเลิก' onClick={() => props.setOpenModal(false)} />
          <BaseButton size='middle' label='ยืนยัน' onClick={handleConfirmCreateModal} />
        </div>
      }
    />
  );
}
