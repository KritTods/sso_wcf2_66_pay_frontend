'use client';
import React from 'react';
import { Col, Row, Form } from 'wcf-component-lib/node_modules/antd';
import { BaseForm } from 'wcf-component-lib/src/components';
import { formColumn } from '@/constants/layoutColumn';

export default function CardHistoryDetail(): React.ReactElement {
  const [form] = Form.useForm();

  return (
    <>
      <BaseForm extraForm={form} name={'test'}>
        <div className='flex flex-col justify-center items-center'>
          <div className='w-full bg-white p-6 shadow-sm rounded-b-lg'>
            <div className='flex flex-col gap-4'>
              <p className='header-card'>รายละเอียด</p>
              <Row gutter={[16, 16]}>
                <Col {...formColumn}>
                  <div>
                    <p className='text-label-info'>เลขที่เอกสาร</p>
                    <p className='text-display'>0000000000</p>
                  </div>
                </Col>
                <Col {...formColumn}>
                  <div>
                    <p className='text-label-info'>วันที่สร้าง</p>
                    <p className='text-display'>01/12/2567</p>
                  </div>
                </Col>
                <Col {...formColumn}>
                  <div>
                    <p className='text-label-info'>ผู้เตรียมจ่าย</p>
                    <p className='text-display'>กาญจนา พิเศษ</p>
                  </div>
                </Col>
                <Col {...formColumn}>
                  <div>
                    <p className='text-label-info'>วันที่เตรียมจ่าย</p>
                    <p className='text-display'>31/12/2567</p>
                  </div>
                </Col>
              </Row>
            </div>
          </div>
        </div>
      </BaseForm>
    </>
  );
}
