'use client';
import React from 'react';
import { Col, Row } from 'wcf-component-lib/node_modules/antd';
import { threeColumn, singleColumn, formColumn } from '@/constants/layoutColumn';
import CardMoneyOrderTable from './cardMoneyOrderTable';
import SpinLoading from '@/components/common/SpinLoading';
import { AccidentIssueDetailServiceType } from '@/store-redux/slices/readytopay/doctor-salary';
import { formatCurrency, formatDayThai } from '@/utils/formatGeneral';

interface AccidentIssueCodeProps {
  dataTestId: string;
  type: string;
  data: AccidentIssueDetailServiceType | undefined;
}

export default function CardAllDetail({ dataTestId, data, type }: AccidentIssueCodeProps): React.ReactElement {
  //สำหรับ Loading Table รอข้อมูล
  if (data === undefined) {
    return (
      <div className='h-[800px] bg-white shadow-sm rounded-xl flex justify-center items-center'>
        <SpinLoading />
      </div>
    );
  }
  const { payment, medicalAssessment, accidentInformation, details, investigate, approval } = data;

  return (
    <div className='flex flex-col gap-4'>
      {/* รายละเอียดการจ่ายเงินทดแทน = 1 */}
      {type === '1' && (
        <>
          {/* ข้อมูลรายละเอียด */}
          <div className='flex flex-col justify-center items-center'>
            <div className='w-full bg-white p-6 shadow-sm rounded-b-lg'>
              <div className='flex flex-col gap-4'>
                <p className='header-card'>รายละเอียด</p>
                <Row key={payment.paymentNo} gutter={[16, 16]}>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label-info'>รหัสเจ้าหน้าที่วินิจฉัย</p>
                      <p className='text-display'>{details.investigatedLogCode}</p>
                    </div>
                  </Col>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label-info'>ชื่อสถานประกอบการ</p>
                      <p className='text-display'>{details.companyName}</p>
                    </div>
                  </Col>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label-info'>เลขที่ประสบอันตราย</p>
                      <p className='text-display'>{details.accidentIssuesCode}</p>
                    </div>
                  </Col>
                </Row>
                <Row gutter={[16, 16]}>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label-info'>ประเภทกิจการ</p>
                      <p className='text-display'>{details.businessType}</p>
                    </div>
                  </Col>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label-info'>เลขที่บัญชีนายจ้าง</p>
                      <p className='text-display'>{details.accountNo}</p>
                    </div>
                  </Col>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label-info'>รหัสกิจการ</p>
                      <p className='text-display'>{details.businessGroup}</p>
                    </div>
                  </Col>
                </Row>
                <Row gutter={[16, 16]}>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label-info'>วันที่ประสบอันตราย</p>
                      <p className='text-display'>{formatDayThai(details.accidentDate)}</p>
                    </div>
                  </Col>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label-info'>รหัส TSIC</p>
                      <p className='text-display'>{details.tsic.code}</p>
                    </div>
                  </Col>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label-info'>วันที่รับแจ้ง</p>
                      <p className='text-display'>{formatDayThai(details.informDate)}</p>
                    </div>
                  </Col>
                </Row>
                <Row gutter={[16, 16]}>
                  <Col {...singleColumn}>
                    <div>
                      <p className='text-label-info'>รายละเอียด TSIC</p>
                      <p className='text-display'>{details.tsic.description}</p>
                    </div>
                  </Col>
                </Row>
              </div>
            </div>
          </div>
          {/* ข้อมูลประสบอันตราย */}
          <div className='flex flex-col justify-center items-center'>
            <div className='w-full bg-white p-6 shadow-sm rounded-xl'>
              <div className='flex flex-col gap-4'>
                <p className='header-card'>ข้อมูลการประสบอันตราย</p>
                <Row gutter={[16, 16]}>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label-info'>ผู้ประสบอันตราย</p>
                      <p className='text-display'>{accidentInformation.employeeName}</p>
                    </div>
                  </Col>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label-info'>รหัสตำแหน่งหน้าที่</p>
                      <p className='text-display'>
                        {accidentInformation.careerPosition.code} - {accidentInformation.careerPosition.description}
                      </p>
                    </div>
                  </Col>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label-info'>เลขที่บัตรประชาชน</p>
                      <p className='text-display'>{accidentInformation.employeeCid}</p>
                    </div>
                  </Col>
                </Row>
                <Row gutter={[16, 16]}>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label-info'>รหัสอวัยวะที่ประสบอันตราย</p>
                      <p className='text-display'>
                        {accidentInformation.accidentOrgan.code} - {accidentInformation.accidentOrgan.description}
                      </p>
                    </div>
                  </Col>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label-info'>ตำแหน่ง</p>
                      <p className='text-display'>{accidentInformation.position}</p>
                    </div>
                  </Col>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label-info'>รหัสสิ่งของที่ทำให้ประสบอันตราย</p>
                      <p className='text-display'>
                        {accidentInformation.accidentItem.code} - {accidentInformation.accidentItem.description}
                      </p>
                    </div>
                  </Col>
                </Row>
                <Row gutter={[16, 16]}>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label-info'>สาเหตุที่ประสบอันตราย</p>
                      <p className='text-display'>{accidentInformation.accidentCauseText}</p>
                    </div>
                  </Col>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label-info'>รหัสสาเหตุที่ประสบอันตราย</p>
                      <p className='text-display'>
                        {accidentInformation.accidentCase.code} - {accidentInformation.accidentCase.description}
                      </p>
                    </div>
                  </Col>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label-info'>ผลของการประสบอันตราย</p>
                      <p className='text-display'>{accidentInformation.accidentInjuryText}</p>
                    </div>
                  </Col>
                </Row>
                <Row gutter={[16, 16]}>
                  <Col {...singleColumn}>
                    <div>
                      <p className='text-label-info'>รหัสผลของการประสบอันตราย</p>
                      <p className='text-display'>
                        {accidentInformation.accidentInjury.code} - {accidentInformation.accidentInjury.description}
                      </p>
                    </div>
                  </Col>
                </Row>
              </div>
            </div>
          </div>
          {/* ข้อมูลการวินิจฉัย */}
          <div className='flex flex-col justify-center items-center'>
            <div className='w-full bg-white p-6 shadow-sm rounded-xl'>
              <div className='flex flex-col gap-4'>
                <p className='header-card'>คำวินิจฉัย / เปลี่ยนแปลงคำวินิจฉัย</p>
                <Row gutter={[16, 16]}>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label-info'>ครั้งที่</p>
                      <p className='text-display'>{investigate.treatmentDescription}</p>
                    </div>
                  </Col>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label-info'>ระดับความรุนแรง</p>
                      <p className='text-display'>
                        {investigate.investigateType.code} - {investigate.investigateType.description}
                      </p>
                    </div>
                  </Col>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label-info'>ผลการวินิจฉัย</p>
                      <p className='text-display'>{investigate.result}</p>
                    </div>
                  </Col>
                </Row>
                <Row gutter={[16, 16]}>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label-info'>เงินค่าจ้าง (บาท)</p>
                      <p className='text-display'>{formatCurrency(investigate.amount)}</p>
                    </div>
                  </Col>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label-info'>วันที่เปลี่ยนแปลงคำวินิจฉัย</p>
                      <p className='text-display'>{formatDayThai(investigate.expiryDate)}</p>
                    </div>
                  </Col>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label-info'>ค่าทดแทนรายเดือน (บาท)</p>
                      <p className='text-display'>{formatCurrency(investigate.compensationFee)}</p>
                    </div>
                  </Col>
                </Row>
              </div>
            </div>
          </div>
          {/* ข้อมูลใบสั่งจ่าย */}
          <div className='flex flex-col justify-center items-center'>
            <div className='w-full bg-white p-6 shadow-sm rounded-xl'>
              <div className='flex flex-col gap-4'>
                <p className='header-card'>ข้อมูลใบสั่งจ่าย</p>
                <Row gutter={[16, 16]}>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label-info'>เลขที่ใบสั่งจ่าย</p>
                      <p className='text-display'>{payment.paymentCode}</p>
                    </div>
                  </Col>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label-info'>สถานะใบสั่งจ่าย</p>
                      <p className='text-display'>{payment.paymentStatus}</p>
                    </div>
                  </Col>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label text-[#F56C1F]'>จ่ายให้</p>
                      <p className='text-display'>{payment.payTo}</p>
                    </div>
                  </Col>
                </Row>
                <Row gutter={[16, 16]}>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label text-[#F56C1F]'>จ่ายโดย</p>
                      <p className='text-display'>{payment.payBy}</p>
                    </div>
                  </Col>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label text-[#F56C1F]'>ลำดับที่</p>
                      <p className='text-display'>{payment.payIndex}</p>
                    </div>
                  </Col>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label text-[#F56C1F]'>ไปรษณีย์ปลายทาง</p>
                      <p className='text-display'>{payment.destinationPortal}</p>
                    </div>
                  </Col>
                </Row>
                <Row gutter={[16, 16]}>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label-info'>วันที่สั่งจ่าย</p>
                      <p className='text-display'>{formatDayThai(payment.paymentDate)}</p>
                    </div>
                  </Col>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label-info'>ผู้บันทึกใบสั่งจ่าย</p>
                      <p className='text-display'>{payment.createdBy}</p>
                    </div>
                  </Col>
                </Row>
              </div>
            </div>
          </div>
          {/* ข้อมูลตารางรายการจ่ายเงิน */}
          <CardMoneyOrderTable dataTestId={dataTestId} data={data} />
          {/* ข้อมูลการอนุมัติใบสั่งจ่าย */}
          {/* อนุมัติใบสั่งจ่าย */}
          <div className='flex flex-col justify-center items-center'>
            <div className='w-full bg-white p-6 shadow-sm rounded-xl'>
              <div className='flex flex-col gap-4'>
                <p className='header-card'>อนุมัติใบสั่งจ่าย</p>
                <Row gutter={[16, 16]}>
                  <Col {...formColumn}>
                    <div>
                      <p className='text-label-info'>สถานะการอนุมัติ</p>
                      <p className='text-display'>{approval.status}</p>
                    </div>
                  </Col>
                  <Col {...formColumn}>
                    <div>
                      <p className='text-label-info'>วันที่อนุมัติ</p>
                      <p className='text-display'>{formatDayThai(approval.date)}</p>
                    </div>
                  </Col>
                  <Col {...formColumn}>
                    <div>
                      <p className='text-label-info'>ผู้อนุมัติ</p>
                      <p className='text-display'>{approval.approver}</p>
                    </div>
                  </Col>
                </Row>
              </div>
            </div>
          </div>
        </>
      )}

      {/* รายละเอียดการจ่ายค่าตอบแทนแพทย์ = 8 */}
      {type === '8' && (
        <>
          {/* ข้อมูลใบสั่งจ่าย */}
          <div className='flex flex-col justify-center items-center'>
            <div className='w-full bg-white p-6 shadow-sm rounded-xl'>
              <div className='flex flex-col gap-4'>
                <p className='header-card'>ข้อมูลใบสั่งจ่าย</p>
                <Row gutter={[16, 16]}>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label-info'>เลขที่ใบสั่งจ่าย</p>
                      <p className='text-display'>{payment.paymentCode}</p>
                    </div>
                  </Col>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label-info'>วันที่สั่งจ่าย</p>
                      <p className='text-display'>{formatDayThai(payment.paymentDate)}</p>
                    </div>
                  </Col>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label text-[#F56C1F]'>จ่ายโดย</p>
                      <p className='text-display'>{payment.payBy}</p>
                    </div>
                  </Col>
                </Row>
                <Row gutter={[16, 16]}>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label text-[#F56C1F]'>สถานะใบสั่งจ่าย</p>
                      <p className='text-display'>{payment.paymentStatus}</p>
                    </div>
                  </Col>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label '>ผู้สั่งจ่าย</p>
                      <p className='text-display'>{payment.paymentOrderer}</p>
                    </div>
                  </Col>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label text-[#F56C1F]'>สถานะการจ่าย</p>
                      <p className='text-display'>{payment.payStatus}</p>
                    </div>
                  </Col>
                </Row>
                <Row gutter={[16, 16]}>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label-info'>จำนวนเงิน</p>
                      <p className='text-display'>{formatCurrency(payment.payAmount)}</p>
                    </div>
                  </Col>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label-info'>เลขที่ใบสำคัญรับเงิน</p>
                      <p className='text-display'>{payment.paymentNo}</p>
                    </div>
                  </Col>
                </Row>
              </div>
            </div>
          </div>

          {/* ข้อมูลการตรวจประเมิน */}
          <div className='flex flex-col justify-center items-center'>
            <div className='w-full bg-white p-6 shadow-sm rounded-xl'>
              <div className='flex flex-col gap-4'>
                <p className='header-card'>ข้อมูลการตรวจประเมิน</p>
                <Row gutter={[16, 16]}>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label-info'>เลขที่ใบคำขอค่าตรวจประเมิน</p>
                      <p className='text-display'>{medicalAssessment.assessmentRequestNo}</p>
                    </div>
                  </Col>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label-info'>แพทย์ผู้ประเมิน</p>
                      <p className='text-display'>{medicalAssessment.assessingDoctor}</p>
                    </div>
                  </Col>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label-info'>วันที่ตรวจ</p>
                      <p className='text-display'>{formatDayThai(medicalAssessment.assessmentDate)}</p>
                    </div>
                  </Col>
                </Row>
                <Row gutter={[16, 16]}>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label-info'>ทำการตรวจ ณ</p>
                      <p className='text-display'>{medicalAssessment.assessmentLocation}</p>
                    </div>
                  </Col>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label-info'>ผู้ออกใบคำขอ</p>
                      <p className='text-display'>{medicalAssessment.requestIssuer}</p>
                    </div>
                  </Col>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label-info'>สถานะการอนุมัติ</p>
                      <p className='text-display'>{medicalAssessment.approvalStatus}</p>
                    </div>
                  </Col>
                </Row>
                <Row gutter={[16, 16]}>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label-info'>ผู้อนุมัติ</p>
                      <p className='text-display'>{medicalAssessment.approver}</p>
                    </div>
                  </Col>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label-info'>วันที่อนุมัติ</p>
                      <p className='text-display'>{formatDayThai(medicalAssessment.approvalDate)}</p>
                    </div>
                  </Col>
                </Row>
              </div>
            </div>
          </div>

          {/* ข้อมูลการประสบอันตราย */}
          <div className='flex flex-col justify-center items-center'>
            <div className='w-full bg-white p-6 shadow-sm rounded-xl'>
              <div className='flex flex-col gap-4'>
                <p className='header-card'>ข้อมูลการประสบอันตราย</p>
                <Row gutter={[16, 16]}>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label-info'>เลขประสบอันตราย</p>
                      <p className='text-display'>{accidentInformation.accidentNumber}</p>
                    </div>
                  </Col>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label-info'>วันที่ประสบอันตราย</p>
                      <p className='text-display'>{formatDayThai(accidentInformation.accidentDate)}</p>
                    </div>
                  </Col>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label-info'>ระดับความรุนแรง</p>
                      <p className='text-display'>{accidentInformation.severityLevel}</p>
                    </div>
                  </Col>
                </Row>
                <Row gutter={[16, 16]}>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label-info'>ชื่อ - นามสกุล</p>
                      <p className='text-display'>{accidentInformation.fullName}</p>
                    </div>
                  </Col>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label-info'>ที่อยู่เลขที่</p>
                      <p className='text-display'>{accidentInformation.addressNumber}</p>
                    </div>
                  </Col>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label-info'>หมู่ที่</p>
                      <p className='text-display'>{accidentInformation.villageNumber}</p>
                    </div>
                  </Col>
                </Row>
                <Row gutter={[16, 16]}>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label-info'>ถนน</p>
                      <p className='text-display'>{accidentInformation.road}</p>
                    </div>
                  </Col>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label-info'>ซอย</p>
                      <p className='text-display'>{accidentInformation.alley}</p>
                    </div>
                  </Col>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label-info'>ตำบล</p>
                      <p className='text-display'>{accidentInformation.subDistrict}</p>
                    </div>
                  </Col>
                </Row>
                <Row gutter={[16, 16]}>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label-info'>อำเภอ</p>
                      <p className='text-display'>{accidentInformation.district}</p>
                    </div>
                  </Col>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label-info'>จังหวัด</p>
                      <p className='text-display'>{accidentInformation.province}</p>
                    </div>
                  </Col>
                  <Col {...threeColumn}>
                    <div>
                      <p className='text-label-info'>รหัสไปรษณีย์</p>
                      <p className='text-display'>{accidentInformation.postalCode}</p>
                    </div>
                  </Col>
                </Row>
                <Row gutter={[16, 16]}>
                  <Col lg={12}>
                    <div>
                      <p className='text-label-info'>นายจ้าง</p>
                      <p className='text-display'>{accidentInformation.employer}</p>
                    </div>
                  </Col>
                </Row>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
