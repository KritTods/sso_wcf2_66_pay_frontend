'use client';
import React, { useState } from 'react';
import { Col, Row, Form } from 'wcf-component-lib/node_modules/antd';

import {
  BaseForm,
  BaseItemInput,
  BaseItemInputNumber,
  BaseButton,
  BaseItemDatePicker,
  BaseItemDropdown,
  BaseToastNotification,
  BaseDialog,
  BaseIcon,
} from 'wcf-component-lib/src/components';
import { formColumn } from '@/constants/layoutColumn';
import { requiredRule } from 'wcf-component-lib/src/rules/FormRulesFunction';
import { URL } from '@/constants/configPage';
import { useRouter } from 'next/navigation';
import CollapseCustoms from '@/modules/readytopay/officefund-payment/component/collapse';

export default function OfficeFundPayment(): React.ReactElement {
  const [form] = Form.useForm();
  const router = useRouter();
  const [activeKeys, setActiveKeys] = useState<string[]>(['1']);
  const [isOpenConfirmModal, setIsOpenConfirmModal] = useState(false);
  const isDeleteDisabled = activeKeys.length <= 1;

  const handleCancel = (): void => {
    setIsOpenConfirmModal(false);
  };

  const handleConfirm = (): void => {
    console.log(activeKeys.length);
    if (activeKeys.length > 0) {
      // show notification success
      BaseToastNotification({
        type: 'success',
        message: 'เสร็จสิ้น',
        description: 'ทำรายการเสร็จสิ้น',
      });
      // router.push(URL.readytopay.officeFundPaymentDetail.url);
      router.push(`${URL.readytopay.OfficeFundPaymentDetail.url}?activeKeys=${activeKeys.length}`);
      //close modal
      setIsOpenConfirmModal(false);
    } else {
      BaseToastNotification({
        type: 'error',
        message: 'บันทึกไม่สำเสร็จ!',
        description: 'กรุณากรอกข้อมูลอย่างน้อย 1 งวด',
      });
    }
  };

  // เพิ่มแถวใหม่
  const handleAddRow = (): void => {
    const newKey = (activeKeys.length + 1).toString(); // สร้างคีย์ใหม่
    setActiveKeys([...activeKeys, newKey]); // เพิ่มแถวใหม่
  };

  // ลบแถว
  const handleDeleteRow = (key: string): void => {
    if (activeKeys.length > 1) {
      setActiveKeys(activeKeys.filter((k) => k !== key)); // ลบแถวที่เลือก
    } else {
      BaseToastNotification({
        type: 'error',
        message: 'ลบไม่สำเสร็จ!',
        description: 'รายการต้องมีอย่างน้อย 1 งวด',
      });
    }
  };

  const handleFormSubmit = (values: unknown): void => {
    console.log('values:', values);
  };

  return (
    <div className='flex flex-col gap-4 mx-4 rounded-2xl'>
      {/* รายละเอียด */}
      <div className='flex flex-col justify-center items-center'>
        <div className='w-full bg-white p-6 shadow-sm rounded-2xl'>
          <div className='flex flex-col gap-4'>
            <p className='header-card'>รายละเอียด</p>
            <Row gutter={[16, 16]}>
              <Col {...formColumn}>
                <div>
                  <p className='text-label-info'>เลขที่เอกสาร</p>
                  <p className='text-display'>0000000000</p>
                </div>
              </Col>
              <Col {...formColumn}>
                <div>
                  <p className='text-label-info'>วันที่สร้าง</p>
                  <p className='text-display'>01/12/2567</p>
                </div>
              </Col>
              <Col {...formColumn}>
                <div>
                  <p className='text-label-info'>ผู้เตรียมจ่าย</p>
                  <p className='text-display'>กาญจนา พิเศษ</p>
                </div>
              </Col>
              <Col {...formColumn}>
                <div>
                  <p className='text-label-info'>วันที่เตรียมจ่าย</p>
                  <p className='text-display'>31/12/2567</p>
                </div>
              </Col>
            </Row>
          </div>
        </div>
      </div>

      {/* บันทึกข้อมูล */}
      <BaseForm
        onFinish={handleFormSubmit}
        // initialValues={initialState.form}
        extraForm={form}
        name={'officefund-payment-form'}
      >
        {/* บันทึกข้อมูล */}
        <div className='flex p-6 bg-white shadow-sm rounded-2xl mb-4'>
          <div className='w-full bg-white shadow-sm rounded-xl flex flex-row gap-4'>
            <div className='w-full'>
              <div className='flex flex-col gap-4'>
                <p className='header-card'>บันทึกข้อมูล</p>
                <Row gutter={[16, 16]}>
                  <Col {...formColumn}>
                    <BaseItemInput
                      label='จ่ายตามประกาศฉบับที่'
                      itemName='noticeNumber'
                      placeholder='/2567'
                      rules={[requiredRule('จ่ายตามประกาศฉบับที่')]}
                    />
                  </Col>
                  <Col {...formColumn}>
                    <BaseItemInputNumber
                      label='จำนวนเงินจ่ายตามประกาศ (บาท)'
                      itemName='paidAmount'
                      className='w-full'
                      rules={[requiredRule('จำนวนเงินจ่ายตามประกาศ (บาท)')]}
                      itemForm={form}
                    />
                  </Col>
                  <Col {...formColumn}>
                    <BaseItemInputNumber
                      label='จำนวนเงินคงเหลือตามประกาศ (บาท)'
                      itemName='balanceAmount'
                      className='w-full'
                      rules={[requiredRule('จำนวนเงินคงเหลือตามประกาศ (บาท)')]}
                      itemForm={form}
                    />
                  </Col>
                </Row>
              </div>
            </div>
          </div>
        </div>

        {/* รายการ งวดที่ */}
        {activeKeys.map((keys) => (
          <CollapseCustoms
            title='งวดที่'
            collapseKey={keys} // ส่ง collapseKey เพื่อใช้แทน key ใน component
            handleDeleteRow={handleDeleteRow}
            isDeleteDisabled={isDeleteDisabled} // ส่ง isDeleteDisabled เป็น prop
            key={keys} // ใช้ key สำหรับ React rendering
            type={'form'}
          >
            <Form.List name='period_number'>
              {() => (
                <>
                  <div className=' bg-white rounded-2xl my-4'>
                    <Row gutter={[16, 16]}>
                      <Col {...formColumn}>
                        <Form.Item key={keys}>
                          <BaseItemInput
                            label='งวดที่'
                            itemName='period_number'
                            placeholder='ระบุงวดที่'
                            rules={[requiredRule('งวดที่')]}
                          />
                        </Form.Item>
                      </Col>
                      <Col {...formColumn}>
                        <Form.Item key={keys}>
                          <BaseItemInput
                            label='เลขที่หนังสือ รง.'
                            itemName='document_number'
                            placeholder='ระบุเลขที่หนังสือ รง.'
                            rules={[requiredRule('เลขที่หนังสือ รง.')]}
                          />
                        </Form.Item>
                      </Col>
                      <Col {...formColumn}>
                        <Form.Item key={keys}>
                          <BaseItemDatePicker
                            label='วันที่หนังสือ'
                            itemName='document_date'
                            placeholder='เลือกวันที่หนังสือ'
                            className='w-full'
                            rules={[requiredRule('เลือกวันที่หนังสือ')]}
                          />
                        </Form.Item>
                      </Col>
                      <Col {...formColumn}>
                        <Form.Item key={keys}>
                          <BaseItemInput
                            label='ชื่อผู้อนุมัติสั่งจ่าย'
                            itemName='approver_name'
                            placeholder='ระบุชื่อผู้อนุมัติสั่งจ่าย'
                            rules={[requiredRule('ระบุชื่อผู้อนุมัติสั่งจ่าย')]}
                          />
                        </Form.Item>
                      </Col>
                    </Row>
                    <hr className='my-5' />
                    {/* งวดที่ 1 */}
                    <Row gutter={[16, 16]}>
                      <Col xl={12}>
                        <Form.Item key={keys}>
                          <BaseItemInput
                            label='1.ชื่อบัญชีสั่งจ่าย'
                            itemName='payee_account_name'
                            placeholder='ระบุชื่อบัญชีสั่งจ่าย'
                            rules={[requiredRule('ชื่อบัญชีสั่งจ่าย')]}
                          />
                        </Form.Item>
                      </Col>
                      <Col {...formColumn}>
                        <Form.Item key={keys}>
                          <BaseItemDropdown
                            label='ธนาคาร'
                            itemName='bankCode'
                            rules={[requiredRule('ธนาคาร')]}
                            placeholder='เลือกธนาคาร'
                            option={[]}
                            loading={false}
                          />
                        </Form.Item>
                      </Col>
                      <Col xl={3}>
                        <Form.Item key={keys}>
                          <BaseItemInput
                            label='เช็คเลขที่'
                            itemName='cheque_number'
                            placeholder='ระบุเช็คเลขที่'
                            rules={[requiredRule('เช็คเลขที่')]}
                          />
                        </Form.Item>
                      </Col>
                      <Col xl={3}>
                        <Form.Item key={keys}>
                          <BaseItemInputNumber
                            label='จำนวนเงิน'
                            itemName='amount'
                            placeholder='ระบุจำนวนเงิน'
                            itemForm={form}
                            className='w-full'
                            rules={[requiredRule('จำนวนเงิน')]}
                          />
                        </Form.Item>
                      </Col>
                    </Row>
                    <Form.List name='period_number_sub'>
                      {(fields, { add, remove }) => (
                        <>
                          {fields.map(({ key, name, ...restField }) => (
                            <div key={key}>
                              <Row gutter={[16, 16]}>
                                <Col xl={12}>
                                  <Form.Item
                                    key={keys}
                                    {...restField}
                                    name={[name, 'payee_account_name']}
                                    rules={[{ required: true, message: 'ระบุชื่อบัญชีสั่งจ่าย' }]}
                                  >
                                    <BaseItemInput
                                      label='2.ชื่อบัญชีสั่งจ่าย'
                                      itemName='payee_account_name'
                                      placeholder='ระบุชื่อบัญชีสั่งจ่าย'
                                      rules={[requiredRule('ชื่อบัญชีสั่งจ่าย')]}
                                    />
                                  </Form.Item>
                                </Col>
                                <Col {...formColumn}>
                                  <Form.Item
                                    key={keys}
                                    {...restField}
                                    name={[name, 'bankCode']}
                                    rules={[{ required: true, message: 'เลือกธนาคาร' }]}
                                  >
                                    <BaseItemDropdown
                                      label='ธนาคาร'
                                      itemName='bankCode'
                                      rules={[requiredRule('ธนาคาร')]}
                                      placeholder='เลือกธนาคาร'
                                      option={[]}
                                      loading={false}
                                    />
                                  </Form.Item>
                                </Col>
                                <Col xl={3}>
                                  <Form.Item
                                    key={keys}
                                    {...restField}
                                    name={[name, 'cheque_number']}
                                    rules={[{ required: true, message: 'ระบุเช็คเลขที่' }]}
                                  >
                                    <BaseItemInput
                                      label='เช็คเลขที่'
                                      itemName='cheque_number'
                                      placeholder='ระบุเช็คเลขที่'
                                      rules={[requiredRule('เช็คเลขที่')]}
                                    />
                                  </Form.Item>
                                </Col>
                                <Col xl={3}>
                                  <Form.Item
                                    key={keys}
                                    {...restField}
                                    name={[name, 'amount']}
                                    rules={[{ required: true, message: 'ระบุจำนวนเงิน' }]}
                                  >
                                    <BaseItemInputNumber
                                      label='จำนวนเงิน'
                                      itemName='amount'
                                      placeholder='ระบุจำนวนเงิน'
                                      itemForm={form}
                                      className='w-full'
                                      rules={[requiredRule('จำนวนเงิน')]}
                                    />
                                  </Form.Item>
                                </Col>
                              </Row>
                              <Form.Item>
                                <p
                                  className='text-lg font-bold text-[#C42828] underline cursor-pointer'
                                  onClick={() => remove(name)}
                                >
                                  ลบบัญชีสั่งจ่าย 2
                                </p>
                              </Form.Item>
                            </div>
                          ))}

                          <Form.Item>
                            {fields.length < 1 ? (
                              <p
                                className='text-lg font-bold text-[#1A6CA8] underline cursor-pointer'
                                onClick={() => add()}
                              >
                                เพิ่มบัญชีสั่งจ่าย 2
                              </p>
                            ) : null}
                          </Form.Item>
                        </>
                      )}
                    </Form.List>
                  </div>
                </>
              )}
            </Form.List>
          </CollapseCustoms>
        ))}

        {/* ปุ่ม เพิ่มงวด/บันทึกข้อมูล */}

        <div className='flex justify-center gap-4 py-6'>
          <BaseButton size='middle' type='outline' label='เพิ่มงวด' className='w-[240px]' onClick={handleAddRow} />
          <BaseButton
            size='middle'
            label='บันทึกข้อมูล'
            className='w-[240px]'
            onClick={() => setIsOpenConfirmModal(true)}
          />
        </div>
        <BaseDialog
          width='560px'
          isOpen={isOpenConfirmModal}
          setIsOpen={setIsOpenConfirmModal}
          content={
            <div className='flex flex-col w-full gap-4'>
              <div className='text-left font-semibold text-3xl'>บันทึกข้อมูลใช่หรือไม่?</div>
              <div className='text-left status text-[#4B5760]'>กรุณายืนยันการทำรายการอีกครั้ง</div>
            </div>
          }
          headerLeftIcon={
            <BaseIcon
              name='downloadSquare'
              size='40px'
              classNameColor={{
                base: 'text-primary',
                hover: 'text-primary-bright',
                active: 'text-secondary',
                disabled: 'text-primary-very-bright',
              }}
              disabled={false}
              active={false}
            />
          }
          footer={
            <div className='flex justify-center gap-4'>
              <BaseButton size='middle' type='cancel' label='ยกเลิก' onClick={handleCancel} />
              <BaseButton size='middle' label='ยืนยัน' onClick={handleConfirm} />
            </div>
          }
        />
      </BaseForm>
    </div>
  );
}
