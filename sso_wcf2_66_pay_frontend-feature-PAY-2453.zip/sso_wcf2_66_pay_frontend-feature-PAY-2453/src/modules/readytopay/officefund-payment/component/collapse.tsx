import { useState } from 'react';
import { BaseButton } from 'wcf-component-lib/src/components';
import { Compress, DeCompress, Trash } from 'wcf-component-lib/node_modules/iconoir-react';

interface CollapseProps {
  title: string;
  children: React.ReactNode;
  collapseKey: string; // ใช้ชื่อ prop อื่นแทน key
  handleDeleteRow?: ((key: string) => void) | undefined; // ฟังก์ชันลบแถว
  isDeleteDisabled?: boolean; // เพิ่ม prop สำหรับควบคุมปุ่มลบ
  type: string;
}

const CollapseCustoms: React.FC<CollapseProps> = ({
  title,
  children,
  collapseKey,
  handleDeleteRow,
  isDeleteDisabled,
  type,
}) => {
  const [isOpen, setIsOpen] = useState<boolean>(true);

  const toggleCollapse = (): void => {
    setIsOpen((prevState) => !prevState);
  };

  console.log('isDeleteDisabled', isDeleteDisabled);

  return (
    <div className='p-6 bg-white shadow-sm rounded-2xl my-4'>
      <div className='flex justify-between'>
        <p className='header-card'>{title}</p>
        <div className='flex gap-6'>
          {type === 'detail' && (
            <BaseButton
              className='!min-w-[200px]'
              size='middle'
              type='outline'
              icon={isOpen ? <Compress /> : <DeCompress />}
              label={isOpen ? 'ย่อลง' : 'แสดงข้อมูล'}
              onClick={toggleCollapse}
            />
          )}
          {isDeleteDisabled === false && type === 'form' && handleDeleteRow && (
            <BaseButton
              className='!min-w-[200px]'
              size='middle'
              type='fieryRed'
              icon={<Trash />}
              label='ลบ'
              onClick={() => handleDeleteRow(collapseKey)}
              disabled={isDeleteDisabled} // ใช้ prop isDeleteDisabled
            />
          )}
        </div>
      </div>

      <div className={`overflow-hidden ease-in-out ${isOpen ? 'max-h-[1000px] mt-2 rounded-md' : 'max-h-0'}`}>
        {isOpen && <div>{children}</div>}
      </div>
    </div>
  );
};

export default CollapseCustoms;
