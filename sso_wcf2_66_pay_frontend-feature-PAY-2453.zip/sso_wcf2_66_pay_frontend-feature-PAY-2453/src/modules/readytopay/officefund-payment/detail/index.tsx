'use client';
import React from 'react';
import { Col, Row } from 'wcf-component-lib/node_modules/antd';

import { BaseButton } from 'wcf-component-lib/src/components';
import { formColumn } from '@/constants/layoutColumn';
import { URL } from '@/constants/configPage';
import { useRouter } from 'next/navigation';

import CollapseCustoms from '@/modules/readytopay/officefund-payment/component/collapse';

export default function OfficeFundPayment(): React.ReactElement {
  const dataTestId = 'page-officefund-payment-detail';
  const router = useRouter();
  const key = '2'; // สามารถปรับให้ dynamic ได้หากมีหลาย panel

  return (
    <div className='flex flex-col rounded-2xl mx-4'>
      {/* รายละเอียด */}
      <div className='flex flex-col justify-center items-center '>
        <div className='w-full bg-white p-6 shadow-sm rounded-2xl'>
          <div className='flex flex-col gap-4'>
            <p className='header-card'>รายละเอียด</p>
            <Row gutter={[16, 16]}>
              <Col {...formColumn}>
                <div>
                  <p className='text-label-info'>เลขที่เอกสาร</p>
                  <p className='text-display'>P000167000001B2</p>
                </div>
              </Col>
              <Col {...formColumn}>
                <div>
                  <p className='text-label-info'>วันที่สร้าง</p>
                  <p className='text-display'>J000167000001B2</p>
                </div>
              </Col>
              <Col {...formColumn}>
                <div>
                  <p className='text-label-info'>ผู้เตรียมจ่าย</p>
                  <p className='text-display'>กาญจนา พิเศษ</p>
                </div>
              </Col>
              <Col {...formColumn}>
                <div>
                  <p className='text-label-info'>วันที่เตรียมจ่าย</p>
                  <p className='text-display'>31/12/2567</p>
                </div>
              </Col>
            </Row>
          </div>
        </div>
      </div>

      {/* บันทึกข้อมูล */}
      <div className='flex flex-col justify-center items-center mt-4'>
        <div className='w-full bg-white p-6 shadow-sm rounded-2xl'>
          <div className='flex flex-col gap-4'>
            <p className='header-card'>บันทึกข้อมูล</p>
            <Row gutter={[16, 16]}>
              <Col {...formColumn}>
                <div>
                  <p className='text-label-info'>จ่ายตามประกาศฉบับที่</p>
                  <p className='text-display'>1</p>
                </div>
              </Col>
              <Col {...formColumn}>
                <div>
                  <p className='text-label-info'>จำนวนเงินจ่ายตามประกาศ (บาท)</p>
                  <p className='text-display'>2,100,000.00</p>
                </div>
              </Col>
              <Col {...formColumn}>
                <div>
                  <p className='text-label-info'>จำนวนเงินคงเหลือตามประกาศ (บาท)</p>
                  <p className='text-display'>0.00</p>
                </div>
              </Col>
            </Row>
          </div>
        </div>
      </div>

      {/* รายการ งวดที่ */}
      <CollapseCustoms
        title={`งวดที่ : ${key}`}
        collapseKey={key} // ส่ง collapseKey เพื่อใช้แทน key ใน component
        key={key} // ใช้ key สำหรับ React rendering
        type={'detail'}
      >
        <Row gutter={[16, 16]} className='my-5'>
          <Col {...formColumn}>
            <p className='text-label-info' id={`${dataTestId}-advancePaymentType-label`}>
              เลขที่หนังสือ รง.
            </p>
            <p className='text-display text-black' id={`${dataTestId}-advancePaymentType-text`}>
              0000000000
            </p>
          </Col>
          <Col {...formColumn}>
            <p className='text-label-info' id={`${dataTestId}-advancePaymentType-label`}>
              ผู้อนุมัติสั่งจ่าย
            </p>
            <p className='text-display text-black' id={`${dataTestId}-advancePaymentType-text`}>
              นพดล สุขมั่งมี
            </p>
          </Col>
          <Col {...formColumn}>
            <p className='text-label-info' id={`${dataTestId}-advancePaymentType-label`}>
              วันที่หนังสือ
            </p>
            <p className='text-display text-black' id={`${dataTestId}-advancePaymentType-text`}>
              31/12/2567
            </p>
          </Col>
        </Row>
        <hr className='my-5' />
        <Row gutter={[16, 16]} className='my-5'>
          <Col lg={24}>
            <p className='text-label-info' id={`${dataTestId}-advancePaymentType-label`}>
              ชื่อบัญชีสั่งจ่าย : 1
            </p>
            <p className='text-display text-black' id={`${dataTestId}-advancePaymentType-text`}>
              บัญชีเงินค่าใช้จ่ายในการฟื้นฟูและส่งเสริมความปลอดภัย บัญชีที่ 1
            </p>
          </Col>
        </Row>
        <Row gutter={[16, 16]} className='my-5'>
          <Col {...formColumn}>
            <p className='text-label-info' id={`${dataTestId}-advancePaymentType-label`}>
              เลขที่เช็ค
            </p>
            <p className='text-display text-black' id={`${dataTestId}-advancePaymentType-text`}>
              12049109
            </p>
          </Col>
          <Col {...formColumn}>
            <p className='text-label-info' id={`${dataTestId}-advancePaymentType-label`}>
              จำนวนเงิน (บาท)
            </p>
            <p className='text-display text-black' id={`${dataTestId}-advancePaymentType-text`}>
              2,000,000.00
            </p>
          </Col>
          <Col {...formColumn}>
            <p className='text-label-info' id={`${dataTestId}-advancePaymentType-label`}>
              ธนาคาร
            </p>
            <p className='text-display text-black' id={`${dataTestId}-advancePaymentType-text`}>
              006 - ธ.กรุงไทย จำกัด (มหาชน)
            </p>
          </Col>
        </Row>
      </CollapseCustoms>

      <div className='flex flex-row justify-center items-center gap-4'>
        <BaseButton
          size='middle'
          type='cancel'
          label='ยกเลิก'
          className='bg-[#dedede] hover:bg-red-500'
          onClick={() => router.push(URL.readytopay.OfficeFundPayment.url)}
        />
      </div>
    </div>
  );
}
