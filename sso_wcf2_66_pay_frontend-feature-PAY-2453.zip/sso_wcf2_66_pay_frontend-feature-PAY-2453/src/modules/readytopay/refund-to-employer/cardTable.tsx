'use client';
import React, { useState, useMemo, useEffect } from 'react';
import TableListLayout from 'wcf-component-lib/src/layout/TableListLayout';
import BaseGrid, { ColumnsTypeCustom } from 'wcf-component-lib/src/components/v2/BaseGrid';
import { BaseButton, BaseDialog, BaseIcon } from 'wcf-component-lib/src/components';
import { Checkbox } from 'wcf-component-lib/node_modules/antd';
import SpinLoading from '@/components/common/spinLoading';
import { InfoCircle } from 'wcf-component-lib/node_modules/iconoir-react';
import { URL } from '@/constants/configPage';
import { useRouter } from 'next/navigation';

import { useAppDispatch } from '@/store-redux/store';
import { useSelector } from 'react-redux';
import {
  RefundtoEmployerSelector,
  clearListFilter,
  getRefundtoEmployerService,
  RefundtoEmployerDataType,
  setPaymentNo,
  setOptionPaymentTabsActive,
} from '@/store-redux/slices/readytopay/refund-to-employer';

export default function CardTable({ dataTestId }: { dataTestId: string }): React.ReactElement {
  const router = useRouter();
  const dispatch = useAppDispatch();
  const [selectedId, setSelectedID] = useState(''); // ตัวแปรเก็บ id ที่เลือก
  const [selectedPaymentTypes, setSelectedPaymentTypes] = useState<string[]>([]); // ตัวแปรเก็บ paymentType ที่เลือก
  const [isOpenConfirmModal, setIsOpenConfirmModal] = useState(false);
  const [isOpenConfirmP_OfficeModal, setIsOpenConfirmP_OfficeModal] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  console.log('selectedId', selectedId);

  const {
    doctorSalaly: {
      tabs: {
        paymentOffice: { filter, loadDatafilter, listFilter },
      },
    },
  } = useSelector(RefundtoEmployerSelector);

  useEffect(() => {
    if (loadDatafilter) {
      void dispatch(getRefundtoEmployerService(filter.paymentType));
    }
  }, [dispatch, loadDatafilter, filter]);

  const dataSource = useMemo(() => listFilter, [listFilter]);

  useEffect(() => {
    setSelectedPaymentTypes([]);
    setSelectedID('');
  }, [listFilter]);

  const [dataSelected, setDataSelected] = useState<RefundtoEmployerDataType[]>([]);
  // const [dataSelectedActiveTable, setDataSelectedActiveTable] = useState<DataSourceType[]>([]);

  const columns = [
    {
      title: filter.paymentType !== 'p_office' && (
        <Checkbox
          checked={dataSelected.length > 0 && dataSelected.length === listFilter.length} // ตรวจสอบว่ามีรายการที่เลือกและทุกรายการถูกเลือก
          indeterminate={dataSelected.length > 0 && dataSelected.length < listFilter.length} // กรณีเลือกบางแถว
          onChange={(e) => {
            if (e.target.checked) {
              setDataSelected(listFilter); // เลือกทั้งหมด
            } else {
              setDataSelected([]); // ยกเลิกการเลือกทั้งหมด
            }
          }}
        />
      ),
      key: 'checkbox',
      dataIndex: 'paymentType',
      render: (paymentType: string, record: RefundtoEmployerDataType): React.ReactElement => {
        const isChecked = dataSelected.some((item) => item.paymentNo === record.paymentNo); // ตรวจสอบว่าแถวนี้ถูกเลือกหรือไม่
        console.log('isChecked:', isChecked);

        const handleCheckboxChange = (checked: boolean, record: RefundtoEmployerDataType): void => {
          if (record.paymentType === 'p_office') {
            // ถ้า paymentType เป็น 'p_office' จะให้เลือกได้แค่ 1 รายการ
            if (checked) {
              // ตรวจสอบว่าเลือกมากกว่า 1 รายการใน dataSelected หรือไม่
              if (dataSelected.length > 0) {
                setIsOpenConfirmP_OfficeModal(true); // แสดง modal ยืนยันการเลือก
                setDataSelected([]); // ยกเลิกการเลือกทั้งหมด
              } else {
                setDataSelected([record]); // เลือกเฉพาะรายการนี้
                setSelectedPaymentTypes((prevselect) => [...prevselect, paymentType]);
                setSelectedID(record.paymentNo);
              }
            } else {
              setDataSelected([]); // ยกเลิกการเลือก
            }
          } else {
            // สำหรับกรณีทั่วไปให้สามารถเลือกหลายรายการได้
            if (checked) {
              //console.log('id2:', record.paymentOrderNumber);
              if (dataSelected.some((item) => item.paymentType === record.paymentType) === true) {
                setDataSelected((prev) => [...prev, record]); // เพิ่มแถวที่เลือก
                setSelectedPaymentTypes((prevselect) => [...prevselect, paymentType]);
                setSelectedID(record.paymentNo);
              } else {
                setDataSelected([record]);
                setSelectedPaymentTypes([paymentType]);
                setSelectedID(record.paymentNo);
              }
            } else {
              setDataSelected((prev) => prev.filter((item) => item.paymentNo !== record.paymentNo)); // ลบแถวที่ยกเลิกการเลือก
            }
          }
        };

        return (
          <div className='flex justify-center'>
            <Checkbox
              checked={isChecked} // ใช้เพื่อตรวจสอบว่า checkbox ในแถวนี้ถูกเลือกหรือไม่
              onChange={(e) => handleCheckboxChange(e.target.checked, record)} // เมื่อคลิก checkbox
            />
          </div>
        );
      },
    },
    {
      title: 'ลำดับ',
      key: 'no',
      dataIndex: 'no',
      align: 'center',
      render: (chequeNo: number, record: unknown, index: number): React.ReactElement => {
        return <span>{index + 1}</span>;
      },
    },
    filter.paymentType === 'p_banks' && {
      title: 'ธนาคาร',
      key: 'bankCode',
      dataIndex: 'bankCode',
      align: 'center',
    },
    {
      title: 'รหัส สปส.',
      key: 'SSO_BRANCH_CODE',
      dataIndex: 'SSO_BRANCH_CODE',
      align: 'center',
    },
    {
      title: 'เลขที่ใบสั่งจ่าย',
      key: 'paymentNo',
      dataIndex: 'paymentNo',
      align: 'center',
    },
    {
      title: 'เลขที่บัญชีนายจ้าง',
      key: 'bankAccountNo',
      dataIndex: 'bankAccountNo',
      align: 'center',
    },
    {
      title: 'จ่ายให้',
      key: 'offerer',
      dataIndex: 'offerer',
    },

    {
      title: 'จำนวนเงิน',
      key: 'amount',
      dataIndex: 'amount',
      sorter: true,
      align: 'right',
      render: (amount: string): React.ReactElement => {
        const amountNumber = Number(amount);

        return <div>{amountNumber.toLocaleString()}</div>;
      },
    },
  ];

  //เมื่อกด บันทึกใบสั่งจ่าย
  const handleConfirm = (): void => {
    void dispatch(setPaymentNo(selectedId)); //set ค่า PaymentNo ในเก็บ store
    void dispatch(setOptionPaymentTabsActive(selectedPaymentTypes)); //set ค่าOptionPaymentTabsActive เก็บ store

    if (selectedPaymentTypes.includes('p_office')) {
      // จ่าย - รับเงิน ณ สำนักงาน
      router.push(`${URL.readytopay.REpaymentOffice.url}?id=${selectedId}`);
    } else if (selectedPaymentTypes.includes('p_banks')) {
      // โอนผ่านธนาคารโดยจังหวัด
      router.push(`${URL.readytopay.REpaymentBank.url}?id=${selectedId}`);
    } else if (selectedPaymentTypes.includes('p_check')) {
      // ส่งเช็คทางไปรษณีย์
      router.push(`${URL.readytopay.REpaymentCheck.url}?id=${selectedId}`);
    } else if (selectedPaymentTypes.includes('p_money')) {
      // ธนาณัติ
      router.push(`${URL.readytopay.REpaymentMoney.url}?id=${selectedId}`);
    }

    // ล้าง data in table from filter ที่เลือก
    dispatch(clearListFilter());

    //close modal
    setIsOpenConfirmModal(false);
  };

  //เมื่อกด ตกลง รับเงิน ณ สำนักงาน
  const handleConfirmP_Ofiilce = (): void => {
    //close modal
    setIsOpenConfirmP_OfficeModal(false);
  };

  const handleCancel = (): void => {
    setIsOpenConfirmModal(false);
    setIsOpen(false);
  };

  const checkOpenConfirmModal = (): void => {
    if (dataSelected.length === 0 || selectedPaymentTypes.length === 0) {
      setIsOpen(true);
    } else {
      setIsOpenConfirmModal(true);
    }
  };

  //สำหรับ Loading Table รอข้อมูล
  if (loadDatafilter) {
    return (
      <div className='h-[480px] bg-white shadow-sm rounded-xl flex justify-center items-center'>
        <SpinLoading />
      </div>
    );
  }

  return (
    <div className='flex flex-col items-center'>
      <div className='w-full bg-white p-6 shadow-sm rounded-xl relative'>
        <TableListLayout
          textHeader='ผลลัพธ์การค้นหา'
          type='form'
          totalItems={dataSource.length}
          firstLoading={dataSource.length === 0}
          emptyText='โปรดระบุข้อมูลที่ต้องการค้นหา'
          emptyDescription='ไม่มีข้อมูลที่ต้องการแสดงในขณะนี้'
          Grid={<BaseGrid rows={dataSource} columns={columns as ColumnsTypeCustom} />}
        />
      </div>
      <div id={`${dataTestId}-popup-confirm-footer`} className='flex justify-center gap-6 py-6'>
        <BaseButton
          id={`${dataTestId}-popup-confirm-footer-btn-cancel`}
          size='large'
          type='cancel'
          label='ยกเลิก'
          onClick={() => router.push(URL.readytopay.readyToPay.url)}
        />
        <BaseButton
          id={`${dataTestId}-popup-confirm-footer-btn-confirm`}
          // loading={loadingSave}
          // disabled={dataSelected.length === 0 || selectedPaymentTypes.length === 0}
          size='large'
          label='บันทึกใบสั่งจ่าย'
          onClick={checkOpenConfirmModal}
        />
        <BaseDialog
          width='560px'
          isOpen={isOpenConfirmModal}
          setIsOpen={setIsOpenConfirmModal}
          content={
            <div id={`${dataTestId}-popup-confirm-content`} className='flex flex-col w-full gap-4'>
              <div className='text-left font-semibold text-3xl'>บันทึกข้อมูลใช่หรือไม่?</div>
              <div className='text-left status text-[#4B5760]'>กรุณายืนยันการทำรายการอีกครั้ง</div>
            </div>
          }
          headerLeftIcon={
            <BaseIcon
              name='downloadSquare'
              size='40px'
              classNameColor={{
                base: 'text-primary',
                hover: 'text-primary-bright',
                active: 'text-secondary',
                disabled: 'text-primary-very-bright',
              }}
              disabled={false}
              active={false}
            />
          }
          footer={
            <div className='flex justify-center gap-4'>
              <BaseButton size='middle' type='cancel' label='ยกเลิก' onClick={handleCancel} />
              <BaseButton size='middle' label='ยืนยัน' onClick={handleConfirm} />
            </div>
          }
        />
        <BaseDialog
          width='560px'
          isOpen={isOpenConfirmP_OfficeModal}
          setIsOpen={setIsOpenConfirmP_OfficeModal}
          themeIcon='warning'
          content={
            <div id={`${dataTestId}-popup-confirm-content`} className='flex flex-col w-full gap-4'>
              <div className='text-left font-semibold text-3xl'>รับเงิน ณ สำนักงาน</div>
              <div className='text-left status text-[#4B5760]'>
                กรณีรับเงิน ณ สำนักงานไม่สามารถเลือกรายการสั่งจ่ายได้มากกว่า 1 รายการ
              </div>
            </div>
          }
          headerLeftIcon={<InfoCircle />}
          footer={
            <div className='flex justify-center gap-4'>
              <BaseButton size='middle' label='ตกลง' onClick={handleConfirmP_Ofiilce} />
            </div>
          }
        />
        <BaseDialog
          width='560px'
          isOpen={isOpen}
          setIsOpen={setIsOpen}
          themeIcon='warning'
          content={
            <div id={`${dataTestId}-popup-confirm-content`} className='flex flex-col w-full gap-4'>
              <div className='text-left font-semibold text-3xl'>บันทึกใบสั่งจ่าย</div>
              <div className='text-left status text-[#4B5760]'>กรุณาเลือกใบสั่งจ่ายอย่างน้อย 1 รายการ</div>
            </div>
          }
          headerLeftIcon={<InfoCircle />}
          footer={
            <div className='flex justify-center gap-4'>
              <BaseButton size='middle' label='ตกลง' onClick={handleCancel} />
            </div>
          }
        />
      </div>
    </div>
  );
}
