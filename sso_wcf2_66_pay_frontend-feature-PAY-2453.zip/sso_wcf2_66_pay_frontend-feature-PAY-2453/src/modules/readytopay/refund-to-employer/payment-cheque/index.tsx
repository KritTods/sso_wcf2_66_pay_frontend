'use client';
import React, { useState } from 'react';
import { Form, Col, Row } from 'wcf-component-lib/node_modules/antd';
import TableCheck from '@/modules/readytopay/refund-to-employer/component/tableCheque';
import {
  BaseForm,
  BaseButton,
  BaseToastNotification,
  BaseDialog,
  BaseIcon,
  BaseItemTextArea,
} from 'wcf-component-lib/src/components';
import { RefundtoEmployerSelector } from '@/store-redux/slices/readytopay/refund-to-employer';

import { URL } from '@/constants/configPage';
import { useRouter } from 'next/navigation';
import { singleColumn, formColumn } from '@/constants/layoutColumn';
import { requiredRule, maxRule } from 'wcf-component-lib/src/rules/FormRulesFunction';

import { useSelector } from 'react-redux';
import { InfoCircle } from 'wcf-component-lib/node_modules/iconoir-react';

import TablePaymentRequest from '@/modules/readytopay/refund-to-employer/component/tablePaymentRequest';

export default function PaymentCheck(): React.ReactElement {
  const [form] = Form.useForm();
  const router = useRouter();
  const [isOpenConfirmModal, setIsOpenConfirmModal] = useState(false);
  const [isOpenOverPrice, setIsOpenOverPrice] = useState(false); //จำนวนเงินไม่สอดคล้อง
  const [isOpenAddRow, setIsOpenAddRow] = useState(false); //กรุณาเพิ่มเช็คอย่างน้อย 1 รายการ

  const {
    doctorSalaly: {
      tabs: {
        paymentOffice: {
          paymentForm: {
            mode: { view },
          },
        },
      },
    },
  } = useSelector(RefundtoEmployerSelector);

  // console.log('view.tableList', view.tableList);

  const handleBackToMain = (): void => {
    router.push(URL.readytopay.refundToEmployer.url);
  };

  const handleConfirm = (): void => {
    // show notification success
    BaseToastNotification({
      type: 'success',
      message: 'เสร็จสิ้น',
      description: 'ทำรายการเสร็จสิ้น',
    });
    router.push(`${URL.readytopay.REpaymentCheckDetail.url}?tab=cheque`);

    //close modal
    setIsOpenConfirmModal(false);
  };

  const handleCancel = (): void => {
    setIsOpenConfirmModal(false);
    setIsOpenAddRow(false);
    setIsOpenOverPrice(false);
  };

  const onFinish = (): void => {
    const sumTotalTableListCheque = view.tabs.cheque.reduce((acc, item) => {
      return acc + item.amount;
    }, 0);
    console.log('TabActive', view.paymentTabActive);
    console.log('sumTableList', view.sumTableList);
    console.log('sumTotalTableListCheque', sumTotalTableListCheque);

    if (sumTotalTableListCheque !== 0) {
      if (sumTotalTableListCheque === view.sumTableList) {
        setIsOpenConfirmModal(true);
      } else {
        setIsOpenOverPrice(true);
      }
    } else {
      setIsOpenAddRow(true);
    }
  };

  return (
    <div className='flex flex-col gap-4 mx-4'>
      <div className='w-full bg-white p-6 shadow-sm rounded-xl'>
        <div className='flex flex-col'>
          <p className='header-card'>รายละเอียด</p>
          <Row gutter={[16, 16]}>
            <Col {...formColumn}>
              <div>
                <p className='text-label-info'>เลขที่เอกสาร</p>
                <p className='text-display'>0000000000</p>
              </div>
            </Col>
            <Col {...formColumn}>
              <div>
                <p className='text-label-info'>ผู้เตรียมจ่าย</p>
                <p className='text-display'>นพดล สุขใจดี</p>
              </div>
            </Col>
            <Col {...formColumn}>
              <div>
                <p className='text-label-info'>วันที่เตรียมจ่าย</p>
                <p className='text-display'>31/12/2567</p>
              </div>
            </Col>
            <Col {...formColumn}>
              <div>
                <p className='text-label-info'>วิธีการชำระเงิน</p>
                <p className='text-display'>ส่งเช็คทางไปรษณีย์</p>
              </div>
            </Col>
          </Row>
        </div>
      </div>

      {/* Table รายการสั่งจ่าย */}
      <TablePaymentRequest dataTestId={'payment-cheque'} />

      <BaseForm extraForm={form} name='refund-to-employer-payment-cheque-form' onFinish={onFinish}>
        <div className='flex flex-col gap-4'>
          {/* Address */}
          <div className='flex flex-col items-center'>
            <div className='w-full bg-white p-6 shadow-sm relative rounded-xl'>
              <Col {...singleColumn}>
                <p className='header-card'>ส่งเช็คทางไปรษณีย์</p>

                <BaseItemTextArea
                  itemName='address'
                  placeholder='ระบุที่อยู่'
                  label='ที่อยู่'
                  rules={[requiredRule('ที่อยู่'), maxRule('ที่อยู่', 400)]}
                />
              </Col>
            </div>
          </div>

          <TableCheck dataTestId={'payment-cheque-form'} />

          {/* ปุ่ม ยกเลิก/บันทึก */}
          <div className='flex justify-center  gap-4 py-6'>
            <BaseButton
              size='middle'
              type='cancel'
              label='ยกเลิก'
              className='w-[240px]'
              onClick={handleBackToMain} // เรียกฟังก์ชันเมื่อกดปุ่ม
            />
            <BaseButton
              size='middle'
              label='บันทึกข้อมูล'
              className='w-[240px]'
              // htmlType='submit'
              onClick={() => form.submit()}
            />
          </div>

          <BaseDialog
            width='560px'
            isOpen={isOpenConfirmModal}
            setIsOpen={setIsOpenConfirmModal}
            content={
              <div className='flex flex-col w-full gap-4'>
                <div className='text-left font-semibold text-3xl'>บันทึกข้อมูลใช่หรือไม่?</div>
                <div className='text-left status text-[#4B5760]'>กรุณายืนยันการทำรายการอีกครั้ง</div>
              </div>
            }
            headerLeftIcon={
              <BaseIcon
                name='downloadSquare'
                size='40px'
                classNameColor={{
                  base: 'text-primary',
                  hover: 'text-primary-bright',
                  active: 'text-secondary',
                  disabled: 'text-primary-very-bright',
                }}
                disabled={false}
                active={false}
              />
            }
            footer={
              <div className='flex justify-center gap-4'>
                <BaseButton size='middle' type='cancel' label='ยกเลิก' onClick={handleCancel} />
                <BaseButton size='middle' label='ยืนยัน' onClick={handleConfirm} />
              </div>
            }
          />

          <BaseDialog
            width='560px'
            isOpen={isOpenAddRow}
            setIsOpen={setIsOpenAddRow}
            themeIcon='warning'
            content={
              <div className='flex flex-col w-full gap-4'>
                <div className='text-left font-semibold text-3xl'>ไม่สามารถทำรายการได้</div>
                <div className='text-left status text-[#4B5760]'>กรุณาเพิ่มเช็คอย่างน้อย 1 รายการ</div>
              </div>
            }
            headerLeftIcon={<InfoCircle />}
            footer={
              <div className='flex justify-center gap-4'>
                <BaseButton size='middle' label='ตกลง' onClick={handleCancel} />
              </div>
            }
          />

          <BaseDialog
            width='560px'
            isOpen={isOpenOverPrice}
            setIsOpen={setIsOpenOverPrice}
            themeIcon='warning'
            content={
              <div className='flex flex-col w-full gap-4'>
                <div className='text-left font-semibold text-3xl'>จำนวนเงินไม่สอดคล้อง</div>
                <div className='text-left status text-[#4B5760]'>
                  จำนวนเงินสั่งจ่ายไม่สอดคล้องกับจำนวนเงินที่ต้องจ่าย กรุณาตรวจสอบการทำรายการอีกครั้ง
                </div>
              </div>
            }
            headerLeftIcon={<InfoCircle />}
            footer={
              <div className='flex justify-center gap-4'>
                <BaseButton size='middle' label='ตกลง' onClick={handleCancel} />
              </div>
            }
          />
        </div>
      </BaseForm>
    </div>
  );
}
