'use client';
import React, { useEffect, useState } from 'react';
import { Col, Row, TabsProps } from 'wcf-component-lib/node_modules/antd';
import { formColumn } from '@/constants/layoutColumn';
import { BaseTabs, BaseIcon } from 'wcf-component-lib/src/components';

import { useAppDispatch } from '@/store-redux/store';
import { setpaymentTabActive } from '@/store-redux/slices/readytopay/refund-to-employer';

import CardCheque from '@/modules/readytopay/refund-to-employer/payment-office/cardCheque';
import { Cash } from 'wcf-component-lib/node_modules/iconoir-react';
import CardCash from '@/modules/readytopay/refund-to-employer/payment-office/cardCash';
import TablePaymentRequest from '@/modules/readytopay/refund-to-employer/component/tablePaymentRequest';

const PaymentOffice: React.FC = () => {
  const dispatch = useAppDispatch();

  const [activeTab, setActiveTab] = useState<string>('cheque');

  useEffect(() => {
    if (activeTab !== undefined) {
      console.log('activeTab:', activeTab);
      void dispatch(setpaymentTabActive(activeTab));
    }
  }, [dispatch, activeTab]);

  const items: TabsProps['items'] = [
    {
      key: 'cheque',
      label: (
        <div className='flex justify-center'>
          <BaseIcon
            name='payOrders'
            size='24px'
            className='!mr-1'
            classNameColor={{
              base: '!text-primary',
              active: 'white-text',
              disabled: 'text-primary-very-bright',
            }}
            disabled={false}
            active={activeTab === 'cheque'}
          />
          <span>เช็ค</span>
        </div>
      ),
      children: <CardCheque />,
    },
    {
      key: 'cash',
      label: (
        <div className='flex justify-center'>
          <Cash className='mr-2' />
          <span>เงินสด</span>
        </div>
      ),
      children: <CardCash />,
    },
  ];

  return (
    <div className=' flex flex-col justify-center gap-4 mx-5'>
      <div className='w-full bg-white p-6 shadow-sm rounded-xl'>
        <div className='flex flex-col gap-4'>
          <p className='header-card'> รายละเอียด</p>
          <Row gutter={[16, 16]}>
            <Col {...formColumn}>
              <div>
                <p className='text-label-info'>เลขที่เอกสาร</p>
                <p className='text-display'>0000000000</p>
              </div>
            </Col>
            <Col {...formColumn}>
              <div>
                <p className='text-label-info'>ผู้เตรียมจ่าย</p>
                <p className='text-display'>กาญจนา พิเศษ</p>
              </div>
            </Col>
            <Col {...formColumn}>
              <div>
                <p className='text-label-info'>วันที่เตรียมจ่าย</p>
                <p className='text-display'>31/12/2567</p>
              </div>
            </Col>
            <Col {...formColumn}>
              <div>
                <p className='text-label-info'>วิธีการชำระเงิน</p>
                <p className='text-display'>รับเงิน ณ สำนักงาน</p>
              </div>
            </Col>
          </Row>
        </div>
      </div>
      {/* Table รายการสั่งจ่าย */}
      <TablePaymentRequest dataTestId={'payment-office'} />

      <BaseTabs
        noBackground={true}
        className='w-full'
        defaultActiveKey={'1'}
        items={items}
        onChange={(key: string) => setActiveTab(key)}
      />
    </div>
  );
};

export default PaymentOffice;
