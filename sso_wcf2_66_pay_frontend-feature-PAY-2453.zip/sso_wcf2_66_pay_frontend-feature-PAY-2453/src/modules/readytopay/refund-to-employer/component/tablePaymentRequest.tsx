'use client';
import React, { useEffect, useMemo, useState } from 'react';
import { Table } from 'wcf-component-lib/node_modules/antd';
import TableListLayout from 'wcf-component-lib/src/layout/TableListLayout';
import { BaseGrid } from 'wcf-component-lib/src/components/v2';
import { ColumnsTypeCustom } from 'wcf-component-lib/src/components/v2/BaseGrid';
import { useAppDispatch } from '@/store-redux/store';
import { useSelector } from 'react-redux';
import {
  getPaymentDetailService,
  setPaySummary,
  RefundtoEmployerSelector,
} from '@/store-redux/slices/readytopay/refund-to-employer';
import { BaseButton, BaseIcon } from 'wcf-component-lib/src/components';
import { PlusOutlined } from '@ant-design/icons';
import ModalPaymentOrder from '@/modules/readytopay/refund-to-employer/component/modalPaymentOrder';

interface TablePaymentRequestProps {
  dataTestId: string;
}

export default function TablePaymentRequest({ dataTestId }: TablePaymentRequestProps): React.ReactElement {
  const [isOpenCreateModal, setIsOpenCreateModal] = useState(false);
  const dispatch = useAppDispatch();
  const {
    doctorSalaly: {
      optionPaymentTabsActive,
      tabs: {
        paymentOffice: {
          paymentActive,
          paymentForm: {
            mode: { view },
          },
        },
      },
    },
  } = useSelector(RefundtoEmployerSelector);

  console.log('paymentActive', paymentActive, optionPaymentTabsActive);

  useEffect(() => {
    console.log('view.paymentNo', view.paymentNo);
    if (view.paymentNo) {
      void dispatch(getPaymentDetailService(view.paymentNo)); //ดึงค่าจาก api by id
    }
  }, [dispatch, view.paymentNo]);

  const dataSource = useMemo(() => view.tableList, [view.tableList]);
  //console.log('view.tableList', view.tableList);

  //action delete
  // const handleDelete = (key: number): void => {

  // };

  const columns = [
    {
      title: 'ลำดับ',
      align: 'center',
      key: 'no',
      dataIndex: 'no',
      render: (chequeNo: number, record: unknown, index: number): React.ReactElement => {
        return <span>{index + 1}</span>;
      },
    },
    ...(optionPaymentTabsActive === 'p_banks'
      ? [
          {
            title: 'ธนาคาร',
            align: 'center',
            key: 'bankCode',
            dataIndex: 'bankCode',
          },
        ]
      : []),

    {
      title: 'รหัส สปส.',
      align: 'center',
      key: 'SSO_BRANCH_CODE',
      dataIndex: 'SSO_BRANCH_CODE',
    },
    {
      title: 'เลขที่ใบสั่งจ่าย',
      align: 'center',
      key: 'paymentNo',
      dataIndex: 'paymentNo',
    },
    {
      title: 'เลขที่บัญชีนายจ้าง',
      align: 'center',
      key: 'bankAccountNo',
      dataIndex: 'bankAccountNo',
    },
    {
      title: 'จ่ายให้',
      align: 'center',
      key: 'offerer',
      dataIndex: 'offerer',
    },
    {
      title: 'จำนวนเงิน',
      align: 'right',
      key: 'amount',
      dataIndex: 'amount',

      render: (amount: string): React.ReactElement => {
        const amountNumber = Number(amount);

        return <div className='flex justify-end items-center -mb-6'>{amountNumber.toLocaleString()}</div>;
      },
    },
    ...(paymentActive !== 'view'
      ? [
          {
            title: '',
            key: 'action',
            align: 'center',
            width: 50,
            render: (): React.ReactElement => {
              // const key = record.key as number; // ใช้ Type Assertion ถ้าจำเป็น

              return (
                <div className='flex justify-center items-center'>
                  <div className='p-2 -ml-1 bg-[#F9EAEA] rounded-full w-12'>
                    <BaseIcon
                      name='delete'
                      classNameColor={{
                        base: 'text-error',
                        hover: 'text-error',
                        active: 'text-error',
                        disabled: 'text-disable',
                      }}
                      // onClick={() => handleDelete(key)} // ส่ง key ของ row ไปที่ฟังก์ชัน
                    />
                  </div>
                </div>
              );
            },
          },
        ]
      : []),
  ];

  return (
    <>
      <div className='flex flex-col items-center'>
        <div className='w-full bg-white p-6 shadow-sm rounded-xl relative'>
          <TableListLayout
            textHeader='รายการสั่งจ่าย'
            type='form'
            totalItems={dataSource.length}
            headTableContent={
              paymentActive !== 'view' && (
                <BaseButton
                  size='middle'
                  className='!min-w-[240px]'
                  icon={<PlusOutlined />}
                  label='เพิ่มรายการสั่งจ่าย'
                  onClick={() => setIsOpenCreateModal(true)}
                />
              )
            }
            Grid={
              <BaseGrid
                rows={dataSource}
                columns={columns as ColumnsTypeCustom}
                bordered
                summary={(pageData) => {
                  // คำนวณผลรวมของฟิลด์ amount
                  const totalAmount = pageData.reduce((sum, item) => {
                    return sum + (isNaN(Number(item.amount)) ? 0 : Number(item.amount)); // เพิ่มเฉพาะค่าที่เป็นตัวเลข
                  }, 0);

                  //เก็บค่า ผลรวมเข้า store
                  if (totalAmount > 0) {
                    void dispatch(setPaySummary(totalAmount));
                  }

                  // กำหนดค่า colSpan ตามเงื่อนไข
                  const colSpanValue =
                    optionPaymentTabsActive !== 'p_banks'
                      ? paymentActive !== 'view'
                        ? 5 // ไม่มีคอลัมน์เพิ่มเติม
                        : 5 // เมื่อไม่มีคอลัมน์ 'action'
                      : paymentActive !== 'view'
                      ? 6
                      : 6;

                  return (
                    <Table.Summary.Row>
                      <Table.Summary.Cell index={0} colSpan={colSpanValue} className='!bg-gray-200 !rounded-bl-xl'>
                        <p className='px-6 text-right'>รวม</p>
                      </Table.Summary.Cell>
                      <Table.Summary.Cell index={1} className='!bg-gray-200 !rounded-br-xl'>
                        <p className='text-right'>{totalAmount.toLocaleString()}</p>
                      </Table.Summary.Cell>
                      {paymentActive !== 'view' && (
                        <Table.Summary.Cell index={2} className='!bg-gray-200 !rounded-br-xl'></Table.Summary.Cell>
                      )}
                    </Table.Summary.Row>
                  );
                }}
              />
            }
          />
        </div>
      </div>
      <ModalPaymentOrder isOpenModal={isOpenCreateModal} setOpenModal={setIsOpenCreateModal} dataTestId={dataTestId} />
    </>
  );
}
