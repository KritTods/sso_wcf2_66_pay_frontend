import React from 'react';
import { BaseButton, BaseDialog, BaseForm, BaseItemDropdown, BaseItemInput } from 'wcf-component-lib/src/components';
import ModalTable from '@/modules/readytopay/refund-to-employer/component/modalTable';
import { Col, Row } from 'wcf-component-lib/node_modules/antd';
import { searchColumn } from '@/constants/layoutColumn';
import { SearchOutlined } from '@ant-design/icons';

interface Props {
  isOpenModal: boolean;
  setOpenModal: (isOpenModal: boolean) => void;
  dataTestId: string;
  isDisabled?: boolean;
  hideBankColumn?: boolean;
}

export default function ModalPaymentOrder({
  isOpenModal,
  setOpenModal,
  dataTestId = 'modal',
  //isDisabled = false,
  hideBankColumn = false,
}: Props): React.ReactElement {
  //   const [isOpenCreateModal, setIsOpenCreateModal] = useState(false);

  const handleConfirmCreateModal = (): void => {
    //close modal
    setOpenModal(false);
  };
  const handleCancelCreateModal = (): void => {
    setOpenModal(false);
  };

  return (
    <BaseDialog
      width='1500px'
      isOpen={isOpenModal}
      setIsOpen={setOpenModal}
      headerContent={<p className='page-title pt-4'>เพิ่มรายการใบสั่งจ่าย</p>}
      contentCenter={true}
      content={
        <>
          <BaseForm name={'hospita-payment-tab1-search'}>
            <div className='flex flex-col gap-4 '>
              <div className='w-full bg-white'>
                <div className='flex flex-col gap-4'>
                  <Row gutter={[16, 16]}>
                    <Col {...searchColumn}>
                      <BaseItemDropdown
                        // id={`${dataTestId}-paymentNo-input`}
                        label='รหัส สปส.'
                        itemName='tab1_1'
                        placeholder='เลือกรหัส สปส.'
                        rules={[{ required: true, message: 'โปรดเลือกรหัส สปส.' }]}
                      />
                    </Col>
                    <Col {...searchColumn}>
                      <BaseItemInput
                        // id={`${dataTestId}-paymentNo-input`}
                        label='เลขที่ใบสั่งจ่าย'
                        itemName='tab1_2'
                        placeholder='ระบุเลขที่ใบสั่งจ่าย'
                      />
                    </Col>
                    <Col {...searchColumn}>
                      <BaseItemInput
                        // id={`${dataTestId}-paymentNo-input`}
                        label='เลขที่บัญชีนายจ้าง'
                        itemName='tab1_3'
                        placeholder='ระบุเลขที่บัญชีนายจ้าง'
                      />
                    </Col>
                    <Col {...searchColumn}>
                      <BaseItemInput
                        // id={`${dataTestId}-paymentNo-input`}
                        label='ลำดับที่สาขา'
                        itemName='tab1_4'
                        placeholder='ระบุลำดับที่สาขา'
                      />
                    </Col>
                  </Row>
                  <Row gutter={[16, 16]}>
                    <Col {...searchColumn}>
                      <BaseItemInput label='ชื่อสถานประกอบการ' itemName='tab1_5' placeholder='ระบุชื่อสถานประกอบการ' />
                    </Col>
                    <Col {...searchColumn}>
                      <BaseItemDropdown
                        label='ธนาคาร'
                        itemName='bankCode'
                        placeholder='เลือกธนาคาร'
                        id={`${dataTestId}-bankCode-selecter`}
                        disabled={true}
                        option={[{ value: 1, label: 'ธนาคารกรุงเทพ', disabled: false }]}
                        rules={[{ required: true, message: 'โปรดระบุธนาคาร' }]}
                      />
                    </Col>

                    <Col span={12}>
                      <div className='grid place-items-end h-20'>
                        <BaseButton
                          className='!min-w-[200px]'
                          size='middle'
                          icon={<SearchOutlined />}
                          htmlType='submit'
                          label={'ค้นหา'}
                        />
                      </div>
                    </Col>
                  </Row>
                </div>
              </div>
            </div>
          </BaseForm>
          <ModalTable hideBankColumn={hideBankColumn} dataTestId={dataTestId} />
        </>
      }
      footer={
        <div className='flex justify-center gap-4'>
          <BaseButton size='middle' type='cancel' label='ยกเลิก' onClick={handleCancelCreateModal} />
          <BaseButton size='middle' label='ยืนยัน' onClick={handleConfirmCreateModal} />
        </div>
      }
    />
  );
}
