'use client';
import React from 'react';
import { Row, Col } from 'wcf-component-lib/node_modules/antd';
import { formColumn } from '@/constants/layoutColumn';
import TablePaymentRequest from '@/modules/readytopay/refund-to-employer/component/tablePaymentRequest';
import CardTableThananat from '@/modules/readytopay/refund-to-employer/payment-money/cardTableThananat';

export default function REpaymentMoney(): React.ReactElement {
  return (
    <div className='flex flex-col gap-4 mx-4'>
      <div className='w-full bg-white p-6 shadow-sm rounded-xl'>
        <div className='flex flex-col gap-4'>
          <p className='header-card'> รายละเอียด</p>
          <Row gutter={[16, 16]}>
            <Col {...formColumn}>
              <div>
                <p className='text-label-info'>เลขที่เอกสาร</p>
                <p className='text-display'>-</p>
              </div>
            </Col>
            <Col {...formColumn}>
              <div>
                <p className='text-label-info'>ผู้เตรียมจ่าย</p>
                <p className='text-display'>กาญจนา พิเศษ</p>
              </div>
            </Col>
            <Col {...formColumn}>
              <div>
                <p className='text-label-info'>วันที่เตรียมจ่าย</p>
                <p className='text-display'>31/12/2567</p>
              </div>
            </Col>
            <Col {...formColumn}>
              <div>
                <p className='text-label-info'>วิธีการชำระเงิน</p>
                <p className='text-display'>ธนาณัติ</p>
              </div>
            </Col>
          </Row>
        </div>
      </div>
      {/* Table รายการสั่งจ่าย */}
      <TablePaymentRequest dataTestId={'payment-office'} />
      <CardTableThananat />
    </div>
  );
}
