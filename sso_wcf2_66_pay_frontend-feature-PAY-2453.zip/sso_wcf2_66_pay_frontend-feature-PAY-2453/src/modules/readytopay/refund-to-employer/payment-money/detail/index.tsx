'use client';
import React, { useState } from 'react';
import { Form, Row, Col } from 'wcf-component-lib/node_modules/antd';
import { formColumn } from '@/constants/layoutColumn';
import TableListLayout from 'wcf-component-lib/src/layout/TableListLayout';
import BaseGrid, { ColumnsTypeCustom } from 'wcf-component-lib/src/components/v2/BaseGrid';
import { BaseForm, BaseButton, BaseDialog, BaseIcon, BaseToastNotification } from 'wcf-component-lib/src/components';
import { useRouter, useSearchParams } from 'next/navigation';
import TableCheck from '@/modules/readytopay/refund-to-employer/component/tableCheque';
import { URL } from '@/constants/configPage';
import { PrinterOutlined } from '@ant-design/icons';
import TablePaymentRequest from '@/modules/readytopay/refund-to-employer/component/tablePaymentRequest';
import { useAppDispatch } from '@/store-redux/store';
import { useSelector } from 'react-redux';
import { RefundtoEmployerSelector, setPaymentActive } from '@/store-redux/slices/readytopay/refund-to-employer';
import { InfoCircle } from 'wcf-component-lib/node_modules/iconoir-react';

export default function PaymentMoneyDetail(): React.ReactElement {
  const [form] = Form.useForm();
  const router = useRouter();
  const searchParams = useSearchParams();
  const tab = searchParams.get('tab');
  const dispatch = useAppDispatch();
  const [isOpenConfirmModal, setIsOpenConfirmModal] = useState(false); //บันทึกข้อมูลใช่หรือไม่?
  const [isOpenAddRow, setIsOpenAddRow] = useState(false); //กรุณาเพิ่มเช็คอย่างน้อย 1 รายการ
  const [isOpenOverPrice, setIsOpenOverPrice] = useState(false); //จำนวนเงินไม่สอดคล้อง

  const {
    doctorSalaly: {
      tabs: {
        paymentOffice: {
          paymentActive,
          paymentForm: {
            mode: { view },
          },
        },
      },
    },
  } = useSelector(RefundtoEmployerSelector);

  // การเลือกแสดง component ตามค่า tab
  let renderCard;
  if (tab === 'cheque') {
    renderCard = <TableCheck dataTestId={'payment-money'} />;
  } else if (tab === 'cash') {
    renderCard = (
      <div className='w-full bg-white p-6 shadow-sm rounded-xl'>
        <div className='flex flex-col gap-4'>
          <p className='header-card'> สั่งจ่ายโดย : เงินสด</p>
          <Row gutter={[16, 16]}>
            <Col xl={2}>
              <p className='text-label-info'>จำนวนเงิน (บาท)</p>
            </Col>
            <Col xl={4}>
              <p className='text-display'>1,200,000.00</p>
            </Col>
          </Row>
        </div>
      </div>
    );
  }

  const handleChangeActive = (action: 'edit' | 'view' | undefined): void => {
    console.log('action', action);

    void dispatch(setPaymentActive(action));
  };

  // ฟังก์ชันสำหรับกลับไปหน้าหลัก
  const handleBackToMain = (): void => {
    router.push(URL.readytopay.refundToEmployer.url);
  };

  const handleConfirm = (): void => {
    // show notification success
    BaseToastNotification({
      type: 'success',
      message: 'เสร็จสิ้น',
      description: 'ทำรายการเสร็จสิ้น',
    });
    // router.push(`${URL.readytopay.paymentOfficeDetail.url}?tab=1`);

    handleChangeActive('view');
    //close modal
    setIsOpenConfirmModal(false);
  };

  const handleCancel = (): void => {
    setIsOpenConfirmModal(false);
    setIsOpenAddRow(false);
    setIsOpenOverPrice(false);
  };

  const columns = [
    {
      title: 'ลำดับ',
      key: 'no',
      dataIndex: 'no',
      align: 'center',
      width: 50,
      render: (chequeNo: number, record: unknown, index: number): React.ReactElement => {
        return <span>{index + 1}</span>;
      },
    },
    {
      title: 'เลขที่ใบสั่งจ่าย',
      align: 'center',
      key: 'paymentOrderNumber',
      dataIndex: 'paymentOrderNumber',
    },
    {
      title: 'เลขบัตรประชาชน',
      align: 'center',
      key: 'cid',
      dataIndex: 'cid',
    },
    {
      title: 'เลขประสบอันตราย',
      align: 'center',
      key: 'accidentNumber',
      dataIndex: 'accidentNumber',
    },

    {
      title: 'ลูกจ้าง/ผู้มีสิทธิ์',
      align: 'left',
      key: 'employeeOrBeneficiary',
      dataIndex: 'employeeOrBeneficiary',
    },
    {
      title: 'จำนวนเงิน',
      align: 'right',
      key: 'amount',
      dataIndex: 'amount',
    },
  ];

  //Exe
  const [dataSource] = useState([
    {
      key: 1,
      no: '1',
      paymentOrderNumber: '000000001',
      accidentNumber: '100764/0128602/02',
      cid: '01948574493821',
      employeeOrBeneficiary: 'นพดล สุขใจดี',
      amount: '1,200,000.00',
    },
  ]);

  const onFinish = (): void => {
    const sumTotalTableListCheque = view.tabs.cheque.reduce((acc, item) => {
      return acc + item.amount;
    }, 0);
    console.log('TabActive', view.paymentTabActive);
    console.log('sumTableList', view.sumTableList);
    console.log('sumTotalTableListCheque', sumTotalTableListCheque);

    if (sumTotalTableListCheque !== 0) {
      if (sumTotalTableListCheque === view.sumTableList) {
        setIsOpenConfirmModal(true);
      } else {
        setIsOpenOverPrice(true);
      }
    } else {
      setIsOpenAddRow(true);
    }
  };

  return (
    <BaseForm extraForm={form} name='refund-to-employer-payment-money-form' onFinish={onFinish}>
      <div className='flex flex-col gap-4 mx-4'>
        <div className='w-full bg-white p-6 shadow-sm rounded-xl'>
          <div className='flex flex-col gap-4'>
            <p className='header-card'> รายละเอียด</p>
            <Row gutter={[16, 16]}>
              <Col {...formColumn}>
                <div>
                  <p className='text-label-info'>เลขที่เอกสาร</p>
                  <p className='text-display'>0000000000</p>
                </div>
              </Col>
              <Col {...formColumn}>
                <div>
                  <p className='text-label-info'>ผู้เตรียมจ่าย</p>
                  <p className='text-display'>กาญจนา พิเศษ</p>
                </div>
              </Col>
              <Col {...formColumn}>
                <div>
                  <p className='text-label-info'>วันที่เตรียมจ่าย</p>
                  <p className='text-display'>31/12/2567</p>
                </div>
              </Col>
              <Col {...formColumn}>
                <div>
                  <p className='text-label-info'>วิธีการชำระเงิน</p>
                  <p className='text-display'>ธนาณัติ</p>
                </div>
              </Col>
            </Row>
          </div>
        </div>

        {/* Table รายการสั่งจ่าย */}
        <TablePaymentRequest dataTestId={'payment-office'} />

        {/* แสดง component ที่เลือก */}
        {renderCard}

        <div className='flex flex-col justify-center items-center'>
          <div className='w-full bg-white p-6 shadow-sm rounded-xl relative'>
            <TableListLayout
              textHeader='ธนาณัติ'
              type='form'
              totalItems={dataSource.length}
              firstLoading={dataSource.length === 0}
              emptyText='โปรดระบุข้อมูลที่ต้องการค้นหา'
              Grid={<BaseGrid columns={columns as ColumnsTypeCustom} rows={dataSource} />}
            />
          </div>
        </div>

        {/* button action */}
        <div className='flex justify-center gap-4'>
          <BaseButton size='middle' type='cancel' label='ยกเลิก' className='w-[240px]' onClick={handleBackToMain} />
          {paymentActive === 'edit' && (
            <BaseButton
              size='middle'
              type='primary'
              label='บันทึก'
              className='w-[240px]'
              onClick={() => form.submit()}
            />
          )}
          {paymentActive === 'view' && (
            <>
              <BaseButton
                size='middle'
                type='outline'
                label='แก้ไข'
                className='w-[240px]'
                onClick={() => handleChangeActive('edit')}
              />

              <BaseButton size='middle' type='primary' label='ตัดจ่าย' className='w-[240px]' />
              <BaseButton
                size='middle'
                label='พิมหนังสือในนามเช็ค'
                icon={<PrinterOutlined />}
                className='w-[240px]'
                onClick={() => console.log('Print')}
              />
              {tab !== 'cheque' && (
                <BaseButton
                  size='middle'
                  label='พิมพ์หนังสือลงนามในเช็ค'
                  className='!min-w-[280px]'
                  icon={<PrinterOutlined />}
                  onClick={() => console.log('print')}
                />
              )}
            </>
          )}
        </div>

        <BaseDialog
          width='560px'
          isOpen={isOpenConfirmModal}
          setIsOpen={setIsOpenConfirmModal}
          content={
            <div className='flex flex-col w-full gap-4'>
              <div className='text-left font-semibold text-3xl'>บันทึกข้อมูลใช่หรือไม่?</div>
              <div className='text-left status text-[#4B5760]'>กรุณายืนยันการทำรายการอีกครั้ง</div>
            </div>
          }
          headerLeftIcon={
            <BaseIcon
              name='downloadSquare'
              size='40px'
              classNameColor={{
                base: 'text-primary',
                hover: 'text-primary-bright',
                active: 'text-secondary',
                disabled: 'text-primary-very-bright',
              }}
              disabled={false}
              active={false}
            />
          }
          footer={
            <div className='flex justify-center gap-4'>
              <BaseButton size='middle' type='cancel' label='ยกเลิก' onClick={handleCancel} />
              <BaseButton size='middle' label='ยืนยัน' onClick={handleConfirm} />
            </div>
          }
        />

        <BaseDialog
          width='560px'
          isOpen={isOpenAddRow}
          setIsOpen={setIsOpenAddRow}
          themeIcon='warning'
          content={
            <div className='flex flex-col w-full gap-4'>
              <div className='text-left font-semibold text-3xl'>ไม่สามารถทำรายการได้</div>
              <div className='text-left status text-[#4B5760]'>กรุณาเพิ่มเช็คอย่างน้อย 1 รายการ</div>
            </div>
          }
          headerLeftIcon={<InfoCircle />}
          footer={
            <div className='flex justify-center gap-4'>
              <BaseButton size='middle' label='ตกลง' onClick={handleCancel} />
            </div>
          }
        />

        <BaseDialog
          width='560px'
          isOpen={isOpenOverPrice}
          setIsOpen={setIsOpenOverPrice}
          themeIcon='warning'
          content={
            <div className='flex flex-col w-full gap-4'>
              <div className='text-left font-semibold text-3xl'>จำนวนเงินไม่สอดคล้อง</div>
              <div className='text-left status text-[#4B5760]'>
                จำนวนเงินสั่งจ่ายไม่สอดคล้องกับจำนวนเงินที่ต้องจ่าย กรุณาตรวจสอบการทำรายการอีกครั้ง
              </div>
            </div>
          }
          headerLeftIcon={<InfoCircle />}
          footer={
            <div className='flex justify-center gap-4'>
              <BaseButton size='middle' label='ตกลง' onClick={handleCancel} />
            </div>
          }
        />
      </div>
    </BaseForm>
  );
}
