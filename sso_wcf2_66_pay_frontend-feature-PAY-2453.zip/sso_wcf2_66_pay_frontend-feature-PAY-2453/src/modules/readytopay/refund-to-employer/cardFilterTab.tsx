'use client';
import { Bank, HomeSale, DeliveryTruck, MoneySquare } from 'wcf-component-lib/node_modules/iconoir-react';
import { useAppDispatch } from '@/store-redux/store';
import React, { useState } from 'react';
import { Col, Row, FormProps, TabsProps } from 'wcf-component-lib/node_modules/antd';
import { searchColumn, HformSearch } from '@/constants/layoutColumn';
import { BaseForm, BaseItemInput, BaseButton, BaseItemDropdown, BaseTabs } from 'wcf-component-lib/src/components';
import { requiredRule } from 'wcf-component-lib/src/rules/FormRulesFunction';
import { SearchOutlined } from '@ant-design/icons';
// import { getฺฺBeginningBalanceService } from '@/store-redux/slices/reserve/prepare';
// import {
//   getBankAccountSSOService,
//   bankAccountSSOSelector,
//   BankAccountGroupType,
// } from '@/store-redux/slices/masterData/bankAccount';
// import { SelectData } from 'wcf-component-lib/src/constants/interface';
// import { useSelector } from 'react-redux';
// import { isArray } from 'lodash';
// import useLayout from 'wcf-component-lib/src/provider/LayoutProvider/useLayout';
import {
  // ReadyToPaySelector,
  setTabsDoctorSalaly,
  FilterSearchType,
  clearListFilter,
  RefundtoEmployerSelector,
} from '@/store-redux/slices/readytopay/refund-to-employer';
import { useSelector } from 'react-redux';

export default function CardSearchTab({ dataTestId }: { dataTestId: string }): React.ReactElement {
  const dispatch = useAppDispatch();
  const [tabActive, setTabActive] = useState<string>('p_office');
  // const { loading: loadingBankData, bankBranchCodeGroups } = useSelector(bankAccountSSOSelector);
  const {
    doctorSalaly: {
      tabs: {
        paymentOffice: { filter },
      },
    },
  } = useSelector(RefundtoEmployerSelector);

  // const {
  //   stateLayout: { user },
  // } = useLayout();

  const items: TabsProps['items'] = [
    {
      key: 'p_office',
      label: (
        <div className='flex justify-center gap-2'>
          <Bank />
          <span>รับเงิน ณ สำนักงาน</span>
        </div>
      ),
    },
    {
      key: 'p_banks',
      label: (
        <div className='flex justify-center gap-2'>
          <HomeSale />
          <span>โอนผ่านธนาคารโดยจังหวัด</span>
        </div>
      ),
    },
    {
      key: 'p_check',
      label: (
        <div className='flex justify-center gap-2'>
          <DeliveryTruck />
          <span>ส่งเช็คทางไปรษณีย์</span>
        </div>
      ),
    },
    {
      key: 'p_money',
      label: (
        <div className='flex justify-center gap-2'>
          <MoneySquare />
          <span>ธนาณัติ</span>
        </div>
      ),
    },
  ];

  const handleChangeTab = (key: string): void => {
    // เปลี่ยน tab update state tabActive
    setTabActive(key);

    // ล้าง data in table from filter ที่เลือก
    dispatch(clearListFilter());
  };

  //initial form
  // useEffect(() => {
  //   if (!user) return;
  //   //ดึงยอดยกมา
  //   void dispatch(getฺฺBeginningBalanceService(user.ssoBranchCode));
  //   //ดึงข้อมูลธนาคาร
  //   void dispatch(getBankAccountSSOService(user.ssoBranchCode));
  // }, [dispatch, user]);

  // const bankSelectData = useMemo(() => {
  //   //check bankBranchCodeGroups is not undefined
  //   if (!bankBranchCodeGroups) {
  //     return;
  //   }

  //   const data: SelectData[] = [];
  //   isArray(bankBranchCodeGroups) &&
  //     bankBranchCodeGroups.forEach((e: BankAccountGroupType) => {
  //       data.push({
  //         value: e.bankCode,
  //         label: `${e.bankCode} : ${e.bankName}`,
  //       });
  //     });

  //   return data;
  // }, [bankBranchCodeGroups]);

  const onFinish: FormProps<FilterSearchType>['onFinish'] = (values) => {
    const searchObj = {
      paymentOrderNumber_start: values.paymentOrderNumber_start,
      paymentOrderNumber_end: values.paymentOrderNumber_end,
      incidentNumber: values.incidentNumber,
      payDate: '', //values.payDate ? dayjs(values.payDate[0]).format('YYYY-MM-DD') : '',
      bankCode: values.bankCode,
      fullName: values.fullName,
      cid: values.cid,
      advancePaymentType: values.advancePaymentType,
      paymentType: tabActive,
      operation: 'AND',
      pagination: {
        pageNumber: 0,
        pageSize: 10,
        orders: undefined,
      },
    };
    // //เซ็ตค่า filter ที่ส่งเข้ามาจาก action
    void dispatch(setTabsDoctorSalaly(searchObj));
  };

  return (
    <div>
      <BaseTabs defaultActiveKey={tabActive} items={items} onChange={handleChangeTab} />
      <div className='flex p-6 bg-white shadow-sm rounded-b-lg'>
        <BaseForm name='doctor-salary-filter' onFinish={onFinish} initialValues={filter}>
          <div className='w-full bg-white shadow-sm rounded-xl flex flex-row gap-4'>
            <div className='w-[4px] h-[200px] bg-[#1C4651] rounded-full'></div>
            <div className='w-full'>
              <div className='flex flex-col gap-4'>
                <Row gutter={[16, 16]}>
                  <Col {...searchColumn}>
                    <BaseItemDropdown
                      label='รหัส สปส.'
                      itemName='SSOCode'
                      placeholder='เลือกรหัส สปส.'
                      id={`${dataTestId}-bankCode-selecter`}
                      disabled={true}
                      option={[{ value: 1, label: '1200', disabled: false }]}
                      // option={bankSelectData}
                      // loading={loadingBankData}
                    />
                  </Col>
                  <Col {...searchColumn}>
                    <BaseItemInput
                      label='เลขที่ใบสั่งจ่าย'
                      itemName='PaymentOrderNo'
                      placeholder='ระบุเลขประสบอันตราย'
                    />
                  </Col>
                  <Col {...searchColumn}>
                    <BaseItemInput
                      label='เลขที่บัญชีนายจ้าง'
                      itemName='EmployerAccountNo'
                      placeholder='ระบุเลขที่บัญชีนายจ้าง'
                      rules={['p_check'].includes(tabActive) ? [requiredRule('ธนาคาร')] : []}
                    />
                  </Col>
                  <Col {...searchColumn}>
                    <BaseItemInput label='ลำดับที่สาขา' itemName='BranchSequenceNo' placeholder='ระบุลำดับที่สาขา' />
                  </Col>
                </Row>
                <Row gutter={[16, 16]}>
                  <Col {...searchColumn}>
                    <BaseItemInput
                      label='ชื่อสถานประกอบการ'
                      itemName='EstablishmentName'
                      placeholder='ระบุชื่อสถานประกอบการ'
                    />
                  </Col>
                  <Col {...searchColumn}>
                    <BaseItemDropdown
                      label='ธนาคาร'
                      itemName='Bank'
                      placeholder='เลือกธนาคาร'
                      rules={['p_banks'].includes(tabActive) ? [requiredRule('ธนาคาร')] : []}
                      id={`${dataTestId}-bankCode-selecter`}
                      option={[{ value: 1, label: 'ธนาคารกรุงเทพ', disabled: false }]}
                      // option={bankSelectData}
                      // loading={loadingBankData}
                      disabled={['p_office', 'p_check', 'p_money'].includes(tabActive)}
                    />
                  </Col>
                  <Col {...HformSearch}>
                    <div className='grid place-items-end h-20'>
                      <BaseButton
                        className='!min-w-[200px]'
                        size='middle'
                        icon={<SearchOutlined />}
                        htmlType='submit'
                        label={'ค้นหา'}
                      />
                    </div>
                  </Col>
                </Row>
              </div>
            </div>
          </div>
        </BaseForm>
      </div>
    </div>
  );
}
