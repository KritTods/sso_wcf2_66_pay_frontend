import React from 'react';
import CardConsiderDetail from './cardConsider';
import { ReceiveType } from '@/types/payType';
export default function index(): React.ReactElement {
  const dataTestId = 'yourTestId';
  const dataCardConsiderDetail = {
    payDate: '31/12/2567',
    payer: 'กาญจนา พิเศษ',
    status: 'จ่ายเงิน',
    significantNo: '0001670000001E2',
    significantHandNo: '-',
    receiveType: 'O' as ReceiveType,
    receiveName: 'มนัศนันท์ หิมพานต์',
    identityDocument: 'บัตรประชาชน',
    identityNo: '1560100433000',
    address: 'ถนนลาดพร้าว แขวงจอมพล เขตจตุจักร กรุงเทพมหานคร 10900',
    referenceDocument: 'บัตรประชาชน',
    referenceNo: '1560100433000',
  };

  return (
    <div>
      <CardConsiderDetail dataTestId={dataTestId} data={dataCardConsiderDetail} />
    </div>
  );
}
