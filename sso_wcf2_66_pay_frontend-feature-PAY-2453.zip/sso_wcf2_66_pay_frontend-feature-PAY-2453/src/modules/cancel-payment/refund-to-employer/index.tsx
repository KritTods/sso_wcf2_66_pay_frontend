import CardTable from '@/modules/cancel-payment/refund-to-employer/cardTable';
import CardFilterTab from '@/modules/cancel-payment/refund-to-employer/cardFilterTab';

export default function index(): React.ReactElement {
  const dataTestId = 'pageCancelRefundToEmployer';

  return (
    <div className='flex flex-col gap-4 mx-4 mb-6'>
      <CardFilterTab dataTestId={dataTestId} />
      <CardTable dataTestId={dataTestId} />
    </div>
  );
}
