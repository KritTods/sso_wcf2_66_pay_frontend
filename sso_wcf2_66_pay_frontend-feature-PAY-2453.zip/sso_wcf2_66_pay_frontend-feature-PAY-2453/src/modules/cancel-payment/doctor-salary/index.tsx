'use client';
import React from 'react';
import CardTable from '@/modules/cancel-payment/doctor-salary/cardTable';
import CardFilterTab from '@/modules/cancel-payment/doctor-salary/cardFilterTab';

export default function index(): React.ReactElement {
  const dataTestId = 'pageCancelPaymentDoctorSalary';

  return (
    <div className='flex flex-col gap-4 mx-4 mb-6'>
      <CardFilterTab dataTestId={dataTestId} />
      <CardTable dataTestId={dataTestId} />
    </div>
  );
}
