'use client';
import React, { useEffect, useMemo, useState } from 'react';
import { Table, Form } from 'wcf-component-lib/node_modules/antd';
import { formatCurrency } from '@/utils/formatGeneral';
import TableListLayout from 'wcf-component-lib/src/layout/TableListLayout';
import BaseGrid, { ColumnsTypeCustom } from 'wcf-component-lib/src/components/v2/BaseGrid';
import { BaseButton, BaseForm, BaseLoading, BaseToastNotification } from 'wcf-component-lib/src/components';
import { ClockRotateRight } from 'wcf-component-lib/node_modules/iconoir-react';
import { PrinterOutlined } from '@ant-design/icons';
import { URL } from '@/constants/configPage';
import { useSearchParams, useRouter } from 'next/navigation';
import { useAppDispatch } from '@/store-redux/store';
import {
  cutOffPaymentDoctorSalarySelector,
  getDoctorSalaryFormService,
  PageFormType,
  setPageForm,
} from '@/store-redux/slices/cutOffPayment/doctor-salary';
import CardPreparePay from '@/components/common/cardPreparePay';
import CardCash from '@/components/common/cardCash';
import TableCheque from '@/components/common/tableCheque';
import { useSelector } from 'react-redux';
import { useLayout } from 'wcf-component-lib/src/provider/LayoutProvider';
import { PayloadAction } from '@reduxjs/toolkit';
import { PopUpHistory } from '@/modules/test-component/popUpHistory';
import PopUpConfirmSave from '@/components/common/popUps/popUpConfirmSave';
import CardConsider from '@/components/common/cardConsider';
import CardAddress from '@/components/common/cardAddress';

export default function PaymentChequeForm(): React.ReactElement {
  const dataTestId = 'pageCutOffPaymentDoctorSalaryForm';
  const router = useRouter();
  const searchParams = useSearchParams();
  const id = searchParams.get('id');
  const dispatch = useAppDispatch();
  const { loading, pageForm } = useSelector(cutOffPaymentDoctorSalarySelector);
  const [form] = Form.useForm();
  const [formCheque] = Form.useForm();
  const [editCheque, setEditCheque] = useState(false);
  const [isOpenConfirmSave, setIsOpenConfirmSave] = useState(false);
  const [isOpenHistoryModal, setIsOpenHistoryModal] = useState(false);
  const [titleHistoryModal, setTitleHistoryModal] = useState('ประวัติการแก้ไข');
  const [keyTableHistory, setKeyTableHistory] = useState('');

  const {
    stateLayout: { user },
  } = useLayout();

  useEffect(() => {
    if (!id) return;
    // Call API Thunks
    void dispatch(getDoctorSalaryFormService(id));

    const fetchData = async () => {
      const { payload } = (await dispatch(getDoctorSalaryFormService(id))) as PayloadAction<PageFormType>;
      // Set data to form
      dispatch(
        setPageForm({
          ...pageForm,
          ...payload,
        }),
      );
    };

    void fetchData();
  }, [dispatch, id]);

  const columns: ColumnsTypeCustom = [
    {
      title: 'ลำดับ',
      key: 'key',
      dataIndex: 'key',
      align: 'center',
      width: 50,
      render: (text: string, record: unknown, index: number): React.ReactElement => {
        return <span className='w-full flex justify-center'>{index + 1}</span>;
      },
    },
    {
      title: 'เลขที่ใบสั่งจ่าย',
      key: 'paymentNo',
      dataIndex: 'paymentNo',
      align: 'center',
      render: (text: string): React.ReactElement => {
        return <span className='w-full flex justify-center'>{text}</span>;
      },
    },
    {
      title: 'เลขประสบอันตราย',
      key: 'accidentIssueCode',
      dataIndex: 'accidentIssueCode',
      align: 'center',
      render: (text: string): React.ReactElement => {
        return <span className='w-full flex justify-center'>{text}</span>;
      },
    },
    {
      title: 'เลขบัตรประชาชน',
      key: 'employeeCitizenId',
      dataIndex: 'employeeCitizenId',
      align: 'center',
      render: (text: string): React.ReactElement => {
        return <span className='w-full flex justify-center'>{text}</span>;
      },
    },
    {
      title: 'ลูกจ้าง/ผู้มีสิทธิ์',
      key: 'receiverName',
      dataIndex: 'receiverName',
      align: 'center',
      render: (text: string): React.ReactElement => {
        return <span className='w-full flex justify-start'>{text}</span>;
      },
    },
    {
      title: 'จำนวนเงิน',
      key: 'amount',
      dataIndex: 'amount',
      align: 'center',
      render: (text: number): React.ReactElement => {
        return <span className='w-full flex justify-end'>{formatCurrency(text)}</span>;
      },
    },
  ];

  const dataCardPreparePay = useMemo(() => {
    return {
      documentNo: pageForm.cardPreparePay?.documentNo || '',
      paymentAgent: pageForm.cardPreparePay?.paymentAgent || '',
      transactionDate: pageForm.cardPreparePay?.transactionDate || '',
      payType: pageForm.cardPreparePay?.payType || 'X',
    };
  }, [pageForm.cardPreparePay]);

  const dataCardConsider = useMemo(() => {
    if (!user) return;

    return {
      payDate: pageForm.cardConsider?.payDate || '',
      payer: `${user.firstName} ${user.lastName}`,
      status: '-',
    };
  }, [pageForm.cardConsider, user]);

  const dataTableList = useMemo(() => {
    return pageForm.tableList;
  }, [pageForm.tableList]);

  const initialValuesFormCheque = useMemo(() => {
    //ดึงค่าจาก API มาใส่ใน initialValuesFormCheque
    const cheques = pageForm.cheques.map((item) => {
      return {
        id: item.id,
        chequeNo: item.chequeNo,
        amount: item.amount,
        bankCode: item.bankCode,
        chequeStampDate: item.chequeStampDate,
        bankBranchCode: item.bankBranchCode,
        mode: editCheque ? 'edit' : 'view',
      };
    });

    return {
      cheques: cheques,
    };
  }, [editCheque, pageForm.cheques]);

  const initialValuesForm = useMemo(() => {
    return {
      ...pageForm.cardConsider,
    };
  }, [pageForm.cardConsider]);

  const handleConfirm = (): void => {
    // show notification success
    BaseToastNotification({
      type: 'success',
      message: 'บันทึกตัดจ่าย',
      description: 'ทำรายการเสร็จสิ้น',
    });

    router.push(`${URL.cutOffPayment.cutOffPaymentDoctorSalaryChequeDetail.url}?id=1`);

    //close modal
    setIsOpenConfirmSave(false);
    form.resetFields();
  };

  const onSubmit = (values: any): void => {
    console.log('onSubmit :>> ', values);
    setIsOpenConfirmSave(true);
  };

  const dataHistory = useMemo(() => {
    if (keyTableHistory === 'historyPreparePay') {
      return pageForm.historyPreparePay;
    }
    if (keyTableHistory === 'historyOrderPayment') {
      return pageForm.historyOrderPayment;
    }
    if (keyTableHistory === 'historyCheques') {
      return pageForm.historyCheques;
    }
    if (keyTableHistory === 'historyMoneys') {
      return pageForm.historyMoneys;
    }
    if (keyTableHistory === 'historyBanks') {
      return pageForm.historyBanks;
    }

    return [];
  }, [pageForm, keyTableHistory]);

  //loading Page
  if (loading) {
    return <BaseLoading size='default' />;
  }

  return (
    <>
      <BaseForm name='paymentChequeForm' initialValues={initialValuesForm} extraForm={form} onFinish={onSubmit}>
        <div className='flex flex-col gap-4 mx-4 mb-6'>
          {dataCardConsider && <CardConsider dataTestId={dataTestId} data={dataCardConsider} />}

          <div className='flex flex-col justify-center items-center gap-4 bg-white rounded-xl'>
            <CardPreparePay isNotShadow dataTestId={dataTestId} data={dataCardPreparePay} />
            <div className='mb-6'>
              <BaseButton
                icon={<ClockRotateRight />}
                size='large'
                label='ประวัติการแก้ไขเตรียมจ่าย'
                type='outline'
                onClick={() => {
                  setIsOpenHistoryModal(true);
                  setTitleHistoryModal('ประวัติการแก้ไขเตรียมจ่าย');
                  setKeyTableHistory('historyPreparePay');
                }}
              />
            </div>
          </div>

          <div className='w-full bg-white p-6 shadow-sm rounded-xl'>
            <TableListLayout
              totalItems={dataTableList.length}
              textHeader='รายการสั่งจ่าย'
              type='form'
              firstLoading={dataTableList.length === 0}
              emptyText='ไม่พบข้อมูลรายการสั่งจ่าย'
              Grid={
                <BaseGrid
                  rowKey='id'
                  columns={columns}
                  rows={dataTableList}
                  bordered
                  summary={() => {
                    const sumAmount = dataTableList.reduce((prev, curr) => prev + curr.amount, 0);

                    return (
                      <Table.Summary.Row className='bg-gray-200'>
                        <Table.Summary.Cell index={0} colSpan={5} className='rounded-bl-xl'>
                          <p className='text-lg font-bold text-right mx-4'>รวม</p>
                        </Table.Summary.Cell>
                        <Table.Summary.Cell index={1} colSpan={1} className='rounded-br-xl'>
                          <p className='text-lg font-bold text-right'>{formatCurrency(sumAmount)}</p>
                        </Table.Summary.Cell>
                      </Table.Summary.Row>
                    );
                  }}
                />
              }
            />
            <div className='flex justify-center gap-4 mt-6'>
              <BaseButton
                icon={<ClockRotateRight />}
                size='large'
                label='ประวัติการแก้ไขใบสั่งจ่าย'
                type='outline'
                onClick={() => {
                  setIsOpenHistoryModal(true);
                  setTitleHistoryModal('ประวัติการแก้ไขใบสั่งจ่าย');
                  setKeyTableHistory('historyOrderPayment');
                }}
              />
            </div>
          </div>

          {pageForm.address && <CardAddress dataTestId={dataTestId} address={pageForm.address} />}

          {pageForm.isCheque && (
            <BaseForm
              name='paymentChequeFormCheque'
              initialValues={initialValuesFormCheque}
              extraForm={formCheque}
              onFinish={(values) => console.log('onFinish:', values)}
            >
              <div className='w-full bg-white p-6 shadow-sm rounded-xl'>
                {formCheque && (
                  <div className='bg-white rounded-xl -m-6'>
                    <Form.List name='cheques'>
                      {(_, { add, remove }) => {
                        return (
                          <>
                            <TableCheque
                              isNotShadow
                              itemName='cheques'
                              form={formCheque}
                              add={add}
                              remove={remove}
                              mode={editCheque ? 'edit' : 'view'}
                              dataTestId={dataTestId}
                              hideButtonAdd
                              onChange={(data) => {
                                // console.log('data change: ', data);
                                // console.log('BaseForm : ', form.getFieldValue('cheques'));
                              }}
                            />
                          </>
                        );
                      }}
                    </Form.List>
                  </div>
                )}
                <div className='flex justify-center gap-4 mt-6'>
                  {editCheque ? (
                    <>
                      <BaseButton
                        size='large'
                        label='ยกเลิกการแก้ไขเช็ค'
                        type='cancel'
                        onClick={() => {
                          setEditCheque(false);
                          formCheque.resetFields();
                        }}
                      />
                      <BaseButton
                        size='large'
                        label='บันทึกการแก้ไขเช็ค'
                        type='primary'
                        onClick={() => formCheque.submit()}
                      />
                    </>
                  ) : (
                    <>
                      <BaseButton
                        icon={<ClockRotateRight />}
                        size='large'
                        label='ประวัติการแก้ไขเช็ค'
                        type='outline'
                        onClick={() => {
                          setIsOpenHistoryModal(true);
                          setTitleHistoryModal('ประวัติการแก้ไขเช็ค');
                          setKeyTableHistory('historyCheques');
                        }}
                      />
                      <BaseButton size='large' label='แก้ไขเช็ค' type='outline' onClick={() => setEditCheque(true)} />
                    </>
                  )}
                </div>
              </div>
            </BaseForm>
          )}

          {!pageForm.isCheque && <CardCash dataTestId={dataTestId} cash={pageForm.cash} />}

          <div className='flex justify-center gap-4'>
            <BaseButton
              size='large'
              type='cancel'
              label='ยกเลิก'
              className='w-[240px]'
              onClick={() => router.push(URL.cutOffPayment.cutOffPaymentDoctorSalary.url)}
            />

            <BaseButton
              size='large'
              label='พิมหนังสือลงในนามเช็ค'
              icon={<PrinterOutlined />}
              className='w-[280px]'
              onClick={() => {
                console.log('พิมหนังสือลงในนามเช็ค');
              }}
            />
            <BaseButton
              size='large'
              type='primary'
              label='ตัดจ่าย'
              className='w-[240px]'
              onClick={() => form.submit()}
            />
          </div>
        </div>
      </BaseForm>

      <PopUpConfirmSave
        isOpen={isOpenConfirmSave}
        setIsOpen={setIsOpenConfirmSave}
        dataTestId={dataTestId}
        handleConfirm={handleConfirm}
      />

      {/* PopUp History */}
      {dataHistory && (
        <PopUpHistory
          dataTestId={dataTestId}
          isOpen={isOpenHistoryModal}
          setIsOpen={setIsOpenHistoryModal}
          titleTable={titleHistoryModal}
          handleCancel={() => setIsOpenHistoryModal(false)}
          typeData='string'
          align='center'
          data={dataHistory}
        />
      )}
    </>
  );
}
