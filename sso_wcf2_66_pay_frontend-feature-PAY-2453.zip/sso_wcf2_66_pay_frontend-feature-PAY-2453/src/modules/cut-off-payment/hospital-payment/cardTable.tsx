'use client';
import React from 'react';
import TableListLayout from 'wcf-component-lib/src/layout/TableListLayout';
import BaseGrid, { ColumnsTypeCustom } from 'wcf-component-lib/src/components/v2/BaseGrid';
import { DollarCircle } from 'wcf-component-lib/node_modules/iconoir-react';
import { URL } from '@/constants/configPage';
import { useRouter } from 'next/navigation';
import { formatCurrency, formatDayThai } from '@/utils/formatGeneral';
import { statusPayType } from '@/constants/statusSystem';
import { PayType } from '@/types/payType';

export default function CardTable({ dataTestId }: { dataTestId: string }): React.ReactElement {
  const router = useRouter();

  const dataSource = [
    {
      key: '1',
      documentNo: '000000000',
      accidentIssueCode: '100764/0128602/02',
      hospitalName: 'โรงพยาบาล เปาโลเกษตร',
      transactionDate: '2024-12-31',
      payType: 'X',
      amount: 2700000,
      id: '1',
    },
    {
      key: '2',
      documentNo: '000000000',
      accidentIssueCode: '100764/0128602/02',
      hospitalName: 'โรงพยาบาล เปาโลเกษตร',
      transactionDate: '2024-12-31',
      payType: 'T',
      amount: 1500000,
      id: '2',
    },
    {
      key: '3',
      documentNo: '000000000',
      accidentIssueCode: '100764/0128602/02',
      hospitalName: 'โรงพยาบาล เปาโลเกษตร',
      transactionDate: '2024-12-31',
      payType: 'S',
      amount: 1500000,
      id: '3',
    },
    {
      key: '4',
      documentNo: '000000000',
      accidentIssueCode: '100764/0128602/02',
      hospitalName: 'โรงพยาบาล เปาโลเกษตร',
      transactionDate: '2024-12-31',
      payType: 'P',
      amount: 1500000,
      id: '4',
    },
  ];

  const columns = [
    {
      title: 'ลำดับ',
      key: 'key',
      dataIndex: 'key',
      align: 'center',
      widht: 80,
      render: (text: string, record: unknown, index: number): React.ReactElement => {
        return <span className='w-full flex justify-center'>{index + 1}</span>;
      },
    },
    {
      title: 'เลขที่เอกสาร',
      key: 'documentNo',
      dataIndex: 'documentNo',
      align: 'center',
      widht: 140,
      render: (text: string): React.ReactElement => {
        return <span className='w-full flex justify-center'>{text}</span>;
      },
    },
    {
      title: 'เลขประสบอันตราย',
      key: 'accidentIssueCode',
      dataIndex: 'accidentIssueCode',
      align: 'center',
      widht: 180,
      render: (text: string): React.ReactElement => {
        return <span className='w-full flex justify-center'>{text}</span>;
      },
    },
    {
      title: 'โรงพยาบาล',
      key: 'hospitalName',
      dataIndex: 'hospitalName',
      align: 'center',
      widht: 200,
      render: (text: string): React.ReactElement => {
        return <span className='w-full flex justify-start'>{text}</span>;
      },
    },
    {
      title: 'วันที่เตรียมจ่าย',
      key: 'transactionDate',
      dataIndex: 'transactionDate',
      align: 'center',
      widht: 180,
      sorter: true,
      render: (text: string): React.ReactElement => {
        return <span className='w-full flex justify-center'>{formatDayThai(text)}</span>;
      },
    },
    {
      title: 'วิธีการชำระเงิน',
      key: 'payType',
      dataIndex: 'payType',
      align: 'center',
      widht: 220,
      render: (text: string): React.ReactElement => {
        return <span className='w-full flex justify-start'>{statusPayType[text as PayType]}</span>;
      },
    },
    {
      title: 'จำนวนเงิน',
      key: 'amount',
      dataIndex: 'amount',
      align: 'center',
      widht: 200,
      sorter: true,
      render: (text: number): React.ReactElement => {
        return <span className='w-full flex justify-end'>{formatCurrency(text)}</span>;
      },
    },

    {
      title: 'ตัดจ่าย',
      key: 'id',
      dataIndex: 'id',
      align: 'center',
      widht: 100,
      render: (text: string, record: { payType: string; documentNo: string }, index: number): React.ReactElement => {
        const row = record;

        return (
          <>
            <div className='flex justify-center gap-2'>
              <DollarCircle
                id={`${dataTestId}-table-row-${index}-icon`}
                className='cursor-pointer bg-[#E6E6F2] text-[#6666B3] rounded-full w-10 h-10 p-2'
                onClick={() => {
                  if (row.payType === 'X') {
                    router.push(`${URL.cutOffPayment.cutOffHospitalPaymentOffice.url}?id=${row.documentNo}`);
                  } else if (row.payType === 'T') {
                    router.push(`${URL.cutOffPayment.cutOffHospitalPaymentBanke.url}?id=${row.documentNo}`);
                  } else if (row.payType === 'S') {
                    router.push(`${URL.cutOffPayment.cutOffHospitalPaymentCheque.url}?id=${row.documentNo}`);
                  } else if (row.payType === 'P') {
                    router.push(`${URL.cutOffPayment.cutOffHospitalPaymentMoney.url}?id=${row.documentNo}`);
                  } else {
                    console.log('No action for this payment type');
                  }
                }}
              />
            </div>
          </>
        );
      },
    },
  ];

  return (
    <div className='flex flex-col items-center'>
      <div className='w-full bg-white p-6 shadow-sm rounded-xl relative'>
        <TableListLayout
          textHeader='ผลลัพธ์การค้นหา'
          type='form'
          totalItems={dataSource.length}
          firstLoading={dataSource.length === 0}
          emptyText='โปรดระบุข้อมูลที่ต้องการค้นหา'
          emptyDescription='ไม่มีข้อมูลที่ต้องการแสดงในขณะนี้'
          Grid={
            <BaseGrid
              rowKey='id'
              rows={dataSource}
              columns={columns as ColumnsTypeCustom}
              page={{
                pageNumber: 0,
                pageSize: 10,
                totalData: 11,
              }}
              isHaveBorderBottomLeftRight
            />
          }
        />
      </div>
    </div>
  );
}
