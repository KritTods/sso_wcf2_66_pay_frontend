'use client';
import React from 'react';
import { Col, Row } from 'wcf-component-lib/node_modules/antd';
import { searchColumn } from '@/constants/layoutColumn';
import { BaseForm, BaseItemInput, BaseButton, BaseItemDateRangePicker } from 'wcf-component-lib/src/components';
import { maxRule, minRule, onlyNumberRule, requiredRule } from 'wcf-component-lib/src/rules/FormRulesFunction';
import { SearchOutlined } from '@ant-design/icons';
import dayjs from '@/utils/dayjs-setup-th';

export default function CardFilterSearch({ dataTestId }: { dataTestId: string }): React.ReactElement {
  return (
    <div className='flex p-6 bg-white shadow-sm rounded-xl'>
      <BaseForm name='doctorSalaryFilter'>
        <div className='w-full bg-white  rounded-xl flex flex-row gap-4'>
          <div className='w-[4px] h-[200px] bg-[#1C4651] rounded-full'></div>
          <div className='w-full'>
            <div className='flex flex-col gap-4'>
              <Row gutter={[16, 16]}>
                <Col {...searchColumn}>
                  <BaseItemInput
                    id={`${dataTestId}-filter-documentNo-input-text`}
                    label='เลขที่เอกสาร'
                    itemName='documentNo'
                    placeholder='ระบุเลขที่เอกสาร'
                    rules={[onlyNumberRule('เลขที่เอกสาร'), minRule('เลขที่เอกสาร', 15), maxRule('เลขที่เอกสาร', 15)]}
                  />
                </Col>
                <Col {...searchColumn}>
                  <BaseItemInput
                    id={`${dataTestId}-filter-paymentNo-input-text`}
                    label='เลขที่ใบสั่งจ่าย'
                    itemName='paymentNo'
                    placeholder='ระบุเลขที่ใบสั่งจ่าย'
                    rules={[
                      onlyNumberRule('เลขที่ใบสั่งจ่าย'),
                      minRule('เลขที่ใบสั่งจ่าย', 15),
                      maxRule('เลขที่ใบสั่งจ่าย', 15),
                    ]}
                  />
                </Col>

                <Col {...searchColumn}>
                  <BaseItemInput
                    id={`${dataTestId}-filter-noticeName-input-text`}
                    label='จ่ายตามประกาศฉบับที่'
                    itemName='noticeName'
                    placeholder='ระบุประกาศฉบับที่'
                  />
                </Col>
              </Row>
              <Row gutter={[16, 16]}>
                <Col {...searchColumn}>
                  <BaseItemDateRangePicker
                    id={`${dataTestId}-transactionDate-input-date`}
                    itemName='transactionDate'
                    label='วันที่เตรียมจ่าย'
                    placeholder={['เริ่มต้น', 'สิ้นสุด']}
                    minDate={dayjs().startOf('year')}
                    maxDate={dayjs().endOf('year')}
                  />
                </Col>
                <Col span={18}>
                  <div className='grid place-items-end h-20'>
                    <BaseButton
                      id={`${dataTestId}-filter-button-search`}
                      className='!min-w-[200px]'
                      size='middle'
                      icon={<SearchOutlined />}
                      htmlType='submit'
                      label={'ค้นหา'}
                      loading={false}
                    />
                  </div>
                </Col>
              </Row>
            </div>
          </div>
        </div>
      </BaseForm>
    </div>
  );
}
