'use client';
import React, { useState } from 'react';
import { Row, Col } from 'wcf-component-lib/node_modules/antd';
import { BaseButton, BaseForm } from 'wcf-component-lib/src/components';
import { formColumn } from '@/constants/layoutColumn';
import { formatDayThai } from '@/utils/formatGeneral';
import { statusPayType } from '@/constants/statusSystem';
import { PayType } from '@/types/payType';
import { ClockRotateRight } from 'wcf-component-lib/node_modules/iconoir-react';
import ModalEditHistory from '@/modules/cut-off-payment/components/modalEditHistory';

export interface CardPrepareType {
  dataTestId: string;
  data: {
    documentNo: string; // เลขที่เอกสาร
    paymentAgent: string; // ผู้ตเตรียมจ่าย
    transactionDate: string; // วันที่เตรียมจ่าย
    payType: PayType; // ประเภทการจ่าย
  };
}

const CardPreparePay = ({ dataTestId, data }: CardPrepareType): React.ReactElement => {
  const [isOpenHistoryModal, setIsOpenHistoryModal] = useState(false);

  return (
    <div className='w-full bg-white p-6 shadow-sm rounded-xl'>
      <BaseForm>
        <div className='flex flex-col gap-4'>
          <p className='header-card'>ข้อมูลเตรียมจ่าย</p>
          <Row gutter={[16, 16]}>
            <Col {...formColumn}>
              <div>
                <p id={`${dataTestId}-cardTax-documentNo-label-title`} className='text-label-info'>
                  เลขที่เอกสาร
                </p>
                <p id={`${dataTestId}-cardTax-documentNo-label-value`} className='text-display'>
                  {data.documentNo}
                </p>
              </div>
            </Col>
            <Col {...formColumn}>
              <div>
                <p id={`${dataTestId}-cardTax-paymentAgent-label-title`} className='text-label-info'>
                  ผู้เตรียมจ่าย
                </p>
                <p id={`${dataTestId}-cardTax-paymentAgent-label-value`} className='text-display'>
                  {data.paymentAgent}
                </p>
              </div>
            </Col>
            <Col {...formColumn}>
              <div>
                <p id={`${dataTestId}-cardTax-transactionDate-label-title`} className='text-label-info'>
                  วันที่เตรียมจ่าย
                </p>
                <p id={`${dataTestId}-cardTax-transactionDate-label-value`} className='text-display'>
                  {formatDayThai(data.transactionDate)}
                </p>
              </div>
            </Col>
            <Col {...formColumn}>
              <div>
                <p id={`${dataTestId}-cardTax-payType-label-title`} className='text-label-info'>
                  วิธีการชำระเงิน
                </p>
                <p id={`${dataTestId}-cardTax-payType-label-value`} className='text-display'>
                  {statusPayType[data.payType]}
                </p>
              </div>
            </Col>
          </Row>
        </div>
        <div className='flex justify-center gap-4 mt-6'>
          <BaseButton
            icon={<ClockRotateRight />}
            size='large'
            label='ประวัติการแก้ไข'
            type='outline'
            onClick={() => setIsOpenHistoryModal(true)}
          />
        </div>
        <ModalEditHistory
          isOpenModal={isOpenHistoryModal}
          setOpenModal={setIsOpenHistoryModal}
          dataTestId={dataTestId}
        />
      </BaseForm>
    </div>
  );
};

export default CardPreparePay;
