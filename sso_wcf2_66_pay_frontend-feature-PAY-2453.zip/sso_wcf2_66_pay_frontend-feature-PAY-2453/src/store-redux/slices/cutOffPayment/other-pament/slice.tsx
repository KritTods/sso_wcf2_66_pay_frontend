import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { sliceName, initialState, StateProps } from './types';
// import { getRefundtoEmployerService, getPaymentDetailService, getChequeInfoListService } from './thunks';
import { RootState } from '@/store-redux/store';

const otherPaymentSlice = createSlice({
  name: sliceName,
  initialState,
  reducers: {
    setPageOtherPaymentForm: (state, action: PayloadAction<StateProps['pageOtherPaymentForm']>) => {
      state.pageOtherPaymentForm = action.payload;
    },
    setPageOtherPaymentDetail: (state, action: PayloadAction<StateProps['pageOtherPaymentDetail']>) => {
      state.pageOtherPaymentDetail = action.payload;
    },
  },

  extraReducers(builder) {
    //getDetail
    // builder.addCase(getDetail.pending, (state) => {
    //   state.loading = true;
    // });
    // builder.addCase(getDetail.fulfilled, (state, action) => {
    //   state.loading = false;
    // });
    // builder.addCase(getDetail.rejected, (state) => {
    //   state.loading = false;
    // });
  },
});

export const { setPageOtherPaymentForm, setPageOtherPaymentDetail } = otherPaymentSlice.actions;
export default otherPaymentSlice.reducer;
export const otherPaymentSelector = (state: RootState): StateProps => state.otherPaymentSlice;
