import { PayType } from '@/types/payType';
import { TableBankType } from '@/components/common/tableBank';
import { TableMoneyType } from '@/components/common/tableMoney';
import { TableChequeType } from '@/components/common/tableCheque';
export const sliceName = 'otherPayment';

export interface CardHeaderTabType {
  bookNo: string;
  receiverName: string;
  paymentType: string;
}

export const initialCardHeaderTabType: CardHeaderTabType = {
  bookNo: '',
  receiverName: '',
  paymentType: '',
};

export type DataCommonTypeType = {
  cheques: TableChequeType[];
  cash: number;
} & CardHeaderTabType;

export const initialDataCommonType: DataCommonTypeType = {
  cheques: [],
  cash: 0,
  ...initialCardHeaderTabType,
};

export type CardHeaderDetailType = {
  documentNo: string; // เลขที่เอกสาร
  paymentNo: string; // เลขที่คำสั่งจ่าย
  paymentAgent: string; // ผู้จเตียมจ่าย
  transactionDate: string; // วันที่เตรียมจ่าย
  payType: string; // วิธีการชำระเงิน
  receiverName: string; // ลูกจ้าง/ผู้มีสิทธิ์
  bookNo: string; // เลขที่หนังสือ รง.
  paymentType: string; // ประเภทการจ่ายนอกระบบ
};

export const initialCardHeaderDetailType: CardHeaderDetailType = {
  documentNo: '',
  paymentNo: '',
  paymentAgent: '',
  transactionDate: '',
  payType: '',
  receiverName: '',
  bookNo: '',
  paymentType: '',
};

export interface StateProps {
  loading: boolean;
  pageOtherPaymentForm: {
    documentNo: string;
    paymentNo: string;
    payDate: string;
    paymentAgent: string;
    payTypeTabActive: PayType;
    tabs: {
      X: DataCommonTypeType; // รับเงิน ณ สำนักงาน
      T: {
        //โอนผ่านธนาคารโดยจังหวัด
        banks: TableBankType[];
      } & DataCommonTypeType;
      S: {
        //ส่งเช็คทางไปรณษีย์
        address: string;
      } & DataCommonTypeType;
      P: {
        //ธนาณัติ
        moneys: TableMoneyType[];
      } & DataCommonTypeType;
    };
  };
  pageOtherPaymentDetail: {
    isCheque: boolean;
    cheques: TableChequeType[];
    banks: TableBankType[];
    moneys: TableMoneyType[];
    cash: number;
    address: string;
    chequesEdit: TableChequeType[];
    banksEdit: TableBankType[];
    moneysEdit: TableMoneyType[];
  } & CardHeaderDetailType;
}

export const initialState: StateProps = {
  loading: false,
  pageOtherPaymentForm: {
    documentNo: '',
    paymentNo: '',
    payDate: '',
    paymentAgent: '',
    payTypeTabActive: 'X', // รับเงิน ณ สำนักงาน
    tabs: {
      X: initialDataCommonType, // รับเงิน ณ สำนักงาน
      T: {
        //โอนผ่านธนาคารโดยจังหวัด
        ...initialDataCommonType,
        banks: [],
      },
      S: {
        //ส่งเช็คทางไปรณษีย์
        ...initialDataCommonType,
        address: '',
      },
      P: {
        //ธนาณัติ
        ...initialDataCommonType,
        moneys: [],
      },
    },
  },
  pageOtherPaymentDetail: {
    ...initialCardHeaderDetailType,
    isCheque: false,
    cheques: [],
    banks: [],
    moneys: [],
    cash: 0,
    address: '',
    chequesEdit: [],
    banksEdit: [],
    moneysEdit: [],
  },
};
