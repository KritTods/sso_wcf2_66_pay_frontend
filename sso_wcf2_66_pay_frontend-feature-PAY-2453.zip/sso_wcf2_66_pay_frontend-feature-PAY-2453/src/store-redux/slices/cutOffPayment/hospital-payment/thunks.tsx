import { createAsyncThunk } from '@reduxjs/toolkit';
// import { callApi } from 'wcf-component-lib/src/utils/apiServerSide';
// import { omitBy, isNil } from 'lodash';
import { sliceName, HospitalPaymentDataType, TableChequeType } from './types';

//รายการสั่งจ่าย
export const getHospitalPaymentService = createAsyncThunk(
  `${sliceName}/getHospitalPayment`, // เปลี่ยนชื่อ action type
  (paymentType: string): HospitalPaymentDataType[] => {
    const data: HospitalPaymentDataType[] = [
      {
        key: '1',
        checkbox: false,
        bankCode: '006',
        bankName: 'กรุงไทย จำกัด (มหาชน)',
        bankAccountNo: '0000000001',
        bankAccountName: 'นพดล สุขใจดี',
        incidentNumber: '100764/0128602/01',
        paymentOrderNumber: '000000001',
        cid: '01948574493821',
        fullName: 'นพดล สุขใจดี',
        beneficiaryName: 'นพดล สุขใจดี',
        hospitalName: '10001 : โรงพยาบาลกรุงเทพ',
        amount: 250000,
        paymentType: 'p_office',
        accidentNumber: '100764/0128602/02',
        accidentName: 'นพดล สุขใจดี', //ผู้ประสบอันตราย
        hostName: '10001 : โรงพยาบาลกรุงเทพ', //ผู้มีสิทธิ์
        manage: '',
      },
      {
        key: '2',
        checkbox: false,
        bankCode: '006',
        bankName: 'กรุงไทย จำกัด (มหาชน)',
        bankAccountNo: '0000000001',
        bankAccountName: 'นพดล สุขใจดี',
        incidentNumber: '100764/0128602/02',
        paymentOrderNumber: '000000002',
        cid: '01948574493821',
        fullName: 'นพดล สุขใจดี',
        beneficiaryName: 'นพดล สุขใจดี',
        hospitalName: '10001 : โรงพยาบาลกรุงเทพ',
        amount: 250000,
        paymentType: 'p_banks',
        accidentNumber: '100764/0128602/02',
        accidentName: 'นพดล สุขใจดี', //ผู้ประสบอันตราย
        hostName: '10001 : โรงพยาบาลกรุงเทพ', //ผู้มีสิทธิ์
        manage: '',
      },
      {
        key: '3',
        checkbox: false,
        bankCode: '006',
        bankName: 'กรุงไทย จำกัด (มหาชน)',
        bankAccountNo: '0000000001',
        bankAccountName: 'นพดล สุขใจดี',
        incidentNumber: '100764/0128602/03',
        paymentOrderNumber: '000000003',
        cid: '01948574493821',
        fullName: 'นพดล สุขใจดี',
        beneficiaryName: 'นพดล สุขใจดี',
        hospitalName: '10001 : โรงพยาบาลกรุงเทพ',
        amount: 250000,
        paymentType: 'p_check',
        accidentNumber: '100764/0128602/02	',
        accidentName: 'นพดล สุขใจดี', //ผู้ประสบอันตราย
        hostName: '10001 : โรงพยาบาลกรุงเทพ', //ผู้มีสิทธิ์
        manage: '',
      },
      {
        key: '4',
        checkbox: false,
        bankCode: '006',
        bankName: 'กรุงไทย จำกัด (มหาชน)',
        bankAccountNo: '0000000001',
        bankAccountName: 'นพดล สุขใจดี',
        incidentNumber: '100764/0128602/04',
        paymentOrderNumber: '000000004',
        cid: '01948574493821',
        fullName: 'นพดล สุขใจดี',
        beneficiaryName: 'นพดล สุขใจดี',
        hospitalName: '10001 : โรงพยาบาลกรุงเทพ',
        amount: 250000,
        paymentType: 'p_money',
        accidentNumber: '100764/0128602/02	',
        accidentName: 'นพดล สุขใจดี', //ผู้ประสบอันตราย
        hostName: '10001 : โรงพยาบาลกรุงเทพ', //ผู้มีสิทธิ์
        manage: '',
      },
      {
        key: '5',
        checkbox: false,
        bankCode: '006',
        bankName: 'กรุงไทย จำกัด (มหาชน)',
        bankAccountNo: '0000000001',
        bankAccountName: 'นพดล สุขใจดี',
        incidentNumber: '100764/0128602/05',
        paymentOrderNumber: '000000005',
        cid: '01948574493821',
        fullName: 'นพดล สุขใจดี',
        beneficiaryName: 'นพดล สุขใจดี',
        hospitalName: '10001 : โรงพยาบาลกรุงเทพ',
        amount: 250000,
        paymentType: 'p_promptpay',
        accidentNumber: '100764/0128602/02	',
        accidentName: 'นพดล สุขใจดี', //ผู้ประสบอันตราย
        hostName: '10001 : โรงพยาบาลกรุงเทพ', //ผู้มีสิทธิ์
        manage: '',
      },
      {
        key: '6',
        checkbox: false,
        bankCode: '006',
        bankName: 'กรุงไทย จำกัด (มหาชน)',
        bankAccountNo: '0000000001',
        bankAccountName: 'นพดล สุขใจดี',
        incidentNumber: '100764/0128602/06',
        paymentOrderNumber: '000000006',
        cid: '01948574493821',
        fullName: 'นพดล สุขใจดี',
        beneficiaryName: 'นพดล สุขใจดี',
        hospitalName: '10001 : โรงพยาบาลกรุงเทพ',
        amount: 250000,
        paymentType: 'p_office',
        accidentNumber: '100764/0128602/02	',
        accidentName: 'นพดล สุขใจดี', //ผู้ประสบอันตราย
        hostName: '10001 : โรงพยาบาลกรุงเทพ', //ผู้มีสิทธิ์
        manage: '',
      },
      {
        key: '7',
        checkbox: false,
        bankCode: '006',
        bankName: 'กรุงไทย จำกัด (มหาชน)',
        bankAccountNo: '0000000001',
        bankAccountName: 'นพดล สุขใจดี',
        incidentNumber: '100764/0128602/07',
        paymentOrderNumber: '000000007',
        hospitalName: '10001 : โรงพยาบาลกรุงเทพ',
        cid: '01948574493821',
        fullName: 'นพดล สุขใจดี',
        beneficiaryName: 'นพดล สุขใจดี',
        amount: 250000,
        paymentType: 'p_banks',
        accidentNumber: '100764/0128602/02	',
        accidentName: 'นพดล สุขใจดี', //ผู้ประสบอันตราย
        hostName: '10001 : โรงพยาบาลกรุงเทพ', //ผู้มีสิทธิ์
        manage: '',
      },
    ];

    //manipulate data by paymentType
    const resultHospitalPayment = data.filter((item) => item.paymentType === paymentType);

    return resultHospitalPayment;
  },
);
//รายการสั่งจ่าย
export const getPaymentDetailService = createAsyncThunk(
  `${sliceName}/getPaymentDetail`, // เปลี่ยนชื่อ action type
  (paymentOrderNumber: string): HospitalPaymentDataType[] => {
    const data: HospitalPaymentDataType[] = [
      {
        key: '1',
        checkbox: false,
        bankCode: '006',
        bankName: 'กรุงไทย จำกัด (มหาชน)',
        bankAccountNo: '0000000001',
        bankAccountName: 'นพดล สุขใจดี',
        incidentNumber: '100764/0128602/01',
        paymentOrderNumber: '000000001',
        cid: '01948574493821',
        fullName: 'นพดล สุขใจดี',
        beneficiaryName: 'นพดล สุขใจดี',
        hospitalName: '10001 : โรงพยาบาลกรุงเทพ',
        amount: 250000,
        paymentType: 'p_office',
        accidentNumber: '100764/0128602/02	',
        accidentName: 'นพดล สุขใจดี', //ผู้ประสบอันตราย
        hostName: '10001 : โรงพยาบาลกรุงเทพ', //ผู้มีสิทธิ์
        manage: '',
      },
      {
        key: '2',
        checkbox: false,
        bankCode: '006',
        bankName: 'กรุงไทย จำกัด (มหาชน)',
        bankAccountNo: '0000000001',
        bankAccountName: 'นพดล สุขใจดี',
        incidentNumber: '100764/0128602/02',
        paymentOrderNumber: '000000002',
        cid: '01948574493821',
        fullName: 'นพดล สุขใจดี',
        beneficiaryName: 'นพดล สุขใจดี',
        hospitalName: '10001 : โรงพยาบาลกรุงเทพ',
        amount: 250000,
        paymentType: 'p_banks',
        accidentNumber: '100764/0128602/02	',
        accidentName: 'นพดล สุขใจดี', //ผู้ประสบอันตราย
        hostName: '10001 : โรงพยาบาลกรุงเทพ', //ผู้มีสิทธิ์
        manage: '',
      },
      {
        key: '3',
        checkbox: false,
        bankCode: '006',
        bankName: 'กรุงไทย จำกัด (มหาชน)',
        bankAccountNo: '0000000001',
        bankAccountName: 'นพดล สุขใจดี',
        incidentNumber: '100764/0128602/03',
        paymentOrderNumber: '000000003',
        cid: '01948574493821',
        fullName: 'นพดล สุขใจดี',
        beneficiaryName: 'นพดล สุขใจดี',
        hospitalName: '10001 : โรงพยาบาลกรุงเทพ',
        amount: 250000,
        paymentType: 'p_check',
        accidentNumber: '100764/0128602/02	',
        accidentName: 'นพดล สุขใจดี', //ผู้ประสบอันตราย
        hostName: '10001 : โรงพยาบาลกรุงเทพ', //ผู้มีสิทธิ์
        manage: '',
      },
      {
        key: '4',
        checkbox: false,
        bankCode: '006',
        bankName: 'กรุงไทย จำกัด (มหาชน)',
        bankAccountNo: '0000000001',
        bankAccountName: 'นพดล สุขใจดี',
        incidentNumber: '100764/0128602/04',
        paymentOrderNumber: '000000004',
        cid: '01948574493821',
        fullName: 'นพดล สุขใจดี',
        beneficiaryName: 'นพดล สุขใจดี',
        hospitalName: '10001 : โรงพยาบาลกรุงเทพ',
        amount: 250000,
        paymentType: 'p_money',
        accidentNumber: '100764/0128602/02	',
        accidentName: 'นพดล สุขใจดี', //ผู้ประสบอันตราย
        hostName: '10001 : โรงพยาบาลกรุงเทพ', //ผู้มีสิทธิ์
        manage: '',
      },
      {
        key: '5',
        checkbox: false,
        bankCode: '006',
        bankName: 'กรุงไทย จำกัด (มหาชน)',
        bankAccountNo: '0000000001',
        bankAccountName: 'นพดล สุขใจดี',
        incidentNumber: '100764/0128602/05',
        paymentOrderNumber: '000000005',
        cid: '01948574493821',
        fullName: 'นพดล สุขใจดี',
        beneficiaryName: 'นพดล สุขใจดี',
        hospitalName: '10001 : โรงพยาบาลกรุงเทพ',
        amount: 250000,
        paymentType: 'p_promptpay',
        accidentNumber: '100764/0128602/02	',
        accidentName: 'นพดล สุขใจดี', //ผู้ประสบอันตราย
        hostName: '10001 : โรงพยาบาลกรุงเทพ', //ผู้มีสิทธิ์
        manage: '',
      },
      {
        key: '6',
        checkbox: false,
        bankCode: '006',
        bankName: 'กรุงไทย จำกัด (มหาชน)',
        bankAccountNo: '0000000001',
        bankAccountName: 'นพดล สุขใจดี',
        incidentNumber: '100764/0128602/06',
        paymentOrderNumber: '000000006',
        cid: '01948574493821',
        fullName: 'นพดล สุขใจดี',
        beneficiaryName: 'นพดล สุขใจดี',
        hospitalName: '10001 : โรงพยาบาลกรุงเทพ',
        amount: 250000,
        paymentType: 'p_office',
        accidentNumber: '100764/0128602/02	',
        accidentName: 'นพดล สุขใจดี', //ผู้ประสบอันตราย
        hostName: '10001 : โรงพยาบาลกรุงเทพ', //ผู้มีสิทธิ์
        manage: '',
      },
      {
        key: '7',
        checkbox: false,
        bankCode: '006',
        bankName: 'กรุงไทย จำกัด (มหาชน)',
        bankAccountNo: '0000000001',
        bankAccountName: 'นพดล สุขใจดี',
        incidentNumber: '100764/0128602/07',
        paymentOrderNumber: '000000007',
        hospitalName: '10001 : โรงพยาบาลกรุงเทพ',
        cid: '01948574493821',
        fullName: 'นพดล สุขใจดี',
        beneficiaryName: 'นพดล สุขใจดี',
        amount: 250000,
        paymentType: 'p_banks',
        accidentNumber: '100764/0128602/02	',
        accidentName: 'นพดล สุขใจดี', //ผู้ประสบอันตราย
        hostName: '10001 : โรงพยาบาลกรุงเทพ', //ผู้มีสิทธิ์
        manage: '',
      },
    ];

    //manipulate data by paymentType
    const resultPaymentDetail = data.filter((item) => item.paymentOrderNumber === paymentOrderNumber);

    return resultPaymentDetail;
  },
);

export const getChequeInfoListService = createAsyncThunk(
  `${sliceName}/getChequeInfoList`, // เปลี่ยนชื่อ action type
  (paymentOrderNumber: string): TableChequeType[] => {
    const data: TableChequeType[] = [
      {
        id: '1',
        paymentNo: '000000001',
        chequeNo: '81020094',
        bankCode: '006',
        bankName: 'กรุงไทย จำกัด (มหาชน)',
        bankAccountNo: '0000000001',
        bankAccountName: 'นพดล สุขใจดี',
        chequeStampDate: '2024-12-16',
        amount: 250000,
        mode: 'view',
      },
      {
        id: '2',
        paymentNo: '000000002',
        chequeNo: '81020094',
        bankCode: '006',
        bankName: 'กรุงไทย จำกัด (มหาชน)',
        bankAccountNo: '0000000001',
        bankAccountName: 'นพดล สุขใจดี',
        chequeStampDate: '2024-12-16',
        amount: 250000,
        mode: 'view',
      },
      {
        id: '3',
        paymentNo: '000000003',
        chequeNo: '81020094',
        bankCode: '006',
        bankName: 'กรุงไทย จำกัด (มหาชน)',
        bankAccountNo: '0000000001',
        bankAccountName: 'นพดล สุขใจดี',
        chequeStampDate: '2024-12-16',
        amount: 250000,
        mode: 'view',
      },
      {
        id: '4',
        paymentNo: '000000004',
        chequeNo: '81020094',
        bankCode: '006',
        bankName: 'กรุงไทย จำกัด (มหาชน)',
        bankAccountNo: '0000000001',
        bankAccountName: 'นพดล สุขใจดี',
        chequeStampDate: '2024-12-16',
        amount: 250000,
        mode: 'view',
      },
      {
        id: '5',
        paymentNo: '000000005',
        chequeNo: '81020094',
        bankCode: '006',
        bankName: 'กรุงไทย จำกัด (มหาชน)',
        bankAccountNo: '0000000001',
        bankAccountName: 'นพดล สุขใจดี',
        chequeStampDate: '2024-12-16',
        amount: 250000,
        mode: 'view',
      },
      {
        id: '6',
        paymentNo: '000000006',
        chequeNo: '81020094',
        bankCode: '006',
        bankName: 'กรุงไทย จำกัด (มหาชน)',
        bankAccountNo: '0000000001',
        bankAccountName: 'นพดล สุขใจดี',
        chequeStampDate: '2024-12-16',
        amount: 250000,
        mode: 'view',
      },
      {
        id: '7',
        paymentNo: '000000007',
        chequeNo: '81020094',
        bankCode: '006',
        bankName: 'กรุงไทย จำกัด (มหาชน)',
        bankAccountNo: '0000000001',
        bankAccountName: 'นพดล สุขใจดี',
        chequeStampDate: '2024-12-16',
        amount: 250000,
        mode: 'view',
      },
      {
        id: '8',
        paymentNo: '000000008',
        chequeNo: '81020094',
        bankCode: '006',
        bankName: 'กรุงไทย จำกัด (มหาชน)',
        bankAccountNo: '0000000001',
        bankAccountName: 'นพดล สุขใจดี',
        chequeStampDate: '2024-12-16',
        amount: 250000,
        mode: 'view',
      },
    ];

    //manipulate data by paymentType
    const resultChequeInfoList = data.filter((item) => item.paymentNo === paymentOrderNumber);

    return resultChequeInfoList;
  },
);
