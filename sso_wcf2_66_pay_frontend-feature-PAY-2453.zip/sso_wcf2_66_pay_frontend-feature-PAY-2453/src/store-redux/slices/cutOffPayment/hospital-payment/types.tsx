import { Pagination } from 'wcf-component-lib/src/constants/interface';
import { pagination } from 'wcf-component-lib/src/constants/initialValue';
export const sliceName = 'HospitalPayment';

// FilterSearch
export interface FilterSearchType {
  paymentOrderNumber_start: string; // เลขที่ใบสั่งจ่าย
  paymentOrderNumber_end: string; // เลขที่ใบสั่งจ่าย
  incidentNumber: string; // เลขประสบอันตราย
  payDate: string; // วันที่เตรียมจ่าย
  bankCode: string; // ธนาคาร
  fullName: string; // ชื่อ - นามสกุล
  cid: string; // เลขบัตรประชาชน
  advancePaymentType: string; // ประเภทเบิกเงินรองจ่าย
  paymentType: string; //ประเภทการจ่ายเงิน
  pagination: Pagination;
}

export const filter: FilterSearchType = {
  paymentOrderNumber_start: '',
  paymentOrderNumber_end: '',
  incidentNumber: '',
  payDate: '',
  bankCode: '',
  fullName: '',
  cid: '',
  advancePaymentType: '',
  paymentType: '',
  pagination,
};

//รายการสั่งจ่าย
export interface HospitalPaymentDataType {
  key: string;
  checkbox: boolean;
  bankCode: string; // ธนาคาร
  bankName: string; // ชื่อธนาคาร
  bankAccountNo: string; // เลขบัญชี
  bankAccountName: string; // ชื่อบัญชี
  paymentOrderNumber: string; // เลขที่ใบสั่งจ่าย
  incidentNumber: string; // เลขประสบอันตราย
  cid: string; // เลขบัตรประชาชน
  fullName: string; // ชื่อ - นามสกุล
  beneficiaryName: string; // ลูกจ้าง/ผู้มีสิทธิ์
  hospitalName: string;
  amount: number; // จำนวนเงิน
  paymentType: string; //ประเภทการจ่ายเงิน
  accidentNumber: string; //เลขประสบอันตราย
  accidentName: string; //ผู้ประสบอันตราย
  hostName: string; //ผู้มีสิทธิ์
  manage: string;
}

//for ChequePayment
export interface ConInvoiceListType {
  id: string;
  invoiceCode: string;
  invoiceType: string;
  year: string;
  accountNo: string;
  accountBranch: string;
  dueDate: string;
  payInvoiceStatus: string;
  returnChequeAmount: number;
  debitRemainMoney: number;
  fineRemain: number;
  debitRemainMoneyNew?: number;
  fineRemainNew?: number;
}

export interface SetPaySummaryType {
  summaryPay: number;
}

export const setTotal: SetPaySummaryType = {
  summaryPay: 0,
};

export interface TableChequeType {
  id: string;
  paymentNo: string;
  chequeNo: string;
  bankCode: string; // ธนาคาร
  bankName: string; // ชื่อธนาคาร
  bankAccountNo: string; // เลขบัญชี
  bankAccountName: string; // ชื่อบัญชี
  amount: number;
  chequeStampDate: string;
  mode?: 'view' | 'edit' | 'add';
}

export type PaymentActiveType = 'view' | 'edit' | 'add' | undefined;

export interface StateProps {
  doctorSalaly: {
    optionPaymentTabsActive: string;
    tabs: {
      paymentOffice: {
        loading: boolean;
        loadDatafilter: boolean;
        filter: FilterSearchType;
        listFilter: HospitalPaymentDataType[];
        totalElements: number;
        paymentActive: PaymentActiveType;
        paymentForm: {
          mode: {
            view: {
              loading: boolean;
              paymentType: string;
              tableList: HospitalPaymentDataType[]; //รายการสั่งจ่าย
              sumTableList: number;
              paymentNo: string;
              paymentTabActive: string;
              tabs: {
                cheque: TableChequeType[]; //รายการหน้ารายละเอียด mode view
                cash: number;
              };
            };
            edit: {
              loading: boolean;
              paymentType: string;
              tableList: HospitalPaymentDataType[];
              sumTableList: number;
              paymentNo: string;
              paymentTabActive: string;
              tabs: {
                cheque: TableChequeType[]; //รายการหน้ารายละเอียด mode view
                cash: number;
              };
            };
          };
        };
        paymentDetail: {
          loadData: boolean;
          tableList: HospitalPaymentDataType[]; //เพิ่ม-ลบ รายการสั่งจ่ายเมื่อ mode edit
          paymentTabActive: string;
          paymentNo: string;
          tabs: {
            cheque: TableChequeType[];
            cash: number;
          };
          //รอ Action ตัดจ่าย
          mode: 'view' | 'edit';
          tableListModalAdd: HospitalPaymentDataType[]; //ใช้เมื่อค้นหาข้อมูล และ เลือกรายการ -> โยนค่าไปใสใน บรรทัดที่ 103
        };
      };
    };
  };
}

export const initialState: StateProps = {
  doctorSalaly: {
    optionPaymentTabsActive: 'p_office',
    tabs: {
      paymentOffice: {
        loading: false,
        loadDatafilter: false,
        filter,
        listFilter: [],
        totalElements: 0,
        paymentActive: 'edit',
        paymentForm: {
          mode: {
            view: {
              loading: false,
              paymentType: '',
              tableList: [],
              sumTableList: 0,
              paymentNo: '',
              paymentTabActive: 'cheque',
              tabs: {
                cheque: [], //รายการหน้ารายละเอียด mode view
                cash: 0,
              },
            },
            edit: {
              loading: false,
              paymentType: '',
              tableList: [],
              sumTableList: 0,
              paymentNo: '',
              paymentTabActive: '',
              tabs: {
                cheque: [], //รายการหน้ารายละเอียด mode view
                cash: 0,
              },
            },
          },
        },
        paymentDetail: {
          loadData: false,
          tableList: [], //เพิ่ม-ลบ รายการสั่งจ่ายเมื่อ mode edit
          paymentTabActive: '',
          paymentNo: '',
          tabs: {
            cheque: [],
            cash: 0,
          },
          //รอ Action ตัดจ่าย
          mode: 'view',
          tableListModalAdd: [], //ใช้เมื่อค้นหาข้อมูล และ เลือกรายการ -> โยนค่าไปใสใน บรรทัดที่ 103
        },
      },
    },
  },
};
