import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { sliceName, initialState, StateProps, FilterSearchType, TableChequeType, PaymentActiveType } from './types';
import { getRefundtoEmployerService, getPaymentDetailService, getChequeInfoListService } from './thunks';
import { RootState } from '@/store-redux/store';

const RefundtoEmployerSlice = createSlice({
  name: sliceName,
  initialState,
  reducers: {
    setTabsDoctorSalaly: (state, action) => {
      state.doctorSalaly.tabs.paymentOffice.filter = {
        ...state.doctorSalaly.tabs.paymentOffice.filter,
        ...action.payload,
      } as FilterSearchType; // ใช้เฉพาะ filter ปัจจุบัน
      state.doctorSalaly.tabs.paymentOffice.loadDatafilter = true;
    },
    clearListFilter: (state) => {
      state.doctorSalaly.tabs.paymentOffice.listFilter = [];
    },
    //เซตค่า ผลรวม รายการสั่งจ่าย
    setOptionPaymentTabsActive: (state, action) => {
      state.doctorSalaly.optionPaymentTabsActive = String(action.payload);
    },

    //เซตค่า paymentNo
    setPaymentNo: (state, action) => {
      state.doctorSalaly.tabs.paymentOffice.paymentForm.mode.view.paymentNo = String(action.payload);
    },

    //เซตค่า ผลรวม รายการสั่งจ่าย
    setPaySummary: (state, action) => {
      state.doctorSalaly.tabs.paymentOffice.paymentForm.mode.view.sumTableList = Number(action.payload);
    },

    //เซตค่า PaymentActive view-edit
    setPaymentActive: (state, action: PayloadAction<PaymentActiveType>) => {
      console.log('action.payload:', action.payload);
      state.doctorSalaly.tabs.paymentOffice.paymentActive = action.payload;
    },

    //set tab active เช็ค-เงินสด view/edit/add
    setpaymentTabActive: (state, action) => {
      state.doctorSalaly.tabs.paymentOffice.paymentForm.mode.view.paymentTabActive = String(action.payload);
    },

    //เซตค่าเข้า เช็ค และ เงินสด
    addChequeData: (state, action) => {
      state.doctorSalaly.tabs.paymentOffice.paymentForm.mode.view.tabs.cheque = action.payload as TableChequeType[];
    },

    addCashData: (state, action) => {
      state.doctorSalaly.tabs.paymentOffice.paymentForm.mode.view.tabs.cash = Number(action.payload);
    },
  },

  extraReducers(builder) {
    //TableListAll
    builder.addCase(getRefundtoEmployerService.pending, (state) => {
      state.doctorSalaly.tabs.paymentOffice.loadDatafilter = true;
    });
    builder.addCase(getRefundtoEmployerService.fulfilled, (state, action) => {
      state.doctorSalaly.tabs.paymentOffice.listFilter = action.payload;
      state.doctorSalaly.tabs.paymentOffice.loadDatafilter = false;
    });
    builder.addCase(getRefundtoEmployerService.rejected, (state) => {
      state.doctorSalaly.tabs.paymentOffice.loadDatafilter = false;
    });

    //paymentDetailAll
    builder.addCase(getPaymentDetailService.pending, (state) => {
      state.doctorSalaly.tabs.paymentOffice.paymentForm.mode.view.loading = true;
    });
    builder.addCase(getPaymentDetailService.fulfilled, (state, action) => {
      state.doctorSalaly.tabs.paymentOffice.paymentForm.mode.view.tableList = action.payload;
      state.doctorSalaly.tabs.paymentOffice.paymentForm.mode.view.loading = false;
    });
    builder.addCase(getPaymentDetailService.rejected, (state) => {
      state.doctorSalaly.tabs.paymentOffice.paymentForm.mode.view.loading = false;
    });

    //getChequeInfoListService
    builder.addCase(getChequeInfoListService.pending, (state) => {
      state.doctorSalaly.tabs.paymentOffice.paymentForm.mode.view.loading = true;
    });
    builder.addCase(getChequeInfoListService.fulfilled, (state, action) => {
      state.doctorSalaly.tabs.paymentOffice.paymentForm.mode.view.tabs.cheque = action.payload;
      state.doctorSalaly.tabs.paymentOffice.paymentForm.mode.view.loading = false;
    });
    builder.addCase(getChequeInfoListService.rejected, (state) => {
      state.doctorSalaly.tabs.paymentOffice.paymentForm.mode.view.loading = false;
    });
  },
});

export const {
  setTabsDoctorSalaly,
  clearListFilter,
  setPaySummary,
  addChequeData,
  addCashData,
  setpaymentTabActive,
  setPaymentNo,
  setPaymentActive,
  setOptionPaymentTabsActive,
} = RefundtoEmployerSlice.actions;
export default RefundtoEmployerSlice.reducer;
export const RefundtoEmployerSelector = (state: RootState): StateProps => state.RefundtoEmployerSlice;
