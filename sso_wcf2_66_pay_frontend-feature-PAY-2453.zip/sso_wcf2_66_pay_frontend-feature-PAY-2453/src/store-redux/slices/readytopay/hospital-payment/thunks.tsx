import { createAsyncThunk } from '@reduxjs/toolkit';
import { callApi } from 'wcf-component-lib/src/utils/apiServerSide';
import { omitBy, isEmpty } from 'lodash';
import { FilterSearchType, sliceName } from './types';

//for map data this response
export interface GetFilterListServiceType {
  content: {
    paymentId: string;
    paymentNo: string;
    accidentIssueCode: string;
    employeeCitizenId: string;
    fullName: string;
    compensationPerPerson: number;
    amount?: number;
    hospital: string;
    bank?: {
      code: string;
      name: string;
    };
  }[];
  totalElements: number;
  number: number;
}

export interface GetHistoryByCidServiceType {
  paymentCode: 'string'; //เลขที่ใบสั่งจ่าย
  accidentIssueCode: 'string'; //เลขประสบอันตราย
  employeeCitizenId: 'string'; //เลขบัตรประชาชน
  treatmentName: 'string'; //รายการเงินทดแทน
  payDate: 'string'; //วันที่จ่าย
  payType: 'string'; //จ่ายโดย
  paymentId: 'string'; //รหัสใบสั่งจ่าย
  fullName: 'string'; //จ่ายให้ (ลูกจ้าง/ผู้มีสิทธิ์)
  compensationPerPerson: number; //จำนวนเงิน
  hospital: 'string'; //โรงพยาบาล
}

export interface GetPaymentDetailsServiceType {
  details: {
    investigatedLogCode: string;
    companyName: string;
    accidentIssuesCode: string;
    businessType: string;
    accountNo: string;
    businessGroup: string;
    accidentDate: string;
    informDate: string;
    tsic: {
      code: string;
      description: string;
    };
  };
  accidentInformation: {
    employeeCid: string;
    employeeName: string;
    careerPosition: {
      code: string;
      description: string;
    };
    accidentOrganSubGroup: {
      code: string;
      description: string;
    };
    position: string;
    accidentItem: {
      code: string;
      description: string;
    };
    accidentCauseText: string;
    accidentCase: {
      code: string;
      description: string;
    };
    accidentInjuryText: string;
    accidentInjury: {
      code: string;
      description: string;
    };
  };
  investigate: {
    treatmentDescription: string;
    investigateType: {
      code: string;
      description: string;
    };
    result: string;
    amount: number;
    expiryDate: string;
    compensationFee: number;
  };
  payment: {
    paymentCode: string;
    paymentStatus: string;
    payTo: string;
    payBy: string;
    payIndex: string;
    destinationPortal: string;
    paymentDate: string;
    createdBy: string;
    paymentNo: string;
  };
  hospitalBillingInvoice: {
    invoiceNo: string;
    hospital: string;
    hospitalInSystem: string;
    startDate: string;
    endDate: string;
    month: number;
    day: number;
    amount: number;
    paidAmount: number;
  }[];
  paymentInvoice: {
    treatMentDescription: string;
    startDate: string;
    endDate: string;
    month: number;
    day: number;
    amount: number;
  }[];
  approval: {
    status: string;
    date: string;
    approver: string;
  };
}

//ค้นหาข้อมูลหน้าหลัก
export const getFilterListService = createAsyncThunk(
  `${sliceName}/prepare-to-pay/list`,
  async (data: FilterSearchType) => {
    //remove empty value in data
    const manipulateData = omitBy(data, (value) => isEmpty(value) || value === undefined);

    const dataBody = {
      ...manipulateData,
      payToCode: '3',
      payType: manipulateData.paymentType === 'T' ? 'B' : manipulateData.paymentType, // แปลง T เป็น B เปฉพาะประเภทจ่ายงานโรงพยาบาล
      startPaymentNo: '',
      endPaymentNo: '',
      pagination: {
        ...manipulateData.pagination,
      },
    };
    // กรณีมีการกรอกเลขที่ใบสั่งจ่าย
    if (manipulateData.paymentNo && manipulateData.paymentNo.start && manipulateData.paymentNo.end) {
      dataBody.startPaymentNo = manipulateData.paymentNo.start;
      dataBody.endPaymentNo = manipulateData.paymentNo.end;
    }

    //convert data pagination.orders property from name "amount" to "compensationPerPerson"
    if (manipulateData.pagination && manipulateData.pagination.orders && manipulateData.pagination.orders.length > 0) {
      dataBody.pagination.orders = manipulateData.pagination.orders.map((item) => {
        if (item.property === 'amount') {
          return { ...item, property: 'compensationPerPerson' };
        }

        return item;
      });
    }

    const response = await callApi({
      method: 'post',
      url: 'prepare-to-pay/list',
      body: dataBody,
      instanceName: 'pay',
    });

    const { content, totalElements, number } = response as GetFilterListServiceType;

    //loop map data
    const manipulateDataContent = content.map((item) => {
      return {
        ...item,
        amount: item.compensationPerPerson,
        bank: {
          code: '001',
          name: 'Bank A รอเพิ่ม API',
        },
      };
    });

    return { content: manipulateDataContent, totalElements, number };
  },
);

export const getHistoryByCidService = createAsyncThunk(`${sliceName}/history-by-cid`, async (cid: string) => {
  const response = (await callApi({
    method: 'get',
    url: `prepare-to-pay/history/cid/${cid}`,
    instanceName: 'pay',
  })) as GetHistoryByCidServiceType[];

  return response;
});

export const getPaymentDetailsService = createAsyncThunk(
  `${sliceName}/prepare-to-pay/payment/hospital`,
  async (paymentCode: string) => {
    const response = (await callApi({
      method: 'get',
      url: `prepare-to-pay/payment/hospital/${paymentCode}`,
      instanceName: 'pay',
    })) as GetPaymentDetailsServiceType;

    return response;
  },
);

// //รายการสั่งจ่าย
// export const getRefundtoEmployerService = createAsyncThunk(
//   `${sliceName}/getRefundtoEmployer`, // เปลี่ยนชื่อ action type
//   (paymentType: string): RefundtoEmployerDataType[] => {
//     const data: RefundtoEmployerDataType[] = [
//       {
//         key: '1',
//         checkbox: false,
//         bankCode: '006',
//         bankName: 'กรุงไทย จำกัด (มหาชน)',
//         bankAccountNo: '0000000001',
//         bankAccountName: 'กาญจนา พิเศษ',
//         SSO_BRANCH_CODE: '1050',
//         paymentNo: '000000001',
//         offerer: '000 : อรุณเซอร์วิส แอนด์ ซัพพลาย',
//         amount: 1200000,
//         paymentType: 'p_office',
//         manage: '',
//       },
//       {
//         key: '2',
//         checkbox: false,
//         bankCode: '006',
//         bankName: 'กรุงไทย จำกัด (มหาชน)',
//         bankAccountNo: '0000000002',
//         bankAccountName: 'กาญจนา พิเศษ',
//         SSO_BRANCH_CODE: '1050',
//         paymentNo: '000000001',
//         offerer: '000 : อรุณเซอร์วิส แอนด์ ซัพพลาย',
//         amount: 1200000,
//         paymentType: 'p_banks',
//         manage: '',
//       },
//       {
//         key: '3',
//         checkbox: false,
//         bankCode: '006',
//         bankName: 'กรุงไทย จำกัด (มหาชน)',
//         bankAccountNo: '0000000003',
//         bankAccountName: 'กาญจนา พิเศษ',
//         SSO_BRANCH_CODE: '1050',
//         paymentNo: '000000001',
//         offerer: '000 : อรุณเซอร์วิส แอนด์ ซัพพลาย',
//         amount: 1200000,
//         paymentType: 'p_check',
//         manage: '',
//       },
//       {
//         key: '4',
//         checkbox: false,
//         bankCode: '006',
//         bankName: 'กรุงไทย จำกัด (มหาชน)',
//         bankAccountNo: '0000000004',
//         bankAccountName: 'กาญจนา พิเศษ',
//         SSO_BRANCH_CODE: '1050',
//         paymentNo: '000000001',
//         offerer: '000 : อรุณเซอร์วิส แอนด์ ซัพพลาย',
//         amount: 1200000,
//         paymentType: 'p_money',
//         manage: '',
//       },
//       {
//         key: '5',
//         checkbox: false,
//         bankCode: '006',
//         bankName: 'กรุงไทย จำกัด (มหาชน)',
//         bankAccountNo: '0000000001',
//         bankAccountName: 'กาญจนา พิเศษ',
//         SSO_BRANCH_CODE: '1050',
//         paymentNo: '000000005',
//         offerer: '000 : อรุณเซอร์วิส แอนด์ ซัพพลาย',
//         amount: 1200000,
//         paymentType: 'p_office',
//         manage: '',
//       },
//       {
//         key: '6',
//         checkbox: false,
//         bankCode: '006',
//         bankName: 'กรุงไทย จำกัด (มหาชน)',
//         bankAccountNo: '0000000006',
//         bankAccountName: 'กาญจนา พิเศษ',
//         SSO_BRANCH_CODE: '1050',
//         paymentNo: '000000006',
//         offerer: '000 : อรุณเซอร์วิส แอนด์ ซัพพลาย',
//         amount: 1200000,
//         paymentType: 'p_check',
//         manage: '',
//       },
//       {
//         key: '7',
//         checkbox: false,
//         bankCode: '006',
//         bankName: 'กรุงไทย จำกัด (มหาชน)',
//         bankAccountNo: '0000000007',
//         bankAccountName: 'กาญจนา พิเศษ',
//         SSO_BRANCH_CODE: '1050',
//         paymentNo: '000000007',
//         offerer: '000 : อรุณเซอร์วิส แอนด์ ซัพพลาย',
//         amount: 1200000,
//         paymentType: 'p_banks',
//         manage: '',
//       },
//     ];

//     //manipulate data by paymentType
//     const resultRefundtoEmployer = data.filter((item) => item.paymentType === paymentType);

//     return resultRefundtoEmployer;
//   },
// );
// //รายการสั่งจ่าย
// export const getPaymentDetailService = createAsyncThunk(
//   `${sliceName}/getPaymentDetail`, // เปลี่ยนชื่อ action type
//   (paymentNo: string): RefundtoEmployerDataType[] => {
//     const data: RefundtoEmployerDataType[] = [
//       {
//         key: '1',
//         checkbox: false,
//         bankCode: '006',
//         bankName: 'กรุงไทย จำกัด (มหาชน)',
//         bankAccountNo: '0000000001',
//         bankAccountName: 'กาญจนา พิเศษ',
//         SSO_BRANCH_CODE: '1050',
//         paymentNo: '000000001',
//         offerer: '000 : อรุณเซอร์วิส แอนด์ ซัพพลาย',
//         amount: 1200000,
//         paymentType: 'p_office',
//         manage: '',
//       },
//       {
//         key: '2',
//         checkbox: false,
//         bankCode: '006',
//         bankName: 'กรุงไทย จำกัด (มหาชน)',
//         bankAccountNo: '0000000002',
//         bankAccountName: 'กาญจนา พิเศษ',
//         SSO_BRANCH_CODE: '1050',
//         paymentNo: '000000002',
//         offerer: '000 : อรุณเซอร์วิส แอนด์ ซัพพลาย',
//         amount: 1200000,
//         paymentType: 'p_banks',
//         manage: '',
//       },
//       {
//         key: '3',
//         checkbox: false,
//         bankCode: '006',
//         bankName: 'กรุงไทย จำกัด (มหาชน)',
//         bankAccountNo: '0000000003',
//         bankAccountName: 'กาญจนา พิเศษ',
//         SSO_BRANCH_CODE: '1050',
//         paymentNo: '000000003',
//         offerer: '000 : อรุณเซอร์วิส แอนด์ ซัพพลาย',
//         amount: 1200000,
//         paymentType: 'p_check',
//         manage: '',
//       },
//       {
//         key: '4',
//         checkbox: false,
//         bankCode: '006',
//         bankName: 'กรุงไทย จำกัด (มหาชน)',
//         bankAccountNo: '0000000004',
//         bankAccountName: 'กาญจนา พิเศษ',
//         SSO_BRANCH_CODE: '1050',
//         paymentNo: '000000004',
//         offerer: '000 : อรุณเซอร์วิส แอนด์ ซัพพลาย',
//         amount: 1200000,
//         paymentType: 'p_money',
//         manage: '',
//       },
//       {
//         key: '5',
//         checkbox: false,
//         bankCode: '006',
//         bankName: 'กรุงไทย จำกัด (มหาชน)',
//         bankAccountNo: '0000000001',
//         bankAccountName: 'กาญจนา พิเศษ',
//         SSO_BRANCH_CODE: '1050',
//         paymentNo: '000000005',
//         offerer: '000 : อรุณเซอร์วิส แอนด์ ซัพพลาย',
//         amount: 1200000,
//         paymentType: 'p_office',
//         manage: '',
//       },
//       {
//         key: '6',
//         checkbox: false,
//         bankCode: '006',
//         bankName: 'กรุงไทย จำกัด (มหาชน)',
//         bankAccountNo: '0000000006',
//         bankAccountName: 'กาญจนา พิเศษ',
//         SSO_BRANCH_CODE: '1050',
//         paymentNo: '000000006',
//         offerer: '000 : อรุณเซอร์วิส แอนด์ ซัพพลาย',
//         amount: 1200000,
//         paymentType: 'p_check',
//         manage: '',
//       },
//       {
//         key: '7',
//         checkbox: false,
//         bankCode: '006',
//         bankName: 'กรุงไทย จำกัด (มหาชน)',
//         bankAccountNo: '0000000007',
//         bankAccountName: 'กาญจนา พิเศษ',
//         SSO_BRANCH_CODE: '1050',
//         paymentNo: '000000007',
//         offerer: '000 : อรุณเซอร์วิส แอนด์ ซัพพลาย',
//         amount: 1200000,
//         paymentType: 'p_banks',
//         manage: '',
//       },
//     ];

//     //manipulate data by paymentType
//     const resultPaymentDetail = data.filter((item) => item.paymentNo === paymentNo);

//     return resultPaymentDetail;
//   },
// );

// export const getChequeInfoListService = createAsyncThunk(
//   `${sliceName}/getChequeInfoList`, // เปลี่ยนชื่อ action type
//   (paymentNo: string): TableChequeType[] => {
//     const data: TableChequeType[] = [
//       {
//         id: '1',
//         paymentNo: '000000001',
//         chequeNo: '81020094',
//         bankCode: '006',
//         bankName: 'กรุงไทย จำกัด (มหาชน)',
//         bankAccountNo: '0000000001',
//         bankAccountName: 'นพดล สุขใจดี',
//         chequeStampDate: '2024-12-16',
//         amount: 1200000,
//         mode: 'view',
//       },
//       {
//         id: '2',
//         paymentNo: '000000002',
//         chequeNo: '81020094',
//         bankCode: '006',
//         bankName: 'กรุงไทย จำกัด (มหาชน)',
//         bankAccountNo: '0000000001',
//         bankAccountName: 'นพดล สุขใจดี',
//         chequeStampDate: '2024-12-16',
//         amount: 1200000,
//         mode: 'view',
//       },
//       {
//         id: '3',
//         paymentNo: '000000003',
//         chequeNo: '81020094',
//         bankCode: '006',
//         bankName: 'กรุงไทย จำกัด (มหาชน)',
//         bankAccountNo: '0000000001',
//         bankAccountName: 'นพดล สุขใจดี',
//         chequeStampDate: '2024-12-16',
//         amount: 1200000,
//         mode: 'view',
//       },
//       {
//         id: '4',
//         paymentNo: '000000004',
//         chequeNo: '81020094',
//         bankCode: '006',
//         bankName: 'กรุงไทย จำกัด (มหาชน)',
//         bankAccountNo: '0000000001',
//         bankAccountName: 'นพดล สุขใจดี',
//         chequeStampDate: '2024-12-16',
//         amount: 1200000,
//         mode: 'view',
//       },
//       {
//         id: '5',
//         paymentNo: '000000005',
//         chequeNo: '81020094',
//         bankCode: '006',
//         bankName: 'กรุงไทย จำกัด (มหาชน)',
//         bankAccountNo: '0000000001',
//         bankAccountName: 'นพดล สุขใจดี',
//         chequeStampDate: '2024-12-16',
//         amount: 1200000,
//         mode: 'view',
//       },
//       {
//         id: '6',
//         paymentNo: '000000006',
//         chequeNo: '81020094',
//         bankCode: '006',
//         bankName: 'กรุงไทย จำกัด (มหาชน)',
//         bankAccountNo: '0000000001',
//         bankAccountName: 'นพดล สุขใจดี',
//         chequeStampDate: '2024-12-16',
//         amount: 1200000,
//         mode: 'view',
//       },
//       {
//         id: '7',
//         paymentNo: '000000007',
//         chequeNo: '81020094',
//         bankCode: '006',
//         bankName: 'กรุงไทย จำกัด (มหาชน)',
//         bankAccountNo: '0000000001',
//         bankAccountName: 'นพดล สุขใจดี',
//         chequeStampDate: '2024-12-16',
//         amount: 1200000,
//         mode: 'view',
//       },
//       {
//         id: '8',
//         paymentNo: '000000008',
//         chequeNo: '81020094',
//         bankCode: '006',
//         bankName: 'กรุงไทย จำกัด (มหาชน)',
//         bankAccountNo: '0000000001',
//         bankAccountName: 'นพดล สุขใจดี',
//         chequeStampDate: '2024-12-16',
//         amount: 1200000,
//         mode: 'view',
//       },
//     ];

//     //manipulate data by paymentType
//     const resultChequeInfoList = data.filter((item) => item.paymentNo === paymentNo);

//     return resultChequeInfoList;
//   },
// );
