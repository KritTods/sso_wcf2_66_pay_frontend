import bankAccountSSOSlice from '@/store-redux/slices/masterData/bankAccount/slice';

export const masterData = {
  bankAccountSSOSlice,
};
