import cutOffPaymentDoctorSalarySlice from '@/store-redux/slices/cutOffPayment/doctor-salary/slice';

export const cutOffPaymentDoctor = {
  // export ไปให้ file index.tsx ในfolder (reducer)
  cutOffPaymentDoctorSalarySlice,
};
