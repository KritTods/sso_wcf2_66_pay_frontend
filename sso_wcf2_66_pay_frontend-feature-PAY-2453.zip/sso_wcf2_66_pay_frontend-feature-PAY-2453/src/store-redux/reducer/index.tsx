import { reserve } from './reserve';
import { masterData } from './masterData';
import { readytopay } from './readytopay';
import { cancelPayment } from './cancelPayment';
import { cutOffPaymentDoctor } from './cutOffPayment';

const reducer = {
  ...reserve,
  ...masterData,
  ...readytopay,
  ...cancelPayment,
  ...cutOffPaymentDoctor,
};

export default reducer;
