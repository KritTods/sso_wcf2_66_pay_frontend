export const searchColumn = {
  lg: 6,
  xl: 6,
};

export const formColumn = {
  lg: 6,
  xl: 6,
};

export const threeColumn = {
  lg: 8,
  xl: 8,
};

export const singleColumn = {
  lg: 24,
  xl: 24,
};

export const formTable = {
  lg: 4,
  xl: 4,
};
export const HformSearch = {
  lg: 12,
  xl: 12,
};

