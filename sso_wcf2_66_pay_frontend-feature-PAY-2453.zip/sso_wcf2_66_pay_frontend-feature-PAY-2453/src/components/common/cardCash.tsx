import React from 'react';
import { Row, Col } from 'wcf-component-lib/node_modules/antd';
import { formColumn } from '@/constants/layoutColumn';
import { formatCurrency } from '@/utils/formatGeneral';

interface CardCashProp {
  dataTestId: string;
  cash: number;
}

export default function cardCash(props: CardCashProp): React.JSX.Element {
  return (
    <div className='w-full bg-white p-6 shadow-sm rounded-xl'>
      <div className='flex flex-col gap-4'>
        <p className='font-bold text-xl'>สั่งจ่ายโดย : เงินสด</p>
        <Row gutter={[16, 16]}>
          <Col {...formColumn}>
            <p id={`${props.dataTestId}-cash-label-title`} className='text-label-info'>
              จำนวนเงิน (บาท)
            </p>
          </Col>
          <Col {...formColumn}>
            <p id={`${props.dataTestId}-cash-label-value`} className='text-display'>
              {props.cash !== 0 ? formatCurrency(props.cash) : 0}
            </p>
          </Col>
        </Row>
      </div>
    </div>
  );
}
