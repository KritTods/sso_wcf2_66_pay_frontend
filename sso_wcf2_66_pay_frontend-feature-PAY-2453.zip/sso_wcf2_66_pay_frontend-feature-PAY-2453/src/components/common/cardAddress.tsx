import React from 'react';
import { BaseForm } from 'wcf-component-lib/src/components';
import { Col } from 'wcf-component-lib/node_modules/antd';
import { singleColumn } from '@/constants/layoutColumn';

interface CardAddressProp {
  dataTestId: string;
  address: string;
  isNotShadow?: boolean;
}

export default function CardAddress({ dataTestId, address, isNotShadow = false }: CardAddressProp): React.JSX.Element {
  return (
    <BaseForm name={'cutoffpay-search'}>
      <div className='flex flex-col items-center'>
        <div className={`w-full bg-white p-6 ${!isNotShadow && 'shadow-sm'}relative rounded-xl`}>
          <Col {...singleColumn}>
            <p className='header-card pb-5'>ส่งเช็คทางไปรษณีย์</p>
            <div>
              <p id={`${dataTestId}-cardAddress-address-label-title`} className='text-label-info'>
                ที่อยู่
              </p>
              <p id={`${dataTestId}-cardAddress-address-label-value`} className='text-display'>
                {address}
              </p>
            </div>
          </Col>
        </div>
      </div>
    </BaseForm>
  );
}
