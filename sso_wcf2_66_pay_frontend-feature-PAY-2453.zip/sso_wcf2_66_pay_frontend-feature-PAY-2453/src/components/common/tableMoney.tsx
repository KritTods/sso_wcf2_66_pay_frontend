'use client';
import React, { useEffect, useState } from 'react';
import { BaseButton, BaseItemInput, BaseItemInputNumber } from 'wcf-component-lib/src/components';
import TableListLayout from 'wcf-component-lib/src/layout/TableListLayout';
import { BaseGrid } from 'wcf-component-lib/src/components/v2';
import { ColumnsTypeCustom } from 'wcf-component-lib/src/components/v2/BaseGrid';
import { onlyNumberRule, requiredRule, minRule, maxRule } from 'wcf-component-lib/src/rules/FormRulesFunction';
import { v4 as uuidv4 } from 'uuid';
import { formatCurrency } from '@/utils/formatGeneral';
import {
  CheckCircle,
  LogNoAccess,
  Refresh,
  NumberedListRight,
  Edit,
} from 'wcf-component-lib/node_modules/iconoir-react';
import { FormInstance } from 'wcf-component-lib/node_modules/antd';
import SpinLoading from '@/components/common/SpinLoading';
import { useSelector } from 'react-redux';
import { readyToPayDoctorSalarySelector } from '@/store-redux/slices/readytopay/doctor-salary';

interface TableMoneyProps {
  dataTestId: string;
  mode?: 'view' | 'edit' | 'add' | 'custom';
  headerTitle?: string;
  onChange?: (data: TableMoneyType[]) => void;
  add: (defaultValue?: TableMoneyType, insertIndex?: number) => void;
  remove: (index: number | number[]) => void;
  form: FormInstance;
  itemName: string;
  hideButtonAdd?: boolean;
  isNotShadow?: boolean;
  customDisplayTable?: CustomDisplayTableMoneyType;
}

export interface TableMoneyType {
  id: string;
  postalNo: string | undefined;
  portalDestination: string | undefined;
  postalCode: string | undefined;
  receiverName: string | undefined;
  amount: number | undefined;
  mode: 'view' | 'edit' | 'add' | 'custom';
}

export const INIT_DATA_MONEY: TableMoneyType[] = [
  {
    id: uuidv4(),
    postalNo: '', // เลขที่ธนาณัติ
    portalDestination: '', // ชื่อไปรษณีย์ปลายทาง
    postalCode: '', // รหัสไปรษณีย์ปลายทาง
    receiverName: '', // ชื่อผู้มีสิทธิ์
    amount: 0, // จำนวนเงิน
    mode: 'add',
  },
];

export interface CustomDisplayTableMoneyType {
  id: 'text' | 'input';
  postalNo: 'text' | 'input';
  portalDestination: 'text' | 'input';
  postalCode: 'text' | 'input';
  receiverName: 'text' | 'input';
  amount: 'text' | 'input';
}

export const CUSTOM_DISPLAY_TABLE_MONEY: CustomDisplayTableMoneyType = {
  id: 'text',
  postalNo: 'text', // เลขที่ธนาณัติ
  portalDestination: 'text', // ชื่อไปรษณีย์ปลายทาง
  postalCode: 'text', // รหัสไปรษณีย์ปลายทาง
  receiverName: 'text', // ชื่อผู้มีสิทธิ์
  amount: 'text', // จำนวนเงิน
};

export default function TableMoney({
  dataTestId,
  mode = 'view',
  headerTitle = 'ธนาณัติ',
  onChange,
  add,
  form,
  itemName,
  isNotShadow = false,
  customDisplayTable = CUSTOM_DISPLAY_TABLE_MONEY,
}: TableMoneyProps): React.ReactElement {
  const [dataSource, setDataSource] = useState<TableMoneyType[]>([]);
  const [dataSourceEdit, setDataSourceEdit] = useState<TableMoneyType[]>([]);

  const {
    pageDoctorSalalyForm: { selectList },
  } = useSelector(readyToPayDoctorSalarySelector);

  useEffect(() => {
    if (form.getFieldValue(itemName) !== undefined) {
      setDataSource(form.getFieldValue(itemName));
      //set dataSourceEdit for check data change
      if (dataSourceEdit.length === 0) {
        setDataSourceEdit(form.getFieldValue(itemName));
      }
    }
  }, [form.getFieldValue(itemName)]);

  useEffect(() => {
    //callback dataSource to parent
    if (onChange) {
      onChange(dataSource);
    }
  }, [dataSource]);

  //จัดการ mode เช็ค
  const updateMode = (id: string, mode: 'add' | 'edit' | 'view' | 'custom'): void => {
    //console.log('mode:', mode);
    const updatedData = dataSource.map((item) => (item.id === id ? { ...item, mode } : item));
    setDataSource(updatedData);
  };

  const handleUpdate = (id: string, key: string, value: string | number | undefined): void => {
    try {
      const newDataSource = dataSource.map((item) => {
        if (item.id === id) {
          return { ...item, [key]: value };
        }

        return item;
      });
      setDataSource(newDataSource);
      form.setFieldsValue({ [itemName]: newDataSource });
    } catch (error) {
      console.error('Error updating dataSource:', error);
    }
  };

  const handleAdd = (): void => {
    try {
      const newCheque: TableMoneyType = { ...INIT_DATA_MONEY[0], id: uuidv4(), mode: 'add' };
      setDataSource([...dataSource, newCheque]);
      add(newCheque);
    } catch (error) {
      console.error('Error adding new item to dataSource:', error);
    }
  };

  const [incidentNumber, setIncidentNumber] = useState<string>('');
  const [runNumber, setRunNumber] = useState<string[]>([]);

  const handleRunNumber = (): void => {
    console.log('incidentNumber', incidentNumber, 'selectList', selectList.length);

    const countList = selectList.length;

    let number = parseInt(incidentNumber, 10);
    if (!isNaN(number)) {
      const tempResult = [];
      if (countList === 1) {
        // ถ้า countList = 1 ให้เพิ่มหมายเลขเริ่มต้นเพียงตัวเดียว
        tempResult.push(number.toString().padStart(20, '0'));
      } else if (countList > 1) {
        // ถ้า countList > 1 ให้เพิ่มหมายเลขและบวกค่าขึ้นทีละ 1
        for (let i = 0; i < countList; i++) {
          tempResult.push(number.toString().padStart(20, '0'));
          number += 1;
        }
      }
      setRunNumber(tempResult);
    } else {
      setRunNumber([]);
    }
  };

  console.log('result', runNumber);

  useEffect(() => {
    try {
      const intitalMoney: TableMoneyType[] = selectList.map((item, index) => ({
        id: uuidv4(),
        postalNo: runNumber[index] || '',
        portalDestination: item.postal?.postalName,
        postalCode: item.postal?.postalCode,
        receiverName: item.fullName,
        amount: Number(item.compensationPerPerson),
        mode: 'custom',
      }));
      setDataSource(intitalMoney);
    } catch (error) {
      console.error('Error initializing dataSource:', error);
    }
  }, [selectList, runNumber]);

  const headTableContent = (): React.ReactElement => {
    if (mode === 'view') return <></>;
    // if (hideButtonAdd) return <></>;

    return (
      <div className='flex justify-end gap-4  right-5 bottom-5'>
        <BaseItemInput
          itemName='incidentNumber'
          placeholder='ระบุเลขที่ธนาณัติเริ่มต้น'
          className='w-[320px] mt-[4px]'
          onChangeFunction={(e) => setIncidentNumber(e.target.value)}
        />
        <BaseButton
          size='middle'
          className='!min-w-[240px]'
          icon={<NumberedListRight />}
          label='รันเลขธนาณัติ'
          onClick={handleRunNumber}
        />
      </div>
    );
  };

  if (form.getFieldValue(itemName) === undefined) {
    return (
      <div className={`h-[280px] bg-white ${!isNotShadow && 'shadow-sm'} rounded-xl flex justify-center items-center`}>
        <SpinLoading />
      </div>
    );
  }

  const columns: ColumnsTypeCustom = [
    {
      align: 'center',
      title: 'ลำดับ',
      key: 'id',
      dataIndex: 'id',
      width: 50,
      render: (id: number, record: unknown, index): React.ReactElement => {
        return <div className='mb-6'>{index + 1}</div>;
      },
    },
    {
      align: 'center',
      title: 'เลขที่ธนาณัติ',
      key: 'postalNo',
      dataIndex: 'postalNo',
      width: 150,
      render: (postalNo: string, record: unknown, index): React.ReactElement => {
        const row = record as TableMoneyType;
        console.log('postalNo', postalNo);
        switch (row.mode) {
          case 'custom':
            if (customDisplayTable.postalNo === 'text') {
              return <div className='mb-6'>{postalNo}</div>;
            }

            return (
              // <div className='mb-6'>{postalNo}</div>
              <BaseItemInput
                value={postalNo}
                className='bg-[#E7F3F5] text-center'
                id={`${dataTestId}-postalNo-${row.id}-input-text`}
                itemName={[index.toString(), 'postalNo']}
                rules={[requiredRule('เลขที่ธนาณัติ')]}
                onChangeFunction={(e) => {
                  handleUpdate(row.id, 'postalNo', e.target.value);
                }}
              />
            );
          case 'view':
            return <div className='mb-6'>{postalNo}</div>;
          case 'edit':
            return (
              <BaseItemInput
                value={postalNo}
                className='bg-[#E7F3F5] text-center'
                id={`${dataTestId}-postalNo-${row.id}-input-text`}
                itemName={[index.toString(), 'postalNo']}
                rules={[requiredRule('เลขที่ธนาณัติ')]}
                onChangeFunction={(e) => {
                  handleUpdate(row.id, 'postalNo', e.target.value);
                }}
              />
            );
          case 'add':
            return (
              <BaseItemInput
                value={postalNo}
                className='bg-[#E7F3F5] text-center'
                id={`${dataTestId}-postalNo-${row.id}-input-text`}
                itemName={[index.toString(), 'postalNo']}
                rules={[requiredRule('เลขที่ธนาณัติ')]}
                onChangeFunction={(e) => {
                  handleUpdate(row.id, 'postalNo', e.target.value);
                }}
              />
            );
          default:
            return <div className='mb-6'>-</div>;
        }
      },
    },
    {
      align: 'center',
      title: 'รหัสไปรษณีย์ปลายทาง',
      key: 'postalCode',
      dataIndex: 'postalCode',
      width: 150,
      render: (postalCode: number, record: unknown, index): React.ReactElement => {
        const row = record as TableMoneyType;
        switch (row.mode) {
          case 'custom':
            if (customDisplayTable.postalCode === 'text') {
              return <div className='mb-6'>{postalCode}</div>;
            }

            return (
              <BaseItemInput
                value={postalCode}
                className='bg-[#E7F3F5] text-center'
                id={`${dataTestId}-postalCode-${row.id}-input-text`}
                itemName={[index.toString(), 'postalCode']}
                rules={[
                  requiredRule('รหัสไปรษณีย์ปลายทาง'),
                  onlyNumberRule('รหัสไปรษณีย์ปลายทาง'),
                  minRule('รหัสไปรษณีย์ปลายทาง', 5),
                  maxRule('รหัสไปรษณีย์ปลายทาง', 5),
                ]}
                onChangeFunction={(e) => {
                  handleUpdate(row.id, 'postalCode', e.target.value);
                }}
              />
            );
          case 'view':
            return <div className='mb-6'>{postalCode}</div>;
          case 'edit':
            return <div className='mb-6'>{postalCode}</div>;
          case 'add':
            return (
              <BaseItemInput
                value={postalCode}
                className='bg-[#E7F3F5] text-center'
                id={`${dataTestId}-postalCode-${row.id}-input-text`}
                itemName={[index.toString(), 'postalCode']}
                rules={[
                  requiredRule('รหัสไปรษณีย์ปลายทาง'),
                  onlyNumberRule('รหัสไปรษณีย์ปลายทาง'),
                  minRule('รหัสไปรษณีย์ปลายทาง', 5),
                  maxRule('รหัสไปรษณีย์ปลายทาง', 5),
                ]}
                onChangeFunction={(e) => {
                  handleUpdate(row.id, 'postalCode', e.target.value);
                }}
              />
            );
          default:
            return <div className='mb-6'>-</div>;
        }
      },
    },
    {
      align: 'center',
      title: 'ชื่อไปรษณีย์ปลายทาง',
      key: 'portalDestination',
      dataIndex: 'portalDestination',
      width: 150,
      render: (portalDestination: number, record: unknown, index): React.ReactElement => {
        const row = record as TableMoneyType;
        switch (row.mode) {
          case 'custom':
            if (customDisplayTable.portalDestination === 'text') {
              return <div className='mb-6'>{portalDestination}</div>;
            }

            return (
              <BaseItemInput
                value={portalDestination}
                className='bg-[#E7F3F5] text-center'
                id={`${dataTestId}-portalDestination-${row.id}-input-text`}
                itemName={[index.toString(), 'portalDestination']}
                rules={[requiredRule('ชื่อไปรษณีย์ปลายทาง'), maxRule('ชื่อไปรษณีย์ปลายทาง', 100)]}
                onChangeFunction={(e) => {
                  handleUpdate(row.id, 'portalDestination', e.target.value);
                }}
              />
            );
          case 'view':
            return <div className='mb-6'>{portalDestination}</div>;
          case 'edit':
            return <div className='mb-6'>{portalDestination}</div>;
          case 'add':
            return (
              <BaseItemInput
                value={portalDestination}
                className='bg-[#E7F3F5] text-center'
                id={`${dataTestId}-portalDestination-${row.id}-input-text`}
                itemName={[index.toString(), 'portalDestination']}
                rules={[requiredRule('ชื่อไปรษณีย์ปลายทาง'), maxRule('ชื่อไปรษณีย์ปลายทาง', 100)]}
                onChangeFunction={(e) => {
                  handleUpdate(row.id, 'portalDestination', e.target.value);
                }}
              />
            );
          default:
            return <div className='mb-6'>-</div>;
        }
      },
    },
    {
      align: 'left',
      title: 'ลูกจ้าง/ผู้มีสิทธิ์',
      key: 'receiverName',
      dataIndex: 'receiverName',
      width: 150,
      render: (receiverName: number, record: unknown, index): React.ReactElement => {
        const row = record as TableMoneyType;
        switch (row.mode) {
          case 'custom':
            if (customDisplayTable.receiverName === 'text') {
              return <div className='mb-6'>{receiverName}</div>;
            }

            return (
              <BaseItemInput
                value={receiverName}
                className='bg-[#E7F3F5] text-center'
                id={`${dataTestId}-receiverName-${row.id}-input-text`}
                itemName={[index.toString(), 'receiverName']}
                rules={[requiredRule('ลูกจ้าง/ผู้มีสิทธิ์'), maxRule('ลูกจ้าง/ผู้มีสิทธิ์', 100)]}
                onChangeFunction={(e) => {
                  handleUpdate(row.id, 'receiverName', e.target.value);
                }}
              />
            );
          case 'view':
            return <div className='mb-6'>{receiverName}</div>;
          case 'edit':
            return <div className='mb-6'>{receiverName}</div>;
          case 'add':
            return (
              <BaseItemInput
                value={receiverName}
                className='bg-[#E7F3F5] text-center'
                id={`${dataTestId}-receiverName-${row.id}-input-text`}
                itemName={[index.toString(), 'receiverName']}
                rules={[requiredRule('ลูกจ้าง/ผู้มีสิทธิ์'), maxRule('ลูกจ้าง/ผู้มีสิทธิ์', 100)]}
                onChangeFunction={(e) => {
                  handleUpdate(row.id, 'receiverName', e.target.value);
                }}
              />
            );
          default:
            return <div className='mb-6'>-</div>;
        }
      },
    },
    {
      align: 'right',
      title: 'จำนวนเงิน',
      key: 'amount',
      width: 150,
      dataIndex: 'amount',
      render: (amount: number, record: unknown, index): React.ReactElement => {
        const row = record as TableMoneyType;
        switch (row.mode) {
          case 'custom':
            if (customDisplayTable.amount === 'text') {
              return <div className='mb-6'>{formatCurrency(amount)}</div>;
            }

            return (
              <BaseItemInputNumber
                className='bg-[#E7F3F5] w-full'
                id={`${dataTestId}-amount-${row.id}-input-text`}
                itemName={[index.toString(), 'amount']}
                rules={[requiredRule('จำนวนเงิน')]}
                hideFieldControl
                onChangeFunction={(e) => {
                  handleUpdate(row.id, 'amount', Number(e.target.value));
                }}
              />
            );
          case 'view':
            return (
              <div className='mb-6'>
                <span>{formatCurrency(amount)}</span>
              </div>
            );
          case 'edit':
            return (
              <div className='mb-6'>
                <span>{formatCurrency(amount)}</span>
              </div>
            );
          case 'add':
            return (
              <BaseItemInputNumber
                className='bg-[#E7F3F5] w-full'
                id={`${dataTestId}-amount-${row.id}-input-text`}
                itemName={[index.toString(), 'amount']}
                rules={[requiredRule('จำนวนเงิน')]}
                hideFieldControl
                onChangeFunction={(e) => {
                  handleUpdate(row.id, 'amount', Number(e.target.value));
                }}
              />
            );
          default:
            return <div className='mb-6'>-</div>;
        }
      },
    },
  ];

  //เพิ่ม column สำหรับแสดงปุ่มลบ เฉพาะใน mode ที่ไม่ใช่ view
  if (mode !== 'view') {
    columns.push({
      align: 'center',
      title: '',
      key: 'id',
      dataIndex: 'id',
      width: 50,
      render: (text: string, record: unknown, index): React.ReactElement => {
        const row = record as TableMoneyType;
        const findIdOldData = dataSourceEdit.find((item) => item.id === row.id);
        //compare data change
        const dataChange = findIdOldData && findIdOldData.postalNo !== row.postalNo;

        switch (row.mode) {
          case 'custom':
            //check data not change show disable button
            if (!dataChange) {
              return (
                <div className='flex justify-center items-center'>
                  <button
                    type='button'
                    disabled
                    className='w-10 h-10 flex justify-center items-center p-2 rounded-full bg-gray-100 cursor-not-allowed  mb-6'
                  >
                    <Refresh color='gray' />
                  </button>
                </div>
              );
            }

            return (
              <div className='flex justify-center items-center'>
                <button
                  type='button'
                  className='w-10 h-10 flex justify-center items-center p-2 rounded-full bg-red-100 cursor-pointer  mb-6'
                  onClick={() => {
                    //when data change then click button to reset data
                    if (dataChange) {
                      const newDataSource = form.getFieldValue(itemName).map((item: TableMoneyType) => {
                        if (item.id === row.id) {
                          return { ...item, postalNo: findIdOldData?.postalNo };
                        }

                        return item;
                      });

                      form.setFieldsValue({
                        moneys: newDataSource,
                      });
                    }
                  }}
                >
                  <Refresh color='red' />
                </button>
              </div>
            );
          case 'view':
            return <div className='mb-6'></div>;
          case 'edit':
            return (
              <div className='flex flex-row gap-2'>
                <div
                  key={row.id}
                  className='p-2 rounded-full bg-[#E7FAF2] cursor-pointer'
                  onClick={() => updateMode(row.id, 'view')}
                >
                  <CheckCircle color='green' />
                </div>

                <div
                  key={row.id}
                  className='p-2 rounded-full bg-[#F9EAEA] cursor-pointer'
                  onClick={() => updateMode(row.id, 'view')}
                >
                  <LogNoAccess color='red' />
                </div>
              </div>
            );

            return (
              <div className='flex justify-center items-center'>
                <div
                  key={row.id}
                  className='w-10 h-10 flex justify-center items-center p-2 rounded-full bg-[#FFF9E5] cursor-pointer mb-6'
                  onClick={() => updateMode(row.id, 'edit')}
                >
                  <Edit color='#1C4651' />
                </div>
              </div>
            );
          case 'add':
          default:
            return <div className='mb-6'></div>;
        }
      },
    });
  }

  return (
    <>
      <div className={`w-full flex flex-col p-6 bg-white ${!isNotShadow && 'shadow-sm'}  rounded-xl`}>
        <TableListLayout
          headTableContent={headTableContent()}
          textHeader={headerTitle}
          totalItems={dataSource.length}
          type='form'
          firstLoading={dataSource.length === 0}
          emptyText='โปรดระบุข้อมูลธนาณัติ'
          emptyDescription='ไม่มีข้อมูลที่ต้องการแสดงในขณะนี้'
          Grid={
            <BaseGrid
              isHaveBorderBottomLeftRight
              twoToneColor={mode !== 'edit' ? itemName === 'moneys' : itemName === 'moneysEdit'}
              rowKey='id'
              rows={dataSource}
              columns={columns}
            />
          }
        />
      </div>
    </>
  );
}
